﻿#pragma warning disable 0168	// variable declared but not used.
#pragma warning disable 0219	// variable assigned but not used.
#pragma warning disable 0414	// private field assigned but not used.
#pragma warning disable 0649	// public field assigned but not used.
#pragma warning disable 0067

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Scratch2DWF
{
    public partial class frmEnum : Form
    {
        [Flags]
        public enum Pet : byte
        {
            None = 0,
            Cat = 1,
            Chicken = 2,
            Dog = 4,
            Guppy = 8,
            Parrot = 16,
            Pig = 32,
        }

        public string[] m_petDescriptions = new string[]
        {
            "It goes nothing",
            "It goes purrr",
            "It goes bawk bawk",
            "It goes ruff ruff",
            "It goes bubble bubble",
            "It goes Hello",
            "It goes oink oink",
        };

        public string[] m_petDescriptions2 = new string[]
        {
            "It goes nothing",          //0
            "It goes purrrr",           //1
            "It goes bawk bawk",        //2
            "",                         //3
            "It goes ruff ruff",        //4
            "",                         //5
            "",                         //6
            "",                         //7
            "It goes bubble bubble",    //8
            "",                         //9
            "",                         //10
            "",                         //11
            "",                         //12
            "",                         //13
            "",                         //14
            "",                         //15
            "It goes Hello",            //16
            "",                         //17
            "",                         //18
            "",                         //19
            "",                         //20
            "",                         //21
            "",                         //22
            "",                         //23
            "",                         //24
            "",                         //25
            "",                         //26
            "",                         //27
            "",                         //28
            "",                         //29
            "",                         //30
            "",                         //31
            "It goes oink oink",        //32
        };

        public string[] m_combinedPetDestriptions = new string[]
        {
            "None", 	    			                            //0
            "Cat, ", 				                                //1
            "Chicken, ", 				                            //2
            "Cat, Chicken, ", 				                        //3
            "Dog, ", 				                                //4
            "Cat, Dog, ", 				                            //5
            "Chicken, Dog, ", 				                        //6
            "Cat, Chicken, Dog, ", 				                    //7
            "Guppy, ", 				                                //8
            "Cat, Guppy, ", 				                        //9
            "Chicken, Guppy, ", 			            	        //10
            "Cat, Chicken, Guppy, ", 		            		    //11
            "Dog, Guppy, ", 				                        //12
            "Cat, Dog, Guppy, ", 			                    	//13
            "Chicken, Dog, Guppy, ", 		                		//14
            "Cat, Chicken, Dog, Guppy, ", 	            			//15
            "Parrot, ", 				                            //16
            "Cat, Parrot, ", 				                        //17
            "Chicken, Parrot, ", 				                    //18
            "Cat, Chicken, Parrot, ", 				                //19
            "Dog, Parrot, ", 				                        //20
            "Cat, Dog, Parrot, ", 			            	        //21
            "Chicken, Dog, Parrot, ", 		        		        //22
            "Cat, Chicken, Dog, Parrot, ", 	    			        //23
            "Guppy, Parrot, ", 				                        //24
            "Cat, Guppy, Parrot, ", 				                //25
            "Chicken, Guppy, Parrot, ", 			        	    //26
            "Cat, Chicken, Guppy, Parrot, ", 		        		//27
            "Dog, Guppy, Parrot, ", 				                //28
            "Cat, Dog, Guppy, Parrot, ", 			            	//29
            "Chicken, Dog, Guppy, Parrot, ", 		        		//30
            "Cat, Chicken, Dog, Guppy, Parrot, ", 				    //31
            "Pig, ", 				                                //32
            "Cat, Pig, ", 				                            //33
            "Chicken, Pig, ", 				                        //34
            "Cat, Chicken, Pig, ", 				                    //35
            "Dog, Pig, ", 				                            //36
            "Cat, Dog, Pig, ", 				                        //37
            "Chicken, Dog, Pig, ", 			                    	//38
            "Cat, Chicken, Dog, Pig, ", 		                	//39
            "Guppy, Pig, ", 				                        //40
            "Cat, Guppy, Pig, ", 			                	    //41
            "Chicken, Guppy, Pig, ", 		                		//42
            "Cat, Chicken, Guppy, Pig, ", 	        	    		//43
            "Dog, Guppy, Pig, ", 			        	            //44
            "Cat, Dog, Guppy, Pig, ", 		        		        //45
            "Chicken, Dog, Guppy, Pig, ", 	        			    //46
            "Cat, Chicken, Dog, Guppy, Pig, ", 				        //47
            "Parrot, Pig, ", 				                        //48
            "Cat, Parrot, Pig, ", 			                    	//49
            "Chicken, Parrot, Pig, ", 		                		//50
            "Cat, Chicken, Parrot, Pig, ", 	            			//51
            "Dog, Parrot, Pig, ", 			            	        //52
            "Cat, Dog, Parrot, Pig, ", 		            	    	//53
            "Chicken, Dog, Parrot, Pig, ", 	            			//54
            "Cat, Chicken, Dog, Parrot, Pig, ", 				    //55
            "Guppy, Parrot, Pig, ", 				                //56
            "Cat, Guppy, Parrot, Pig, ", 			        	    //57
            "Chicken, Guppy, Parrot, Pig, ", 		        		//58
            "Cat, Chicken, Guppy, Parrot, Pig, ", 		    		//59
            "Dog, Guppy, Parrot, Pig, ", 				            //60
            "Cat, Dog, Guppy, Parrot, Pig, ", 				        //61
            "Chicken, Dog, Guppy, Parrot, Pig, ", 				    //62
            "Cat, Chicken, Dog, Guppy, Parrot, Pig, ", 				//63
        };

        private Pet m_petValue;

        public frmEnum()
        {
            InitializeComponent();
            string[] values = Enum.GetNames(typeof(Pet));
            for (int n = 0; n < values.Length; ++n)
            {
                cmbEnum.Items.Add(values[n]);
                clbEnums.Items.Add(values[n]);
            }
        }

        private void cmbEnum_SelectedIndexChanged(object sender, EventArgs e)
        {
            //tbSelection.Text = m_petDescriptions[cmbEnum.SelectedIndex];
            Pet pet = (Pet)cmbEnum.SelectedIndex;
            tbSelection.Text = m_petDescriptions[(byte)pet];
        }

        private void clbEnums_SelectedValueChanged(object sender, EventArgs e)
        {
            tbSelection.Text = "";
            m_petValue = Pet.None;
            for (int n = 0; n < clbEnums.CheckedItems.Count; ++n)
            {
                string v = clbEnums.CheckedItems[n].ToString();

                Enum.TryParse(typeof(Pet), v, out object pet);
                m_petValue |= (Pet)pet;

                tbSelection.Text += v;
                tbSelection.Text += "\r\n";
                tbSelection.Text += m_petDescriptions2[(byte)pet];
                tbSelection.Text += "\r\n\r\n";
            }

            tbSelection.Text += m_combinedPetDestriptions[(byte)m_petValue];
        }

        private void btnRemoveSel_Click(object sender, EventArgs e)
        {
            Array whats = Enum.GetValues(typeof(Pet));
            string results = "before: \r\n";
            foreach(object v in whats)
            {
                //if ((m_petValue & (Pet)v) == (Pet)v)
                if (m_petValue.HasFlag((Pet)v))
                {
                    results += v.ToString() + " was selected\r\n";
                }
            }

            Pet removed = (Pet)cmbEnum.SelectedIndex;
            m_petValue &= ~removed;

            results += "\r\nafter: \r\n";
            foreach (object v in whats)
            {
                //if ((m_petValue & (Pet)v) == (Pet)v)
                if (m_petValue.HasFlag((Pet)v))
                {
                    results += v.ToString() + " was selected\r\n";
                }
            }
            tbSelection.Text = results;
        }
    }
}
