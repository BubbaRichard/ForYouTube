﻿#pragma warning disable 0168    // variable declared but not used.
#pragma warning disable 0219    // variable assigned but not used.
#pragma warning disable 0414    // private field assigned but not used.
#pragma warning disable 0649    // public field assigned but not used.
#pragma warning disable 0067
#pragma warning disable UNT0001
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class ArrayCommon
{
    public static T[] Add<T>(this T[] list, T value)
    {
        int cnt = list == null ? 0 : list.Length;
        T[] results = new T[cnt + 1];
        int n = 0;
        if (list != null)
        {
            for (; n < list.Length; ++n)
                results[n] = list[n];
        }
        results[n] = value;
        return results;
    }

    public static T[] AddRange<T>(this T[] list, T[] values)
    {
        int cnt = list == null ? 0 : list.Length;
        T[] results = new T[cnt + values.Length];
        int n = 0;
        if (list != null)
        {
            for (; n < list.Length; ++n)
                results[n] = list[n];
        }
        for (int m = 0; m < values.Length; ++m)
        {
            results[n] = values[m];
            ++n;
        }
        return results;
    }

    public static T[] RemoveAt<T>(this T[] list, int index)
    {
        if (list == null) return new T[0];
        if (index >= list.Length) return list;
        int m = 0;
        T[] results = new T[list.Length - 1];
        for (int n = 0; n < list.Length; ++n)
        {
            if (n != index)
            {
                results[m] = list[n];
                ++m;
            }
        }
        return results;
    }

    public static T[] InsertBefore<T>(this T[] list, T value, int index)
    {
        if (list == null || index >= list.Length) return list.Add(value);
        int cnt = list.Length;
        T[] results = new T[cnt + 1];
        int m = 0;
        for (int n = 0; n < list.Length; ++n)
        {
            if (n == index)
            {
                results[m] = value;
                ++m;
            }
            results[m] = list[n];
            ++m;
        }
        return results;
    }

    public static T[] InsertAfter<T>(this T[] list, T value, int index)
    {
        if (list == null || index >= list.Length) return list.Add(value);
        int cnt = list.Length;
        T[] results = new T[cnt + 1];
        int m = 0;
        for (int n = 0; n < list.Length; ++n)
        {
            results[m] = list[n];
            ++m;
            if (n == index)
            {
                results[m] = value;
                ++m;
            }
        }
        return results;
    }
}