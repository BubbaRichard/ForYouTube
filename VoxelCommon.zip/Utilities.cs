﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Utilities : MonoBehaviour
{
    public string m_replaceWhat;
    public string m_replaceWith;

    public void DoReplace()
    {
        gameObject.name = gameObject.name.Replace(m_replaceWhat, m_replaceWith);
        int cnt = gameObject.transform.childCount;
        for (int c = 0; c < cnt; ++c)
        {
            gameObject.transform.GetChild(c).gameObject.name =
                gameObject.transform.GetChild(c).gameObject.name.Replace(m_replaceWhat, m_replaceWith);
        }
    }
}
