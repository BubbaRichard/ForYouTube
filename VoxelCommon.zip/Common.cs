﻿#pragma warning disable 0168    // variable declared but not used.
#pragma warning disable 0219    // variable assigned but not used.
#pragma warning disable 0414    // private field assigned but not used.
#pragma warning disable 0649    // public field assigned but not used.
#pragma warning disable 0067
#pragma warning disable UNT0001
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Common
{
    public const byte m_sn0 = (byte)Neighbor.Neighbor0;
    public const byte m_sn1 = (byte)Neighbor.Neighbor1;
    public const byte m_sn2 = (byte)Neighbor.Neighbor2;
    public const byte m_sn3 = (byte)Neighbor.Neighbor3;
    public const byte m_sn4 = (byte)Neighbor.Neighbor4;
    public const byte m_sn5 = (byte)Neighbor.Neighbor5;
    public const byte m_sn6 = (byte)Neighbor.Neighbor6;
    public const byte m_sn7 = (byte)Neighbor.Neighbor7;
    public const byte m_sn01 = (byte)Neighbor.Neighbor01;
    public const byte m_sn12 = (byte)Neighbor.Neighbor12;
    public const byte m_sn23 = (byte)Neighbor.Neighbor23;
    public const byte m_sn30 = (byte)Neighbor.Neighbor30;

    public enum Neighbor : byte
    {
        None = 0,
        Neighbor0,
        Neighbor1,
        Neighbor2,
        Neighbor3,
        Neighbor4,
        Neighbor5,
        Neighbor6,
        Neighbor7,
        Neighbor01,
        Neighbor12,
        Neighbor23,
        Neighbor30,
    }

    [System.Serializable]
    public struct MapLevel
    {
        public int m_maxHeight;
        public int m_generateHeight;
        public int m_seed;
        public int m_worldSize;
        public float m_smoothing;
        public int m_scale;
    }

    public static int GetCRIndex(int c, int r, int stride)
    {
        return (r * stride) + c;
    }

    public static int GetCRIndex(int c, int y, int r, int stride, int size)
    {
        return (y * size) + (r * stride) + c;
    }

    public static void GetCR(int crIndex, int stride, int size, ref int c, ref int y, ref int r)
    {
        float yrem = crIndex / size;
        crIndex -= (int)(yrem * size);
        float zrem = (crIndex / stride);
        zrem -= zrem % 1f;
        float xrem = crIndex - (zrem * stride);
        c = (int)xrem;
        y = (int)yrem;
        r = (int)zrem;
    }

    public static void GetCROut(int crIndex, int stride, int size, out int c, out int y, out int r)
    {
        float yrem = crIndex / size;
        crIndex -= (int)(yrem * size);
        float zrem = (crIndex / stride);
        zrem -= zrem % 1f;
        float xrem = crIndex - (zrem * stride);
        c = (int)xrem;
        y = (int)yrem;
        r = (int)zrem;
    }

    public static void GetCR(int crIndex, int stride, ref int c, ref int r)
    {
        float zrem = (crIndex / stride);
        zrem -= zrem % 1f;
        float xrem = crIndex - (zrem * stride);
        c = (int)xrem;
        r = (int)zrem;
    }

    public static void GetCROut(int crIndex, int stride, out int c, out int r)
    {
        float zrem = (crIndex / stride);
        zrem -= zrem % 1f;
        float xrem = crIndex - (zrem * stride);
        c = (int)xrem;
        r = (int)zrem;
    }
}