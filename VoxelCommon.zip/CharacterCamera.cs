﻿#pragma warning disable 0168    // variable declared but not used.
#pragma warning disable 0219    // variable assigned but not used.
#pragma warning disable 0414    // private field assigned but not used.
#pragma warning disable 0649    // public field assigned but not used.
#pragma warning disable 0067
#pragma warning disable UNT0001
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterCamera : MonoBehaviour
{
    public Camera m_camera;
    public float m_sensitivityX = 15f;
    public float m_sensitivityY = 15f;

    public float m_minimumY = -64f;
    public float m_maximumY = 64f;

    public float m_rotationY = 0f;

    public float m_speed = 6.0f;
    public float m_speedModifier = 2f;
    public float m_jumpSpeed = 8.0f;
    public float m_gravity = 250f;
    public float m_jumpGravity = 125f;
    public float m_currentGravity = 0f;
    private Vector3 m_moveDirection = Vector3.zero;
    public Vector3 m_cameraInitialOffset = Vector3.zero;

    public bool m_jumping;
    public bool m_finishingJump;
    public bool m_wasMoving;

    public bool m_strafeRight;
    public bool m_strafeLeft;
    public bool m_moveForward;
    public bool m_moveBackward;
    public bool m_moveUp;
    public bool m_moveDown;

    public float m_curSpeed = 0f;
    public CharacterController m_controller;

    public bool m_lookAround = true;

    public int m_scrollDelta;
    public int m_minScrollDelta = 0;
    public int m_maxScrollDelta = 5;
    public bool m_trackScrollDelta;


    private void Awake()
    {
        m_currentGravity = m_gravity;
        m_controller = GetComponent<CharacterController>();
    }

    // Start is called before the first frame update
    void Start()
    {
        if (m_camera == null)
            m_camera = Camera.main;
        m_camera.transform.localPosition = m_cameraInitialOffset;
        m_controller = GetComponent<CharacterController>();
    }

    // Update is called once per frame
    void Update()
    {
        bool move = (m_finishingJump || m_wasMoving) || Input.GetKey(KeyCode.W) ||
            m_moveForward || m_moveBackward || Input.GetKey(KeyCode.S);
        m_curSpeed = m_speed;

        float speedModifier = 1f;

        if (Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift))
            speedModifier = m_speedModifier;

        if (Input.GetKey(KeyCode.LeftAlt) ||
            Input.GetKey(KeyCode.RightAlt) ||
            Input.GetKey(KeyCode.S) || m_moveBackward)
            m_curSpeed *= -0.5f;

        m_curSpeed *= speedModifier;

        m_moveDirection = new Vector3(0f, 0f, move ? 1f : 0f);
        if (Input.GetKey(KeyCode.D) || m_strafeRight)
            m_moveDirection.x = 1;
        else if (Input.GetKey(KeyCode.A) || m_strafeLeft)
            m_moveDirection.x = -1;

        m_moveDirection = transform.TransformDirection(m_moveDirection);

        if (!m_finishingJump)
            m_moveDirection *= m_curSpeed;
        else
            m_moveDirection *= m_curSpeed / 2f;

        if ((Input.GetKey(KeyCode.Backspace) && !m_moveUp) || m_moveDown)
            m_moveDirection.y = -m_jumpSpeed;
        else if (!m_finishingJump && Input.GetButton("Jump") || m_moveUp)
        {
            if (!Input.GetKey(KeyCode.LeftControl) || m_moveUp)
            {
                m_moveDirection.y = m_jumpSpeed * speedModifier;
                m_jumping = true;
                m_finishingJump = false;
            }
            else if (!m_moveUp)
                m_moveDirection.y = -m_jumpSpeed * speedModifier;

            m_currentGravity = m_jumpGravity;
        }
        else if (m_jumping && !Input.GetButton("Jump"))
        {
            m_jumping = false;
            m_finishingJump = true;
            m_wasMoving = move;
        }
        else if (m_finishingJump)
        {
            m_currentGravity = m_gravity;
            if (m_controller.isGrounded || m_gravity <= 0f)
                m_wasMoving = m_finishingJump = false;
        }
        else
            m_currentGravity = m_gravity;

        if (m_lookAround && Input.GetMouseButton(1))
        {
            float x = Input.GetAxis("Mouse X");
            float rotationX = transform.localEulerAngles.y + x * m_sensitivityX;
            float y = Input.GetAxis("Mouse Y");
            m_rotationY += y * m_sensitivityY;
            m_rotationY = Mathf.Clamp(m_rotationY, m_minimumY, m_maximumY);

            transform.localEulerAngles = new Vector3(0f, rotationX, 0f);
            m_camera.transform.localEulerAngles = new Vector3(-m_rotationY, 0.0f, 0.0f);
        }
        else if (Input.GetKey(KeyCode.G))
        {
            float x = 0f;
            float rotationX = transform.localEulerAngles.y + x * m_sensitivityX;

            float y = 0.01f;
            m_rotationY += y * m_sensitivityY;
            m_rotationY = Mathf.Clamp(m_rotationY, m_minimumY, m_maximumY);

            transform.localEulerAngles = new Vector3(0f, rotationX, 0f);
            m_camera.transform.localEulerAngles = new Vector3(-m_rotationY, 0f, 0f);
        }
        else if (Input.GetKey(KeyCode.H))
        {
            float x = 0f;
            float rotationX = transform.localEulerAngles.y + x * m_sensitivityX;

            float y = -0.01f;
            m_rotationY += y * m_sensitivityY;
            m_rotationY = Mathf.Clamp(m_rotationY, m_minimumY, m_maximumY);

            transform.localEulerAngles = new Vector3(0f, rotationX, 0f);
            m_camera.transform.localEulerAngles = new Vector3(-m_rotationY, 0f, 0f);
        }

        if (m_jumping && m_controller.isGrounded)
            m_jumping = false;

        if (m_currentGravity != 0f)
            m_moveDirection.y -= m_currentGravity * Time.deltaTime;
        if (m_moveDirection != Vector3.zero)
            m_controller.Move(m_moveDirection * Time.deltaTime);

        if (m_trackScrollDelta && Input.mouseScrollDelta.y != 0f)
        {
            m_scrollDelta += (int)Input.mouseScrollDelta.y;
            m_scrollDelta = m_scrollDelta > m_maxScrollDelta ? m_maxScrollDelta : m_scrollDelta;
            m_scrollDelta = m_scrollDelta < m_minScrollDelta ? m_minScrollDelta : m_scrollDelta;
        }

    }
}