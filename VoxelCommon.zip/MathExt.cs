﻿#pragma warning disable 0168    // variable declared but not used.
#pragma warning disable 0219    // variable assigned but not used.
#pragma warning disable 0414    // private field assigned but not used.
#pragma warning disable 0649    // public field assigned but not used.
#pragma warning disable 0067
#pragma warning disable UNT0001
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class MathExt
{
    public static float Abs(this float v)
    {
        return System.Math.Abs(v);
    }

    public static int Abs(this int v)
    {
        return System.Math.Abs(v);
    }

    public static float Round(this float v, int decimals)
    {
        return (float)System.Math.Round(v, decimals);
    }

    public static bool Between(this float v, float l, float r)
    {
        float sv = v.Round(15);
        float sl = l.Round(15);
        float sr = r.Round(15);
        return (sv >= sl && sv <= sr) || (sv >= sr && sv <= sl);
    }

    public static bool Between(this float v, float l, float r, int decimals)
    {
        float sv = v.Round(decimals);
        float sl = l.Round(decimals);
        float sr = r.Round(decimals);
        return (sv >= sl && sv <= sr) || (sv >= sr && sv <= sl);
    }

    public static int FloorToInt(this float v)
    {
        return (int)System.Math.Floor(v.Round(14));
    }

    public static int CeilingToInt(this float v)
    {
        return (int)System.Math.Ceiling(v.Round(14));
    }

    public static bool ApprEqual(this float v0, float v1, float err = 0.00000005f)
    {
        return v0.Between(v1 - err, v1 + err);
    }

    public static bool ApprEqual(this float v0, float v1, int decimals, float err = 0.00000005f)
    {
        return v0.Between(v1 - err, v1 + err, decimals);
    }

    public static int[] CloneArray(this int[] list)
    {
        if (list != null)
        {
            int[] results = new int[list.Length];
            for (int n = 0; n < list.Length; ++n)
                results[n] = list[n];
            return results;
        }
        return list;
    }

    public static int[] Addition(this int[] list, int value)
    {
        if (list != null)
        {
            for (int n = 0; n < list.Length; ++n)
            {
                list[n] += value;
            }
        }
        return list;
    }
}