﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class HA : MonoBehaviour
{
    public bool m_showGizmos = true;
    public bool m_editMode = true;
    public HAPart[] m_bones;

    public Dictionary<string, string> m_boneNames;

    public Animator m_avatorSource;
    private Animator m_animator;

    public void GetAvatarBones()
    {
        Avatar ava = m_avatorSource.avatar;
        for (int n = 0; n < ava.humanDescription.human.Length; ++n)
        {
            Debug.Log(string.Format("{0}  ---   {1}", ava.humanDescription.human[n].boneName, ava.humanDescription.human[n].humanName));
        }
    }

    public void FetchParts()
    {
        m_bones = GetComponentsInChildren<HAPart>(true);
    }

    public void ListBones()
    {
        m_boneNames = new Dictionary<string, string>();
        m_boneNames["Chest"] = "Bip001 Spine2";
        m_boneNames["Head"] = "Bip001 Head";
        m_boneNames["Hips"] = "Bip001 Pelvis";
        m_boneNames["LeftFoot"] = "Bip001 L Foot";
        m_boneNames["LeftHand"] = "Bip001 L Hand";
        m_boneNames["LeftLowerArm"] = "Bip001 L Forearm";
        m_boneNames["LeftLowerLeg"] = "Bip001 L Calf";
        m_boneNames["LeftShoulder"] = "Bip001 L Clavicle";
        m_boneNames["LeftUpperArm"] = "Bip001 L UpperArm";
        m_boneNames["LeftUpperLeg"] = "Bip001 L Thigh";
        m_boneNames["RightFoot"] = "Bip001 R Foot";
        m_boneNames["RightHand"] = "Bip001 R Hand";
        m_boneNames["RightLowerArm"] = "Bip001 R Forearm";
        m_boneNames["RightLowerLeg"] = "Bip001 R Calf";
        m_boneNames["RightShoulder"] = "Bip001 R Clavicle";
        m_boneNames["RightUpperArm"] = "Bip001 R UpperArm";
        m_boneNames["RightUpperLeg"] = "Bip001 R Thigh";
        m_boneNames["Spine"] = "Bip001 Spine1";

        string[] humanName = HumanTrait.BoneName;
        HumanBone[] humanBones = new HumanBone[m_boneNames.Count];
        int j = 0;
        int i = 0;
        while (i < humanName.Length)
        {
            if (m_boneNames.ContainsKey(humanName[i]))
            {
                HumanBone humanBone = new HumanBone();
                humanBone.humanName = humanName[i];
                humanBone.boneName = m_boneNames[humanName[i]];
                humanBone.limit.useDefaultValues = true;
                humanBones[j++] = humanBone;
            }
            i++;
        }
    }

    public void RequiredBones()
    {
        string[] boneName = HumanTrait.BoneName;
        for (int i = 0; i < HumanTrait.BoneCount; ++i)
        {
            if (HumanTrait.RequiredBone(i))
                Debug.Log(boneName[i]);
        }
    }

    public void CreateAvatar()
    {
        ListBones();
        m_animator = GetComponent<Animator>();
        HumanDescription description = CreateHumanDescription(gameObject);
        Avatar avatar = AvatarBuilder.BuildHumanAvatar(gameObject, description);
        avatar.name = gameObject.name;
        m_animator.avatar = avatar;
    }

    private HumanDescription CreateHumanDescription(GameObject avatarRoot)
    {
        HumanDescription description = new HumanDescription()
        {
            armStretch = 0.05f,
            feetSpacing = 0f,
            hasTranslationDoF = false,
            legStretch = 0.05f,
            lowerArmTwist = 0.5f,
            lowerLegTwist = 0.5f,
            upperArmTwist = 0.5f,
            upperLegTwist = 0.5f,
            skeleton = CreateSkeleton(avatarRoot),
            human = GetRequiredBones(),
        };

        return description;
    }

    private SkeletonBone[] CreateSkeleton(GameObject avatarRoot)
    {
        List<SkeletonBone> skeleton = new List<SkeletonBone>();
        Transform[] avatarTransforms = avatarRoot.GetComponentsInChildren<Transform>();
        foreach(Transform avatarTransform in avatarTransforms)
        {
            SkeletonBone bone = new SkeletonBone()
            {
                name = avatarTransform.name,
                position = avatarTransform.localPosition,
                rotation = avatarTransform.localRotation,
                scale = avatarTransform.localScale
            };
            skeleton.Add(bone);
        }
        return skeleton.ToArray();
    }

    public HumanBone[] GetRequiredBones()
    {
        HumanBone[] bones = new HumanBone[0];
        string[] boneName = HumanTrait.BoneName;
        for (int i = 0; i < HumanTrait.BoneCount; ++i)
        {
            if (HumanTrait.RequiredBone(i))
            {
                HumanBone bone = new HumanBone()
                {
                    boneName = boneName[i],
                    humanName = boneName[i],
                };
                bone.limit.useDefaultValues = true;
                bones = bones.Add(bone);
            }
        }
        bones = bones.Add(new HumanBone()
        {
            boneName = "test",
            humanName = "test",
        });
        return bones;
    }

    public void Preview()
    {
        Vector3[] vertices = new Vector3[0];
        Vector3[] normals = new Vector3[0];
        Vector4[] tangents = new Vector4[0];
        Vector2[] uvs = new Vector2[0];

        int[] faceIndexs = new int[0];

        MeshFilter mf = gameObject.GetComponent<MeshFilter>();
        if (mf == null)
            mf = gameObject.AddComponent<MeshFilter>();
        MeshRenderer mr = gameObject.GetComponent<MeshRenderer>();
        if (mr == null)
            mr = gameObject.AddComponent<MeshRenderer>();

        mr.sharedMaterial = new Material(Shader.Find("Standard"));
        Mesh mesh = new Mesh();
        int maxFi = 0;

        for (int n = 0; n < m_bones.Length; ++n)
        {
            if (m_bones[n].m_part != null)
            {
                Matrix4x4 mat4 = Matrix4x4.TRS(m_bones[n].m_part.transform.position, m_bones[n].m_part.transform.rotation, m_bones[n].m_part.transform.lossyScale);
                MeshFilter srcmf = m_bones[n].m_part.GetComponent<MeshFilter>();
                if (srcmf != null)
                {
                    for (int i = 0; i < srcmf.sharedMesh.vertices.Length; ++i)
                    {
                        vertices = vertices.Add(mat4.MultiplyPoint3x4(srcmf.sharedMesh.vertices[i]));
                    }

                    normals = normals.AddRange(srcmf.sharedMesh.normals);
                    tangents = tangents.AddRange(srcmf.sharedMesh.tangents);
                    uvs = uvs.AddRange(srcmf.sharedMesh.uv);
                    int[] fis = srcmf.sharedMesh.triangles.CloneArray();
                    fis = fis.Addition(maxFi);
                    faceIndexs = faceIndexs.AddRange(fis);
                    maxFi = fis.Max() + 1;
                }
                m_bones[n].m_part.SetActive(false);
            }
        }

        mesh.vertices = vertices;
        mesh.normals = normals;
        mesh.uv = uvs;
        mesh.tangents = tangents;
        mesh.triangles = faceIndexs;
        mf.sharedMesh = mesh;
    }

    public void Process()
    {
        MeshFilter mf = gameObject.GetComponent<MeshFilter>();
        if (mf != null)
            DestroyImmediate(mf);
        MeshRenderer mr = gameObject.GetComponent<MeshRenderer>();
        if (mr != null)
            DestroyImmediate(mr);

        Transform firstChild = gameObject.transform.GetChild(0);

        Transform[] bones = new Transform[m_bones.Length];
        Matrix4x4[] bindPoses = new Matrix4x4[m_bones.Length];
        BoneWeight[] weights = new BoneWeight[0];
        Vector3[] vertices = new Vector3[0];
        Vector3[] normals = new Vector3[0];
        Vector4[] tangents = new Vector4[0];
        Vector2[] uvs = new Vector2[0];
        int[] faceIndexs = new int[0];
        int[] rightEyeFi = new int[0];
        int[] leftEyeFi = new int[0];

        SkinnedMeshRenderer rend = gameObject.GetComponent<SkinnedMeshRenderer>();
        if (rend == null)
            rend = gameObject.AddComponent<SkinnedMeshRenderer>();
        rend.sharedMaterials = new Material[3];
        rend.sharedMaterial = new Material(Shader.Find("Standard"));

        Mesh mesh = new Mesh();
        int maxFi = 0;
        int boneIndex = 0;
        int boneVn = 0;

        for (int n = 0; n < m_bones.Length; ++n)
        {
            bones[boneIndex] = new GameObject(m_bones[n].m_boneName).transform;
            bones[boneIndex].localRotation = Quaternion.identity;
            bones[boneIndex].localPosition = m_bones[n].m_anchor;
            bindPoses[boneIndex] = bones[boneIndex].worldToLocalMatrix * transform.localToWorldMatrix;

            if (m_bones[n].m_part != null)
            {
                Matrix4x4 mat4 = Matrix4x4.TRS(m_bones[n].m_part.transform.position, m_bones[n].m_part.transform.rotation,
                    m_bones[n].m_part.transform.lossyScale);
                MeshFilter srcmf = m_bones[n].m_part.GetComponent<MeshFilter>();
                if (srcmf != null)
                {
                    for (int i = 0; i < srcmf.sharedMesh.vertices.Length; ++i)
                    {
                        vertices = vertices.Add(mat4.MultiplyPoint3x4(srcmf.sharedMesh.vertices[i]));
                        weights = weights.Add(new BoneWeight());
                        weights[boneVn].boneIndex0 = boneIndex;
                        weights[boneVn].weight0 = 1;
                        ++boneVn;
                    }

                    normals = normals.AddRange(srcmf.sharedMesh.normals);
                    tangents = tangents.AddRange(srcmf.sharedMesh.tangents);
                    uvs = uvs.AddRange(srcmf.sharedMesh.uv);

                    if (m_bones[n].m_boneName == "RightEye")
                    {
                        int[] fis = srcmf.sharedMesh.triangles.CloneArray();
                        fis = fis.Addition(maxFi);
                        rightEyeFi = rightEyeFi.AddRange(fis);
                        maxFi = fis.Max() + 1;
                    }
                    else if (m_bones[n].m_boneName == "LeftEye")
                    {
                        int[] fis = srcmf.sharedMesh.triangles.CloneArray();
                        fis = fis.Addition(maxFi);
                        leftEyeFi = leftEyeFi.AddRange(fis);
                        maxFi = fis.Max() + 1;
                    }
                    else
                    {
                        int[] fis = srcmf.sharedMesh.triangles.CloneArray();
                        fis = fis.Addition(maxFi);
                        faceIndexs = faceIndexs.AddRange(fis);
                        maxFi = fis.Max() + 1;
                    }
                }

                bones[boneIndex].parent = transform;
                if (m_bones[n].transform.parent != null)
                {
                    HAPart parent = m_bones[boneIndex].transform.parent.GetComponent<HAPart>();
                    if (parent != null)
                    {
                        int parentIndex = System.Array.IndexOf(m_bones, parent);
                        if (parentIndex > -1)
                        {
                            bones[boneIndex].SetParent(bones[parentIndex]);
                        }
                    }
                }
                else
                {
                    bones[boneIndex].SetParent(transform);
                }
            }
            ++boneIndex;

            m_bones[n].gameObject.SetActive(false);
        }

        mesh.subMeshCount = 3;
        mesh.vertices = vertices;
        mesh.normals = normals;
        mesh.uv = uvs;
        mesh.tangents = tangents;
        mesh.SetTriangles(faceIndexs, 0);
        mesh.SetTriangles(rightEyeFi, 1);
        mesh.SetTriangles(leftEyeFi, 2);
        mesh.boneWeights = weights;
        rend.bones = bones;
        mesh.bindposes = bindPoses;
        mesh.RecalculateBounds();

        rend.sharedMesh = mesh;

        if (firstChild != null)
            firstChild.SetParent(null);
    }
}
