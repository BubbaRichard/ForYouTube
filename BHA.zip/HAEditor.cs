﻿#pragma warning disable 0168 // variable declared but not used.
#pragma warning disable 0219 // variable assigned but not used.
#pragma warning disable 0414 // private field assigned but not used.
#pragma warning disable 0649 // public field assigned but not used.
#pragma warning disable UNT0001
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(HA))]
public class HAEditor : Editor
{
    public HA m_ha;

    public override void OnInspectorGUI()
    {
        if (GUILayout.Button("get avatar bones"))
            m_ha.GetAvatarBones();
        if (GUILayout.Button("print required bones"))
            m_ha.RequiredBones();
        if (GUILayout.Button("preview"))
            m_ha.Preview();
        if (GUILayout.Button("fetch parts"))
            m_ha.FetchParts();
        if (GUILayout.Button("process"))
            m_ha.Process();
        if (GUILayout.Button("create avatar"))
            m_ha.CreateAvatar();
        DrawDefaultInspector();
    }

    private void OnEnable()
    {
        m_ha = (HA)target;
    }


    private void OnSceneGUI()
    {
        if (m_ha.m_showGizmos && m_ha.m_bones != null)
        {
            for (int n = 0; n < m_ha.m_bones.Length; ++n)
            {
                if (Handles.Button(m_ha.m_bones[n].m_anchor, Quaternion.identity, 0.03125f, 0.0325f, Handles.SphereHandleCap))
                {
                    ShowMenu(n);
                }
                if (m_ha.m_bones[n].m_selected)
                {
                    EditPoint(ref m_ha.m_bones[n].m_anchor);
                }
            }
        }
    }

    private void ShowMenu(int n)
    {
        GenericMenu menu = new GenericMenu();
        menu.AddItem(new GUIContent("flip select"), false, FlipSelect, n);
        menu.ShowAsContext();
    }

    private void FlipSelect(object data)
    {
        int n = (int)data;
        m_ha.m_bones[n].m_selected = !m_ha.m_bones[n].m_selected;
    }

    private bool EditPoint(ref Vector3 pnt)
    {
        Matrix4x4 mat4 = Matrix4x4.TRS(m_ha.transform.position,
            m_ha.transform.rotation, m_ha.transform.lossyScale);

        Vector3 v3 = Handles.PositionHandle(mat4.MultiplyPoint3x4(pnt), Quaternion.identity);
        if (GUI.changed)
        {
            Undo.RecordObject(m_ha, "EditPoint");
            v3 = mat4.inverse.MultiplyPoint3x4(v3);
            pnt.x = v3.x;
            pnt.y = v3.y;
            pnt.z = v3.z;
            return true;
        }
        return false;
    }
}