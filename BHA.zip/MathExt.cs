﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class MathExt
{
    public static T[] Add<T>(this T[] list, T value)
    {
        int cnt = list == null ? 0 : list.Length;
        T[] results = new T[cnt + 1];
        int n = 0;
        if (list != null)
        {
            for (; n < list.Length; ++n)
                results[n] = list[n];
        }
        results[n] = value;
        return results;
    }

    public static T[] AddRange<T>(this T[] list, T[] values)
    {
        int cnt = list == null ? 0 : list.Length;
        T[] results = new T[cnt + values.Length];
        int n = 0;
        if (list != null)
        {
            for (; n < list.Length; ++n)
                results[n] = list[n];
        }
        for (int m = 0; m < values.Length; ++m)
        {
            results[n] = values[m];
            ++n;
        }
        return results;
    }

    public static int[] Addition(this int[] list, int value)
    {
        if (list != null)
        {
            for (int n = 0; n < list.Length; ++n)
                list[n] += value;
        }
        return list;
    }

    public static int[] CloneArray(this int[] list)
    {
        if (list != null)
        {
            int[] results = new int[list.Length];
            for (int n = 0; n < list.Length; ++n)
                results[n] = list[n];
            return results;
        }
        return list;
    }
}