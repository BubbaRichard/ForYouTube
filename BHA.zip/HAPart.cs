﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HAPart : MonoBehaviour
{
    public bool m_root;
    public bool m_selected;
    public string m_boneName;
    public string m_humanName;
    public GameObject m_part;
    public Vector3 m_anchor;
}
