﻿#pragma warning disable 0168 // variable declared but not used.
#pragma warning disable 0219 // variable assigned but not used.
#pragma warning disable 0414 // private field assigned but not used.
#pragma warning disable 0649 // public field assigned but not used.
#pragma warning disable UNT0001
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(HAParts))]
public class HAPartsEditor : Editor
{
    private HAParts m_parts;

    public override void OnInspectorGUI()
    {
        if (GUILayout.Button("show all"))
            m_parts.ShowAll();
        DrawDefaultInspector();
    }

    private void OnEnable()
    {
        m_parts = (HAParts)target;
    }
}
