﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HAParts : MonoBehaviour
{
    public void ShowAll()
    {
        HAPart[] parts = GetComponentsInChildren<HAPart>(true);
        for (int n = 0; n < parts.Length; ++n)
            parts[n].gameObject.SetActive(true);
    }
}
