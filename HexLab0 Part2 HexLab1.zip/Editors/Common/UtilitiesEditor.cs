﻿#pragma warning disable 0168	// variable declared but not used.
#pragma warning disable 0219	// variable assigned but not used.
#pragma warning disable 0414	// private field assigned but not used.
#pragma warning disable 0649	// public field assigned but not used.
#pragma warning disable 0067
#pragma warning disable UNT0001
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(Utilities))]
public class UtilitiesEditor : Editor
{
    private Utilities m_utilies;
    public override void OnInspectorGUI()
    {
        if (GUILayout.Button("do replace"))
            m_utilies.DoReplace();
        DrawDefaultInspector();
    }

    private void OnEnable()
    {
        m_utilies = (Utilities)target;
    }
}
