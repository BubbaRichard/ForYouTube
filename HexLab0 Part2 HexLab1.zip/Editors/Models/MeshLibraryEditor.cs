﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(MeshLibrary))]
public class MeshLibraryEditor : Editor
{
    public MeshLibrary m_meshLibrary;
    public override void OnInspectorGUI()
    {
        if (GUILayout.Button("refresh prefab"))
            m_meshLibrary.RefreshPrefab();
        DrawDefaultInspector();
    }

    private void OnEnable()
    {
        m_meshLibrary = (MeshLibrary)target;
    }
}
