﻿#pragma warning disable 0168	// variable declared but not used.
#pragma warning disable 0219	// variable assigned but not used.
#pragma warning disable 0414	// private field assigned but not used.
#pragma warning disable 0649	// public field assigned but not used.
#pragma warning disable 0067
#pragma warning disable UNT0001
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

public class OppositesPartWin : EditorWindow
{
    private OppositesPart m_oppositesPart;
    private MeshPart m_meshPart;
    private Vector2 m_scroll;
    private MeshPart m_setAll;
    private bool m_hideNone;

    public static void ShowWindow()
    {
        OppositesPartWin win = GetWindow<OppositesPartWin>();
        win.titleContent = new GUIContent("OppositesPartWin");
    }

    private void OnEnable()
    {
        GameObject selectedObject = Selection.activeObject as GameObject;
        if (selectedObject != null)
        {
            m_oppositesPart = selectedObject.GetComponent<OppositesPart>();
            m_meshPart = selectedObject.GetComponent<MeshPart>();
        }
    }

    private void OnSelectionChange()
    {
        OnEnable();
    }

    private void OnGUI()
    {
        if (m_oppositesPart == null)
        {
            OnEnable();
            EditorGUILayout.LabelField("add a oppositespart");
            return;
        }
        if (m_meshPart == null)
        {
            OnEnable();
            EditorGUILayout.LabelField("select a meshpart");
            return;
        }

        if (m_oppositesPart.m_opposites != null && m_meshPart.m_parent != null)
        {
            m_hideNone = EditorGUILayout.ToggleLeft("hide none", m_hideNone);
            m_setAll = (MeshPart)EditorGUILayout.ObjectField(m_setAll, typeof(MeshPart), true);
            m_scroll = EditorGUILayout.BeginScrollView(m_scroll);
            for (int n = 0; n < m_oppositesPart.m_opposites.Length; ++n)
            {
                if (m_setAll != null)
                {
                    m_oppositesPart.m_opposites[n] = m_setAll;
                }
                else if (!m_hideNone || m_oppositesPart.m_opposites[n] != m_meshPart.m_parent.m_noneSide)
                {
                    string shape = m_meshPart.m_parent.m_shapes.m_shapes[n].name;
                    EditorGUILayout.BeginHorizontal("box");
                    m_oppositesPart.m_opposites[n] =
                        (MeshPart)EditorGUILayout.ObjectField(shape, m_oppositesPart.m_opposites[n], typeof(MeshPart), true);
                    if (GUILayout.Button("n", GUILayout.Width(22f)))
                        m_oppositesPart.m_opposites[n] = m_meshPart.m_parent.m_noneSide;
                    if (GUILayout.Button("d", GUILayout.Width(22f)))
                        m_oppositesPart.m_opposites[n] = m_meshPart;
                    EditorGUILayout.EndHorizontal();
                    GUILayout.Space(7f);
                }
            }
            EditorGUILayout.EndScrollView();
            m_setAll = null;
        }
    }
}