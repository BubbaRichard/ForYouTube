﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(MeshShapes))]
[CanEditMultipleObjects]
public class MeshShapesEditor : Editor
{
    private MeshShapes m_shapes;

    public override void OnInspectorGUI()
    {
        if (GUILayout.Button("new shape"))
            m_shapes.NewShape();
        if (GUILayout.Button("refresh shapes"))
            m_shapes.RefreshShapes();
        if (GUILayout.Button("refresh prefab"))
            m_shapes.RefreshPrefab();

        DrawDefaultInspector();
    }

    private void OnEnable()
    {
        m_shapes = (MeshShapes)target;
    }
}