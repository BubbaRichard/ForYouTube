﻿#pragma warning disable 0168	// variable declared but not used.
#pragma warning disable 0219	// variable assigned but not used.
#pragma warning disable 0414	// private field assigned but not used.
#pragma warning disable 0649	// public field assigned but not used.
#pragma warning disable 0067
#pragma warning disable UNT0001
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(MeshPart))]
[CanEditMultipleObjects]
public class MeshPartEditor : Editor
{
    private MeshPart m_meshPart;
    public override void OnInspectorGUI()
    {
        if (GUILayout.Button("editorwindow"))
            MeshPartWin.ShowWindow();
        if (GUILayout.Button("refresh mesh"))
            m_meshPart.RefreshMesh();
        if (GUILayout.Button("clear mesh"))
            m_meshPart.ClearMesh();

        if (m_meshPart.m_import != null && GUILayout.Button("import add"))
            m_meshPart.ImportMesh();

        DrawDefaultInspector();
    }

    private void OnEnable()
    {
        m_meshPart = (MeshPart)target;
    }
}