﻿#pragma warning disable 0168	// variable declared but not used.
#pragma warning disable 0219	// variable assigned but not used.
#pragma warning disable 0414	// private field assigned but not used.
#pragma warning disable 0649	// public field assigned but not used.
#pragma warning disable 0067
#pragma warning disable UNT0001
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using static Common;

public class MeshPartWin : EditorWindow
{
    private MeshPart m_meshPart;
    private Vector2 m_scroll;

    public static void ShowWindow()
    {
        MeshPartWin wnd = GetWindow<MeshPartWin>();
        wnd.titleContent = new GUIContent("MeshPartWin");
    }

    private void OnEnable()
    {
        GameObject selectedObject = Selection.activeObject as GameObject;
        if (selectedObject != null)
        {
            m_meshPart = selectedObject.GetComponent<MeshPart>();
        }
    }

    private void OnSelectionChange()
    {
        OnEnable();
    }

    private void OnGUI()
    {
        if (m_meshPart == null)
        {
            OnEnable();
            EditorGUILayout.LabelField("select a meshpart");
            return;
        }

        m_meshPart.m_side = (Neighbor)EditorGUILayout.EnumPopup(m_meshPart.m_side);
        m_meshPart.m_source = (GameObject)EditorGUILayout.ObjectField(m_meshPart.m_source, typeof(GameObject), true);

        if (m_meshPart.m_source != null)
        {
            if (GUILayout.Button("collect available"))
                CollectAvailable();
            if (m_meshPart.m_parts != null)
            {
                if (EditorGUILayout.DropdownButton(new GUIContent("options"), FocusType.Passive))
                {
                    GenericMenu menu = new GenericMenu();
                    menu.AddItem(new GUIContent("import"), false, ImportSelected);
                    menu.AddItem(new GUIContent("select all"), false, () =>
                    {
                        for (int n = 0; n < m_meshPart.m_parts.Length; ++n)
                        {
                            m_meshPart.m_parts[n].m_selected = true;
                        }
                    });
                    menu.AddItem(new GUIContent("deselect all"), false, () =>
                    {
                        for (int n = 0; n < m_meshPart.m_parts.Length; ++n)
                        {
                            m_meshPart.m_parts[n].m_selected = false;
                        }
                    });
                    menu.ShowAsContext();
                }

                m_scroll = EditorGUILayout.BeginScrollView(m_scroll);
                for (int n = 0; n < m_meshPart.m_parts.Length; ++n)
                {
                    EditorGUILayout.BeginVertical("box");
                    m_meshPart.m_parts[n].m_selected =
                        EditorGUILayout.ToggleLeft(m_meshPart.m_parts[n].m_key,
                        m_meshPart.m_parts[n].m_selected);
                    EditorGUILayout.EndVertical();
                }
                EditorGUILayout.EndScrollView();
            }
        }
    }

    private void ImportSelected()
    {
        Vector3[] vertices = null;
        Vector3[] normals = null;
        Vector4[] tangents = null;
        Vector2[] uvs = null;
        int[] faceIndexs = null;

        int lastFi = 0;
        for (int n = 0; n < m_meshPart.m_parts.Length; ++n)
        {
            if (m_meshPart.m_parts[n].m_selected)
            {
                vertices = vertices.AddRange(m_meshPart.m_parts[n].m_mf.sharedMesh.vertices);
                normals = normals.AddRange(m_meshPart.m_parts[n].m_mf.sharedMesh.normals);
                uvs = uvs.AddRange(m_meshPart.m_parts[n].m_mf.sharedMesh.uv);
                tangents = tangents.AddRange(m_meshPart.m_parts[n].m_mf.sharedMesh.tangents);
                int[] fis = m_meshPart.m_parts[n].m_mf.sharedMesh.triangles;
                fis = fis.Addition(lastFi);
                faceIndexs = faceIndexs.AddRange(fis);
                lastFi = fis.Max() + 1;
            }
        }

        m_meshPart.m_vertices = vertices;
        m_meshPart.m_normals = normals;
        m_meshPart.m_uvs = uvs;
        m_meshPart.m_tangents = tangents;
        m_meshPart.m_faceIndexs = faceIndexs;
        m_meshPart.RefreshMesh();
        if (PrefabUtility.IsPartOfAnyPrefab(m_meshPart.gameObject))
        {
            UnityEditor.SceneManagement.EditorSceneManager.MarkAllScenesDirty();
            EditorUtility.SetDirty(m_meshPart);
            PrefabUtility.ApplyPrefabInstance(m_meshPart.gameObject, InteractionMode.AutomatedAction);
        }
    }

    private void CollectAvailable()
    {
        m_meshPart.m_parts = new MeshPart.AvailablePart[0];
        MeshFilter[] mfs = m_meshPart.m_source.GetComponentsInChildren<MeshFilter>();
        if (mfs != null)
        {
            for (int n = 0; n < mfs.Length; ++n)
            {
                m_meshPart.m_parts = m_meshPart.m_parts.Add(new MeshPart.AvailablePart()
                {
                    m_key = mfs[n].name,
                    m_selected = true,
                    m_mf = mfs[n]
                });
            }
        }
    }
}