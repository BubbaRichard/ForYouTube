﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(OppositesPart))]
public class OppositesPartEditor : Editor
{
    private OppositesPart m_oppositesPart;
    public override void OnInspectorGUI()
    {
        if (GUILayout.Button("editor window"))
            OppositesPartWin.ShowWindow();
        DrawDefaultInspector();
    }

    private void OnEnable()
    {
        m_oppositesPart = (OppositesPart)target;
    }
}