﻿#pragma warning disable 0168	// variable declared but not used.
#pragma warning disable 0219	// variable assigned but not used.
#pragma warning disable 0414	// private field assigned but not used.
#pragma warning disable 0649	// public field assigned but not used.
#pragma warning disable 0067
#pragma warning disable UNT0001
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;


[CustomEditor(typeof(MeshShape))]
[CanEditMultipleObjects]
public class MeshShapeEditor : Editor
{
    private MeshShape m_shape;
    public override void OnInspectorGUI()
    {
        m_shape.m_takeParts = (GameObject)EditorGUILayout.ObjectField(m_shape.m_takeParts, typeof(GameObject), true);
        if (GUILayout.Button("take parts"))
            m_shape.TakeParts();

        DrawDefaultInspector();
    }

    private void OnEnable()
    {
        m_shape = (MeshShape)target;
    }
}