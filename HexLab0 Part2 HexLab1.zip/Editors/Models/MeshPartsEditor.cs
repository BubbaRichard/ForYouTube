﻿#pragma warning disable 0168	// variable declared but not used.
#pragma warning disable 0219	// variable assigned but not used.
#pragma warning disable 0414	// private field assigned but not used.
#pragma warning disable 0649	// public field assigned but not used.
#pragma warning disable 0067
#pragma warning disable UNT0001
using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(MeshParts))]
[CanEditMultipleObjects]
public class MeshPartsEditor : Editor
{
    private MeshParts m_parts;
    public override void OnInspectorGUI()
    {
        if (GUILayout.Button("refresh part"))
            m_parts.RefreshParts();
        if (GUILayout.Button("clear meshes"))
            m_parts.ClearMeshes();
        if (GUILayout.Button("new part"))
            m_parts.NewPart();
        if (GUILayout.Button("refresh prefab"))
            m_parts.RefreshParts();
        if (GUILayout.Button("refresh opposites"))
            m_parts.UpdateOpposites();
        DrawDefaultInspector();
    }

    private void OnEnable()
    {
        m_parts = (MeshParts)target;
    }
}
