﻿#pragma warning disable 0168    // variable declared but not used.
#pragma warning disable 0219    // variable assigned but not used.
#pragma warning disable 0414    // private field assigned but not used.
#pragma warning disable 0649    // public field assigned but not used.
#pragma warning disable 0067
#pragma warning disable UNT0001
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class Vector3Ext
{
    public static Vector2[] CloneArray(this Vector2[] list)
    {
        int cnt = list != null ? list.Length : 0;
        Vector2[] results = new Vector2[cnt];
        if (list != null)
        {
            for (int n = 0; n < list.Length; ++n)
                results[n] = list[n];
        }
        return results;
    }

    public static Vector3[] CloneArray(this Vector3[] list)
    {
        int cnt = list != null ? list.Length : 0;
        Vector3[] results = new Vector3[cnt];
        if (list != null)
        {
            for (int n = 0; n < list.Length; ++n)
                results[n] = list[n];
        }
        return results;
    }

    public static float MaxX(this Vector2[] list)
    {
        float value = float.MinValue;
        for (int n = 0; n < list.Length; ++n)
        {
            if (list[n].x > value)
                value = list[n].x;
        }
        if (value == float.MinValue)
            value = 0f;
        return value;
    }

    public static float MinX(this Vector2[] list)
    {
        float value = float.MaxValue;
        for (int n = 0; n < list.Length; ++n)
        {
            if (list[n].x < value)
                value = list[n].x;
        }
        if (value == float.MaxValue)
            value = 0f;
        return value;
    }

    public static float MaxY(this Vector2[] list)
    {
        float value = float.MinValue;
        for (int n = 0; n < list.Length; ++n)
        {
            if (list[n].y > value)
                value = list[n].y;
        }
        if (value == float.MinValue)
            value = 0f;
        return value;
    }

    public static float MinY(this Vector2[] list)
    {
        float value = float.MaxValue;
        for (int n = 0; n < list.Length; ++n)
        {
            if (list[n].y < value)
                value = list[n].y;
        }
        if (value == float.MaxValue)
            value = 0f;
        return value;
    }

    public static float MaxX(this Vector3[] list)
    {
        float value = float.MinValue;
        for (int n = 0; n < list.Length; ++n)
        {
            if (list[n].x > value)
                value = list[n].x;
        }
        if (value == float.MinValue)
            value = 0f;
        return value;
    }

    public static float MinX(this Vector3[] list)
    {
        float value = float.MaxValue;
        for (int n = 0; n < list.Length; ++n)
        {
            if (list[n].x < value)
                value = list[n].x;
        }
        if (value == float.MaxValue)
            value = 0f;
        return value;
    }

    public static float MaxY(this Vector3[] list)
    {
        float value = float.MinValue;
        for (int n = 0; n < list.Length; ++n)
        {
            if (list[n].y > value)
                value = list[n].y;
        }
        if (value == float.MinValue)
            value = 0f;
        return value;
    }

    public static float MinY(this Vector3[] list)
    {
        float value = float.MaxValue;
        for (int n = 0; n < list.Length; ++n)
        {
            if (list[n].y < value)
                value = list[n].y;
        }
        if (value == float.MaxValue)
            value = 0f;
        return value;
    }

    public static float MaxZ(this Vector3[] list)
    {
        float value = float.MinValue;
        for (int n = 0; n < list.Length; ++n)
        {
            if (list[n].z > value)
                value = list[n].z;
        }
        if (value == float.MinValue)
            value = 0f;
        return value;
    }

    public static float MinZ(this Vector3[] list)
    {
        float value = float.MaxValue;
        for (int n = 0; n < list.Length; ++n)
        {
            if (list[n].z < value)
                value = list[n].z;
        }
        if (value == float.MaxValue)
            value = 0f;
        return value;
    }

    public static float Width(this Vector2[] list)
    {
        float mxx = list.MaxX();
        float mnx = list.MinX();
        return mxx - mnx;
    }

    public static float Height(this Vector2[] list)
    {
        float mxy = list.MaxY();
        float mny = list.MinY();
        return mxy - mny;
    }

    public static float Width(this Vector3[] list)
    {
        float mxx = list.MaxX();
        float mnx = list.MinX();
        return mxx - mnx;
    }

    public static float Height(this Vector3[] list)
    {
        float mxy = list.MaxY();
        float mny = list.MinY();
        return mxy - mny;
    }

    public static float Depth(this Vector3[] list)
    {
        float mxz = list.MaxZ();
        float mnz = list.MinZ();
        return mxz - mnz;
    }

    public static float CenterX(this Vector2[] list)
    {
        float mnx = list.MinX();
        float mxx = list.MaxX();
        float cx = mnx + ((mxx - mnx) / 2f);
        return cx;
    }

    public static float CenterY(this Vector2[] list)
    {
        float mny = list.MinY();
        float mxy = list.MaxY();
        float cy = mny + ((mxy - mny) / 2f);
        return cy;
    }

    public static float CenterX(this Vector3[] list)
    {
        float mnx = list.MinX();
        float mxx = list.MaxX();
        float cx = mnx + ((mxx - mnx) / 2f);
        return cx;
    }

    public static float CenterY(this Vector3[] list)
    {
        float mny = list.MinY();
        float mxy = list.MaxY();
        float cy = mny + ((mxy - mny) / 2f);
        return cy;
    }

    public static float CenterZ(this Vector3[] list)
    {
        float mnz = list.MinZ();
        float mxz = list.MaxZ();
        float cz = mnz + ((mxz - mnz) / 2f);
        return cz;
    }

    public static Vector2 Center(this Vector2[] list)
    {
        return new Vector2(list.CenterX(), list.CenterY());
    }

    public static Vector3 Center(this Vector3[] list)
    {
        return new Vector3(list.CenterX(), list.CenterY(), list.CenterZ());
    }
}