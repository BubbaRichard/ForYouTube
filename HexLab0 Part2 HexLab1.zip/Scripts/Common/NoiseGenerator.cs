﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NoiseGenerator
{
    public static readonly NoiseGenerator m_instance = new NoiseGenerator();
    public static NoiseGenerator I
    {
        get
        {
            return m_instance;
        }
    }

    public float GetNoise(float x, float z, int seed, int worldSize, float smooth,
        float xorg, float zorg)
    {
        float v = Mathf.PerlinNoise(((xorg + x) / worldSize * smooth) * seed,
            ((zorg + z) / worldSize * smooth) * seed);
        return v;
    }
}