﻿#pragma warning disable 0168	// variable declared but not used.
#pragma warning disable 0219	// variable assigned but not used.
#pragma warning disable 0414	// private field assigned but not used.
#pragma warning disable 0649	// public field assigned but not used.
#pragma warning disable 0067
#pragma warning disable UNT0001
using UnityEngine;

#if UNITY_EDITOR
public class MeshShape : MonoBehaviour
{
    public int m_indexInParent;
    public int m_shapeProcessor;
    public MeshShapes m_parent;
    public MeshPart[] m_parts;
    public GameObject m_takeParts;

    public byte[] m_matNs;
    public int[] m_matSource;

    public void TakeParts()
    {
        if (m_takeParts != null)
            m_parts = m_takeParts.GetComponentsInChildren<MeshPart>();
        else
            m_parts = new MeshPart[0];
    }
}
#endif