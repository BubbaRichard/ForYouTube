﻿#pragma warning disable 0168	// variable declared but not used.
#pragma warning disable 0219	// variable assigned but not used.
#pragma warning disable 0414	// private field assigned but not used.
#pragma warning disable 0649	// public field assigned but not used.
#pragma warning disable 0067
#pragma warning disable UNT0001
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class MeshShapes : MonoBehaviour
{
    public MeshShape[] m_shapes;

#if UNITY_EDITOR
    public void NewShape()
    {
        GameObject goNew = new GameObject("new shape");
        goNew.transform.SetParent(transform);
        goNew.AddComponent<MeshShape>();
        RefreshPrefab();
    }

    public void RefreshPrefab()
    {
        if (PrefabUtility.IsPartOfPrefabAsset(gameObject))
        {
            UnityEditor.SceneManagement.EditorSceneManager.MarkAllScenesDirty();
            EditorUtility.SetDirty(gameObject);
            PrefabUtility.ApplyPrefabInstance(gameObject, InteractionMode.AutomatedAction);
        }
    }

    public void RefreshShapes()
    {
        m_shapes = GetComponentsInChildren<MeshShape>();
        int index = 0;
        for (int n = 0; n < m_shapes.Length; ++n)
        {
            m_shapes[n].m_parent = this;
            m_shapes[n].m_indexInParent = index;
            if (m_shapes[n].m_parts != null)
            {
                System.Array.Resize(ref m_shapes[n].m_matNs, m_shapes[n].m_parts.Length);
                int preCnt = m_shapes[n].m_matSource != null ? m_shapes[n].m_matSource.Length : 0;
                System.Array.Resize(ref m_shapes[n].m_matSource, m_shapes[n].m_parts.Length);
                for (int c = preCnt; c < m_shapes[n].m_matSource.Length; ++c)
                {
                    m_shapes[n].m_matSource[c] = 0;
                }
            }
            ++index;
        }
    }

#endif
}