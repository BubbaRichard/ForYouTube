﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OppositesPart : MonoBehaviour
{
    public MeshPart[] m_opposites;
}
