﻿#pragma warning disable 0168	// variable declared but not used.
#pragma warning disable 0219	// variable assigned but not used.
#pragma warning disable 0414	// private field assigned but not used.
#pragma warning disable 0649	// public field assigned but not used.
#pragma warning disable 0067
#pragma warning disable UNT0001
using UnityEditor;
using UnityEngine;

#if UNITY_EDITOR
public class MeshParts : MonoBehaviour
{
    public GameObject m_currentSides;
    public GameObject[] m_sidesParents;
    public MeshPart[] m_parts;
    public MeshPart m_noneSide;
    public Material m_defaultMaterial;

    public MeshShapes m_shapes;

    public void RefreshPrefab()
    {
        if (PrefabUtility.IsPartOfPrefabAsset(gameObject))
        {
            UnityEditor.SceneManagement.EditorSceneManager.MarkAllScenesDirty();
            EditorUtility.SetDirty(gameObject);
            PrefabUtility.ApplyPrefabInstance(gameObject, InteractionMode.AutomatedAction);
        }
    }

    public void RefreshParts()
    {
        m_parts = m_currentSides.GetComponentsInChildren<MeshPart>();
        int index = 0;
        for (int n = 0; n < m_parts.Length; ++n)
        {
            m_parts[n].m_parent = this;
            m_parts[n].m_indexInParent = index;
            ++index;
        }

        if (m_sidesParents != null)
        {
            for (int i = 0; i < m_sidesParents.Length; ++i)
            {
                MeshPart[] parts = m_sidesParents[i].GetComponentsInChildren<MeshPart>();
                m_parts = m_parts.AddRange(parts);
                for (int n = 0; n < parts.Length; ++n)
                {
                    parts[n].m_parent = this;
                    parts[n].m_indexInParent = index;
                    ++index;
                }
            }
        }
    }

    public void ClearMeshes()
    {
        ClearMeshes(m_currentSides);
        if (m_sidesParents != null)
        {
            for (int n = 0; n < m_sidesParents.Length; ++n)
                ClearMeshes(m_sidesParents[n]);
        }
    }

    private void ClearMeshes(GameObject source)
    {
        MeshPart[] parts = source.GetComponentsInChildren<MeshPart>();
        for (int n = 0; n < parts.Length; ++n)
            parts[n].ClearMesh();
    }

    public void NewPart()
    {
        GameObject goNew = new GameObject("new");
        goNew.transform.SetParent(m_currentSides.transform);
        MeshPart part = goNew.AddComponent<MeshPart>();
        part.m_material = m_defaultMaterial;
        part.m_parent = this;

        if (PrefabUtility.IsPartOfPrefabAsset(gameObject))
        {
            UnityEditor.SceneManagement.EditorSceneManager.MarkAllScenesDirty();
            EditorUtility.SetDirty(gameObject);
            PrefabUtility.ApplyPrefabInstance(gameObject, InteractionMode.AutomatedAction);
        }
    }

    public void UpdateOpposites()
    {
        UpdateOpposites(m_currentSides);
        if (m_sidesParents != null)
        {
            for (int n = 0; n < m_sidesParents.Length; ++n)
            {
                UpdateOpposites(m_sidesParents[n]);
            }
        }
    }

    private void UpdateOpposites(GameObject source)
    {
        m_shapes.RefreshShapes();
        MeshPart[] parts = source.GetComponentsInChildren<MeshPart>();
        for (int n = 0; n < parts.Length; ++n)
        {
            parts[n].m_parent = this;
            OppositesPart op = m_parts[n].GetComponent<OppositesPart>();
            if (op == null)
                op = parts[n].gameObject.AddComponent<OppositesPart>();
            int preCnt = op.m_opposites != null ? op.m_opposites.Length : 0;
            System.Array.Resize(ref op.m_opposites, m_shapes.m_shapes.Length);
            for (int i = preCnt; i < op.m_opposites.Length; ++i)
            {
                op.m_opposites[i] = parts[n];
            }
            parts[n].m_oppositesPart = op;
        }
    }
}
#endif