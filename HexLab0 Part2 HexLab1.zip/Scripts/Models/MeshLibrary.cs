﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class MeshLibrary : MonoBehaviour
{
    public MeshParts m_meshParts;
    public MeshShapes m_meshShapes;

    public void RefreshPrefab()
    {
        UnityEditor.SceneManagement.EditorSceneManager.MarkAllScenesDirty();
        EditorUtility.SetDirty(gameObject);
        PrefabUtility.ApplyPrefabInstance(gameObject, InteractionMode.AutomatedAction);
    }
}
