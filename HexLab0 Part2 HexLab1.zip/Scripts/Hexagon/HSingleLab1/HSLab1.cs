﻿#pragma warning disable 0168    // variable declared but not used.
#pragma warning disable 0219    // variable assigned but not used.
#pragma warning disable 0414    // private field assigned but not used.
#pragma warning disable 0649    // public field assigned but not used.
#pragma warning disable 0067
#pragma warning disable UNT0001
using UnityEngine;
using UnityEngine.UI;
using static Common;

public class HSLab1 : MonoBehaviour
{
    public const int m_nuggetCount = 16;
    public const int m_levelSize = 256;
    public const int m_verticeLimit = 60000;

    public enum State
    {
        Paused,
        Generate,
        Generating,
        PreEvaluate,
        PreEvaluating,
        Evaluate,
        Evaluating,
        PostEvaluate,
        PostEvaluating,
        CreateMesh0,
        CreatingMesh0,
        CreateMesh1,
        CreatingMesh1,
        Error,
    }
    public State m_state;

    public enum InputMode : byte
    {
        None,
        Place,
        Material,
        Erase,
        Identify,
    }
    public InputMode m_inputMode;

    public MeshLibrary m_meshLibrary;
    public CharacterCamera m_character;
    public CreateResults m_createResults;
    public EvaluateResults m_evaluateResults;
    public BaseShape m_baseShape;

    public MapLevel m_mapLevel;
    public Nugget[] m_nuggets;
    public byte[] m_heightMap;

    public Material[] m_materials;
    public MaterialPreset[] m_materialPresets;

    public float m_xorg;
    public float m_zorg;

    public int m_column;
    public int m_row;
    public int m_index;

    public float m_x;
    public float m_y;
    public float m_z;

    public float m_nrmX;
    public float m_nrmY;
    public float m_nrmZ;

    public int m_pickedColumn;
    public int m_pickedRow;

    public bool m_ceven;
    public float m_clickDistance = 500f;

    public short m_selectedPresetN;
    public short m_selectedShapeN;

    public bool m_nuggetMode;
    public int m_nuggetDistance = 5;

    public bool m_generated;
    public bool m_created;

    public GameObject m_preview;
    public Material m_previewMaterial;

    // Start is called before the first frame update
    void Start()
    {
        m_createResults.m_gameObjects = new GameObject[]
        {
            new GameObject("child0"),
        };
        m_createResults.m_meshes = new Mesh[]
        {
            new Mesh(),
        };
        m_createResults.m_gameObjects[0].transform.SetParent(transform);
        m_createResults.m_gameObjects[0].AddComponent<MeshCollider>();
        m_createResults.m_gameObjects[0].AddComponent<MeshRenderer>();
        MeshFilter mf = m_createResults.m_gameObjects[0].AddComponent<MeshFilter>();
        mf.sharedMesh = m_createResults.m_meshes[0];

        m_xorg = m_column * m_nuggetCount * 0.75f;
        m_zorg = m_row * m_nuggetCount * 0.8660254f;

        m_baseShape = ScriptableObject.CreateInstance<BaseShape>();
        m_baseShape.Initialize(m_materialPresets, m_meshLibrary, m_mapLevel.m_scale, m_xorg, m_zorg);

        m_evaluateResults.Initialize(m_materials.Length, m_verticeLimit);
    }

    // Update is called once per frame
    void Update()
    {
        switch (m_state)
        {
            case State.Generate:
                m_state = State.Generating;
                Generate();
                break;
            case State.PreEvaluate:
                m_state = State.PreEvaluating;
                PreEvaluate();
                break;
            case State.Evaluate:
                m_state = State.Evaluating;
                Evaluate();
                break;
            case State.PostEvaluate:
                m_state = State.PostEvaluating;
                PostEvaluate();
                break;
            case State.CreateMesh0:
                m_state = State.CreatingMesh0;
                CreateMesh0();
                break;
            case State.CreateMesh1:
                m_state = State.CreatingMesh1;
                CreateMesh1();
                break;
        }
        if (m_state == State.Paused && m_inputMode != InputMode.None)
            HandleInput();
        else if (m_preview != null)
            Destroy(m_preview);
    }

    private void HandleInput()
    {
        if (m_preview == null)
            CreatePreview();

        int layerMask = 1 << 2;
        layerMask = ~layerMask;
        Vector3 mp = Input.mousePosition;
        Ray ray = m_character.m_camera.ScreenPointToRay(mp);
        if (!m_nuggetMode)
        {
            if (Physics.Raycast(ray, out RaycastHit hitinfo, m_clickDistance,
                layerMask, QueryTriggerInteraction.Collide))
            {
                if (hitinfo.collider.gameObject.transform.parent != null)
                {
                    Vector3 point = hitinfo.point;
                    Vector3 normal = hitinfo.normal;
                    m_x = point.x / m_mapLevel.m_scale;
                    m_y = point.y / m_mapLevel.m_scale;
                    m_z = point.z / m_mapLevel.m_scale;

                    m_nrmX = normal.x.Round(5);
                    m_nrmY = normal.y.Round(5);
                    m_nrmZ = normal.z.Round(5);

                    HSLab1 chunk = hitinfo.collider.gameObject.transform.parent.GetComponent<HSLab1>();
                    if (chunk != null)
                    {
                        m_pickedColumn = ((m_x - m_xorg) / 0.75f).FloorToInt();
                        m_ceven = m_pickedColumn % 2 == 0;
                        m_pickedRow = (((m_z - m_zorg) - (m_ceven ? 0.4330127f : 0f)) / 0.8660254f).FloorToInt();
                    }
                }
            }
            if (m_inputMode == InputMode.Place)
                HandlePlace(m_ceven, m_pickedColumn, (int)m_y, m_pickedRow, m_nrmX, m_nrmY, m_nrmZ);
            else
                HandleInner(m_ceven, m_pickedColumn, (int)m_y, m_pickedRow, m_nrmX, m_nrmY, m_nrmZ);
        }
        else
        {
            Vector3 point = ray.GetPoint(m_character.m_scrollDelta);
            m_x = point.x / m_mapLevel.m_scale;
            m_y = point.y / m_mapLevel.m_scale;
            m_z = point.z / m_mapLevel.m_scale;

            m_pickedColumn = ((m_x - m_xorg) / 0.75f).FloorToInt();
            m_ceven = m_pickedColumn % 2 == 0;
            m_pickedRow = (((m_z - m_zorg) - (m_ceven ? 0.4330127f : 0f)) / 0.8660254f).FloorToInt();

            HandleNuggetMode(m_ceven, m_pickedColumn, (int)m_y, m_pickedRow);
        }
    }

    private void HandleNuggetMode(bool ceven, int pickedColumn, int pickedY, int pickedRow)
    {
        int nuggetIndex = GetCRIndex(pickedColumn, pickedY, pickedRow, m_nuggetCount, m_levelSize);
        if (nuggetIndex > -1 && nuggetIndex < m_nuggets.Length)
        {
            GetCROut(nuggetIndex, m_nuggetCount, m_levelSize, out int c, out int py, out int r);
            if (Input.GetMouseButtonDown(0))
            {
                if (m_inputMode == InputMode.Place)
                {
                    m_nuggets[nuggetIndex].m_shape = m_selectedShapeN;
                    m_nuggets[nuggetIndex].m_presetN = m_selectedPresetN;
                    m_state = State.PreEvaluate;
                }
                else if (m_inputMode == InputMode.Erase)
                {
                    m_nuggets[nuggetIndex].m_shape = 0;
                    m_state = State.PreEvaluate;
                }
                else if (m_inputMode == InputMode.Material)
                {
                    m_nuggets[nuggetIndex].m_presetN = m_selectedPresetN;
                    m_state = State.PreEvaluate;
                }
                else
                {
                    SetIndetify(nuggetIndex, c, py, r);
                }
            }
            m_preview.transform.position = new Vector3((c * 0.75f) * m_mapLevel.m_scale,
                py * m_mapLevel.m_scale,
                ((r * 0.8660254f) + (ceven ? 0.4330127f : 0f)) * m_mapLevel.m_scale);
        }
        else
        {
            m_preview.transform.position = new Vector3((pickedColumn * 0.75f) * m_mapLevel.m_scale,
                pickedY * m_mapLevel.m_scale,
                ((pickedRow * 0.8660254f) + (ceven ? 0.4330127f : 0f)) * m_mapLevel.m_scale);
        }
    }

    private void HandleInner(bool ceven, int pickedColumn, int pickedY, int pickedRow,
        float nrmX, float nrmY, float nrmZ)
    {
        int nuggetIndex = GetCRIndex(pickedColumn, pickedY, pickedRow, m_nuggetCount, m_levelSize);
        if (nrmX < 0f)
            HandleInnerNegX(ceven, nuggetIndex, pickedColumn, pickedY, pickedRow);
        else if (nrmX > 0f && nrmZ < 0f)
            HandleInnerPosXNegZ(ceven, nuggetIndex, pickedColumn, pickedY, pickedRow);
        else if (nrmY > 0f && nrmZ > 0f)
            HandleInnerNegXNegZ(ceven, nuggetIndex, pickedColumn, pickedY, pickedRow);
        else if (nrmY > 0f)
            HandleInnerPosY(ceven, nuggetIndex, pickedColumn, pickedY, pickedRow);
        else if (nrmY < 0f)
            HandleInnerNegY(ceven, nuggetIndex, pickedColumn, pickedY, pickedRow);
        else if (nrmZ > 0f)
            HandleInnerPosZ(ceven, nuggetIndex, pickedColumn, pickedY, pickedRow);
        else if (nrmZ < 0f)
            HandleInnerNegZ(ceven, nuggetIndex, pickedColumn, pickedY, pickedRow);
    }

    private void DoInner(int nuggetIndex, int c, int py, int r)
    {
        if (Input.GetMouseButtonDown(0))
        {
            if (m_inputMode == InputMode.Erase)
            {
                m_nuggets[nuggetIndex].m_shape = 0;
                m_state = State.PreEvaluate;
            }
            else if (m_inputMode == InputMode.Material)
            {
                m_nuggets[nuggetIndex].m_presetN = m_selectedPresetN;
                m_state = State.PreEvaluate;
            }
            else if (m_inputMode == InputMode.Identify)
            {
                SetIndetify(nuggetIndex, c, py, r);
            }
        }
    }

    private void HandleInnerNegX(bool ceven, int nuggetIndex, int pickedColumn, int pickedY, int pickedRow)
    {
        if (nuggetIndex < m_nuggets.Length && nuggetIndex > -1)
        {
            GetCROut(nuggetIndex, m_nuggetCount, m_levelSize, out int c, out int py, out int r);
            DoInner(nuggetIndex, c, py, r);
            m_preview.transform.position = new Vector3((c * 0.75f) * m_mapLevel.m_scale,
                py * m_mapLevel.m_scale,
                ((r * 0.8660254f) + (ceven ? 0.4330127f : 0f)) * m_mapLevel.m_scale);
        }
        else
        {
            m_preview.transform.position = new Vector3((pickedColumn * 0.75f) * m_mapLevel.m_scale,
                pickedY * m_mapLevel.m_scale,
                ((pickedRow * 0.8660254f) + (ceven ? 0.4330127f : 0f)) * m_mapLevel.m_scale);
        }
    }

    private void HandleInnerPosXNegZ(bool ceven, int nuggetIndex, int pickedColumn, int pickedY, int pickedRow)
    {
        if (ceven)
        {
            while (nuggetIndex < m_nuggets.Length && nuggetIndex > -1 && m_nuggets[nuggetIndex].m_shape == 0)
                --nuggetIndex;
        }
        else
        {
            while (nuggetIndex < m_nuggets.Length && nuggetIndex > -1 && m_nuggets[nuggetIndex].m_shape == 0)
                nuggetIndex -= m_nuggetCount + 1;
        }

        if (nuggetIndex < m_nuggets.Length && nuggetIndex > -1)
        {
            GetCROut(nuggetIndex, m_nuggetCount, m_levelSize, out int c, out int py, out int r);
            DoInner(nuggetIndex, c, py, r);
            m_preview.transform.position = new Vector3((c * 0.75f) * m_mapLevel.m_scale,
                py * m_mapLevel.m_scale,
                ((r * 0.8660254f) + (ceven ? 0f : 0.4330127f)) * m_mapLevel.m_scale);
        }
        else
        {
            m_preview.transform.position = new Vector3((pickedColumn * 0.75f) * m_mapLevel.m_scale,
                pickedY * m_mapLevel.m_scale,
                ((pickedRow * 0.8660254f) + (ceven ? 0f : 0.4330127f)) * m_mapLevel.m_scale);
        }
    }

    private void HandleInnerNegXNegZ(bool ceven, int nuggetIndex, int pickedColumn, int pickedY, int pickedRow)
    {
        if (ceven)
        {
            while (nuggetIndex < m_nuggets.Length && nuggetIndex > -1 && m_nuggets[nuggetIndex].m_shape == 0)
                nuggetIndex += (m_nuggetCount - 1);
        }
        else
        {
            while (nuggetIndex < m_nuggets.Length && nuggetIndex > -1 && m_nuggets[nuggetIndex].m_shape == 0)
                --nuggetIndex;
        }

        if (nuggetIndex < m_nuggets.Length && nuggetIndex > -1)
        {
            GetCROut(nuggetIndex, m_nuggetCount, m_levelSize, out int c, out int py, out int r);
            DoInner(nuggetIndex, c, py, r);
            m_preview.transform.position = new Vector3((c * 0.75f) * m_mapLevel.m_scale,
                py * m_mapLevel.m_scale,
                ((r * 0.8660254f) + (ceven ? 0f : 0.4330127f)) * m_mapLevel.m_scale);
        }
        else
        {
            m_preview.transform.position = new Vector3((pickedColumn * 0.75f) * m_mapLevel.m_scale,
                pickedY * m_mapLevel.m_scale,
                ((pickedRow * 0.8660254f) + (ceven ? 0f : 0.4330127f)) * m_mapLevel.m_scale);
        }
    }

    private void HandleInnerPosY(bool ceven, int nuggetIndex, int pickedColumn, int pickedY, int pickedRow)
    {
        while (nuggetIndex < m_nuggets.Length && nuggetIndex > -1 && m_nuggets[nuggetIndex].m_shape == 0)
            nuggetIndex -= m_levelSize;

        if (nuggetIndex < m_nuggets.Length && nuggetIndex > -1)
        {
            GetCROut(nuggetIndex, m_nuggetCount, m_levelSize, out int c, out int py, out int r);
            DoInner(nuggetIndex, c, py, r);
            m_preview.transform.position = new Vector3((c * 0.75f) * m_mapLevel.m_scale,
                py * m_mapLevel.m_scale,
                ((r * 0.8660254f) + (ceven ? 0.4330127f : 0f)) * m_mapLevel.m_scale);
        }
        else
        {
            m_preview.transform.position = new Vector3((pickedColumn * 0.75f) * m_mapLevel.m_scale,
                pickedY * m_mapLevel.m_scale,
                ((pickedRow * 0.8660254f) + (ceven ? 0.4330127f : 0f)) * m_mapLevel.m_scale);
        }
    }

    private void HandleInnerNegY(bool ceven, int nuggetIndex, int pickedColumn, int pickedY, int pickedRow)
    {
        while (nuggetIndex < m_nuggets.Length && nuggetIndex > -1 && m_nuggets[nuggetIndex].m_shape == 0)
            nuggetIndex += m_levelSize;

        if (nuggetIndex < m_nuggets.Length && nuggetIndex > -1)
        {
            GetCROut(nuggetIndex, m_nuggetCount, m_levelSize, out int c, out int py, out int r);
            DoInner(nuggetIndex, c, py, r);
            m_preview.transform.position = new Vector3((c * 0.75f) * m_mapLevel.m_scale,
                py * m_mapLevel.m_scale,
                ((r * 0.8660254f) + (ceven ? 0.4330127f : 0f)) * m_mapLevel.m_scale);
        }
        else
        {
            m_preview.transform.position = new Vector3((pickedColumn * 0.75f) * m_mapLevel.m_scale,
                pickedY * m_mapLevel.m_scale,
                ((pickedRow * 0.8660254f) + (ceven ? 0.4330127f : 0f)) * m_mapLevel.m_scale);
        }
    }

    private void HandleInnerPosZ(bool ceven, int nuggetIndex, int pickedColumn, int pickedY, int pickedRow)
    {
        while (nuggetIndex < m_nuggets.Length && nuggetIndex > -1 && m_nuggets[nuggetIndex].m_shape == 0)
            nuggetIndex -= m_nuggetCount;

        if (nuggetIndex < m_nuggets.Length && nuggetIndex > -1)
        {
            GetCROut(nuggetIndex, m_nuggetCount, m_levelSize, out int c, out int py, out int r);
            DoInner(nuggetIndex, c, py, r);
            m_preview.transform.position = new Vector3((c * 0.75f) * m_mapLevel.m_scale,
                py * m_mapLevel.m_scale,
                ((r * 0.8660254f) + (ceven ? 0.4330127f : 0f)) * m_mapLevel.m_scale);
        }
        else
        {
            m_preview.transform.position = new Vector3((pickedColumn * 0.75f) * m_mapLevel.m_scale,
                pickedY * m_mapLevel.m_scale,
                ((pickedRow * 0.8660254f) + (ceven ? 0.4330127f : 0f)) * m_mapLevel.m_scale);
        }
    }

    private void HandleInnerNegZ(bool ceven, int nuggetIndex, int pickedColumn, int pickedY, int pickedRow)
    {
        while (nuggetIndex < m_nuggets.Length && nuggetIndex > -1 && m_nuggets[nuggetIndex].m_shape == 0)
            nuggetIndex += m_nuggetCount;

        if (nuggetIndex < m_nuggets.Length && nuggetIndex > -1)
        {
            GetCROut(nuggetIndex, m_nuggetCount, m_levelSize, out int c, out int py, out int r);
            DoInner(nuggetIndex, c, py, r);
            m_preview.transform.position = new Vector3((c * 0.75f) * m_mapLevel.m_scale,
                py * m_mapLevel.m_scale,
                ((r * 0.8660254f) + (ceven ? 0.4330127f : 0f)) * m_mapLevel.m_scale);
        }
        else
        {
            m_preview.transform.position = new Vector3((pickedColumn * 0.75f) * m_mapLevel.m_scale,
                pickedY * m_mapLevel.m_scale,
                ((pickedRow * 0.8660254f) + (ceven ? 0.4330127f : 0f)) * m_mapLevel.m_scale);
        }
    }

    private void HandlePlace(bool ceven, int pickedColumn, int pickedY, int pickedRow,
        float nrmX, float nrmY, float nrmZ)
    {
        int nuggetIndex = GetCRIndex(pickedColumn, pickedY, pickedRow, m_nuggetCount, m_levelSize);
        if (nrmX < 0f && nrmZ < 0f)
            HandlePlaceNegXNegZ(ceven, nuggetIndex, pickedColumn, pickedY, pickedRow);
        else if (nrmX > 0f && nrmZ < 0f)
            HandlePlacePosXNegZ(ceven, nuggetIndex, pickedColumn, pickedY, pickedRow);
        else if (nrmX < 0f && nrmZ > 0f)
            HandlePlaceNegXPosZ(ceven, nuggetIndex, pickedColumn, pickedY, pickedRow);
        else if (nrmX > 0f && nrmZ > 0f)
            HandlePlacePosXPosZ(ceven, nuggetIndex, pickedColumn, pickedY, pickedRow);
        else if (nrmY > 0f)
            HandlePlacePosY(ceven, nuggetIndex, pickedColumn, pickedY, pickedRow);
        else if (nrmY < 0f)
            HandlePlaceNegY(ceven, nuggetIndex, pickedColumn, pickedY, pickedRow);
        else if (nrmZ > 0f)
            HandlePlacePosZ(ceven, nuggetIndex, pickedColumn, pickedY, pickedRow);
        else if (nrmZ < 0f)
            HandlePlaceNegZ(ceven, nuggetIndex, pickedColumn, pickedY, pickedRow);
    }

    private void HandlePlacePosXNegZ(bool ceven, int nuggetIndex, int pickedColumn, int pickedY, int pickedRow)
    {
        if (ceven)
        {
            while (nuggetIndex < m_nuggets.Length && nuggetIndex > -1 && m_nuggets[nuggetIndex].m_shape != 0)
                ++nuggetIndex;
        }
        else
        {
            while (nuggetIndex < m_nuggets.Length && nuggetIndex > -1 && m_nuggets[nuggetIndex].m_shape != 0)
                nuggetIndex -= (m_nuggetCount - 1);
        }

        if (nuggetIndex < m_nuggets.Length && nuggetIndex > -1)
        {
            GetCROut(nuggetIndex, m_nuggetCount, m_levelSize, out int c, out int py, out int r);
            if (Input.GetMouseButtonDown(0))
            {
                m_nuggets[nuggetIndex].m_shape = m_selectedShapeN;
                m_nuggets[nuggetIndex].m_presetN = m_selectedPresetN;
                m_state = State.PreEvaluate;
            }
            m_preview.transform.position = new Vector3((c * 0.75f) * m_mapLevel.m_scale,
                py * m_mapLevel.m_scale,
                ((r * 0.8660254f) + (ceven ? 0.4330127f : 0f)) * m_mapLevel.m_scale);
        }
        else
        {
            m_preview.transform.position = new Vector3((pickedColumn * 0.75f) * m_mapLevel.m_scale,
                pickedY * m_mapLevel.m_scale,
                ((pickedRow * 0.8660254f) + (ceven ? 0.4330127f : 0f)) * m_mapLevel.m_scale);
        }
    }

    private void HandlePlaceNegXNegZ(bool ceven, int nuggetIndex, int pickedColumn, int pickedY, int pickedRow)
    {
        if (ceven)
        {
            while (nuggetIndex < m_nuggets.Length && nuggetIndex > -1 && m_nuggets[nuggetIndex].m_shape != 0)
                --nuggetIndex;
        }
        else
        {
            while (nuggetIndex < m_nuggets.Length && nuggetIndex > -1 && m_nuggets[nuggetIndex].m_shape != 0)
                nuggetIndex -= (m_nuggetCount + 1);
        }

        if (nuggetIndex < m_nuggets.Length && nuggetIndex > -1)
        {
            GetCROut(nuggetIndex, m_nuggetCount, m_levelSize, out int c, out int py, out int r);
            if (Input.GetMouseButtonDown(0))
            {
                m_nuggets[nuggetIndex].m_shape = m_selectedShapeN;
                m_nuggets[nuggetIndex].m_presetN = m_selectedPresetN;
                m_state = State.PreEvaluate;
            }
            m_preview.transform.position = new Vector3((c * 0.75f) * m_mapLevel.m_scale,
                py * m_mapLevel.m_scale,
                ((r * 0.8660254f) + (ceven ? 0f : 0.4330127f)) * m_mapLevel.m_scale);
        }
        else
        {
            m_preview.transform.position = new Vector3((pickedColumn * 0.75f) * m_mapLevel.m_scale,
                pickedY * m_mapLevel.m_scale,
                ((pickedRow * 0.8660254f) + (ceven ? 0f : 0.4330127f)) * m_mapLevel.m_scale);
        }
    }

    private void HandlePlacePosXPosZ(bool ceven, int nuggetIndex, int pickedColumn, int pickedY, int pickedRow)
    {
        if (ceven)
        {
            while (nuggetIndex < m_nuggets.Length && nuggetIndex > -1 && m_nuggets[nuggetIndex].m_shape != 0)
                nuggetIndex += (m_nuggetCount + 1);
        }
        else
        {
            while (nuggetIndex < m_nuggets.Length && nuggetIndex > -1 && m_nuggets[nuggetIndex].m_shape != 0)
                ++nuggetIndex;
        }

        if (nuggetIndex < m_nuggets.Length && nuggetIndex > -1)
        {
            GetCROut(nuggetIndex, m_nuggetCount, m_levelSize, out int c, out int py, out int r);
            if (Input.GetMouseButtonDown(0))
            {
                m_nuggets[nuggetIndex].m_shape = m_selectedShapeN;
                m_nuggets[nuggetIndex].m_presetN = m_selectedPresetN;
                m_state = State.PreEvaluate;
            }
            m_preview.transform.position = new Vector3((c * 0.75f) * m_mapLevel.m_scale,
                py * m_mapLevel.m_scale,
                ((r * 0.8660254f) + (ceven ? 0.4330127f : 0f)) * m_mapLevel.m_scale);
        }
        else
        {
            m_preview.transform.position = new Vector3((pickedColumn * 0.75f) * m_mapLevel.m_scale,
                pickedY * m_mapLevel.m_scale,
                ((pickedRow * 0.8660254f) + (ceven ? 0.4330127f : 0f)) * m_mapLevel.m_scale);
        }
    }

    private void HandlePlaceNegXPosZ(bool ceven, int nuggetIndex, int pickedColumn, int pickedY, int pickedRow)
    {
        if (ceven)
        {
            while (nuggetIndex < m_nuggets.Length && nuggetIndex > -1 && m_nuggets[nuggetIndex].m_shape != 0)
                nuggetIndex += (m_nuggetCount - 1);
        }
        else
        {
            while (nuggetIndex < m_nuggets.Length && nuggetIndex > -1 && m_nuggets[nuggetIndex].m_shape != 0)
                --nuggetIndex;
        }

        if (nuggetIndex < m_nuggets.Length && nuggetIndex > -1)
        {
            GetCROut(nuggetIndex, m_nuggetCount, m_levelSize, out int c, out int py, out int r);
            if (Input.GetMouseButtonDown(0))
            {
                m_nuggets[nuggetIndex].m_shape = m_selectedShapeN;
                m_nuggets[nuggetIndex].m_presetN = m_selectedPresetN;
                m_state = State.PreEvaluate;
            }
            m_preview.transform.position = new Vector3((c * 0.75f) * m_mapLevel.m_scale,
                py * m_mapLevel.m_scale,
                ((r * 0.8660254f) + (ceven ? 0f : 0.4330127f)) * m_mapLevel.m_scale);
        }
        else
        {
            m_preview.transform.position = new Vector3((pickedColumn * 0.75f) * m_mapLevel.m_scale,
                pickedY * m_mapLevel.m_scale,
                ((pickedRow * 0.8660254f) + (ceven ? 0f : 0.4330127f)) * m_mapLevel.m_scale);
        }
    }

    private void HandlePlacePosY(bool ceven, int nuggetIndex, int pickedColumn, int pickedY, int pickedRow)
    {
        while (nuggetIndex < m_nuggets.Length && nuggetIndex > -1 && m_nuggets[nuggetIndex].m_shape != 0)
            nuggetIndex += m_levelSize;

        if (nuggetIndex < m_nuggets.Length && nuggetIndex > -1)
        {
            GetCROut(nuggetIndex, m_nuggetCount, m_levelSize, out int c, out int py, out int r);
            if (Input.GetMouseButtonDown(0))
            {
                m_nuggets[nuggetIndex].m_shape = m_selectedShapeN;
                m_nuggets[nuggetIndex].m_presetN = m_selectedPresetN;
                m_state = State.PreEvaluate;
            }
            m_preview.transform.position = new Vector3((c * 0.75f) * m_mapLevel.m_scale,
                py * m_mapLevel.m_scale,
                ((r * 0.8660254f) + (ceven ? 0.4330127f : 0f)) * m_mapLevel.m_scale);
        }
        else
        {
            m_preview.transform.position = new Vector3((pickedColumn * 0.75f) * m_mapLevel.m_scale,
                pickedY * m_mapLevel.m_scale,
                ((pickedRow * 0.8660254f) + (ceven ? 0.4330127f : 0f)) * m_mapLevel.m_scale);
        }
    }

    private void HandlePlaceNegY(bool ceven, int nuggetIndex, int pickedColumn, int pickedY, int pickedRow)
    {
        while (nuggetIndex < m_nuggets.Length && nuggetIndex > -1 && m_nuggets[nuggetIndex].m_shape != 0)
            nuggetIndex -= m_levelSize;

        if (nuggetIndex < m_nuggets.Length && nuggetIndex > -1)
        {
            GetCROut(nuggetIndex, m_nuggetCount, m_levelSize, out int c, out int py, out int r);
            if (Input.GetMouseButtonDown(0))
            {
                m_nuggets[nuggetIndex].m_shape = m_selectedShapeN;
                m_nuggets[nuggetIndex].m_presetN = m_selectedPresetN;
                m_state = State.PreEvaluate;
            }
            m_preview.transform.position = new Vector3((c * 0.75f) * m_mapLevel.m_scale,
                py * m_mapLevel.m_scale,
                ((r * 0.8660254f) + (ceven ? 0.4330127f : 0f)) * m_mapLevel.m_scale);
        }
        else
        {
            m_preview.transform.position = new Vector3((pickedColumn * 0.75f) * m_mapLevel.m_scale,
                pickedY * m_mapLevel.m_scale,
                ((pickedRow * 0.8660254f) + (ceven ? 0.4330127f : 0f)) * m_mapLevel.m_scale);
        }
    }

    private void HandlePlacePosZ(bool ceven, int nuggetIndex, int pickedColumn, int pickedY, int pickedRow)
    {
        while (nuggetIndex < m_nuggets.Length && nuggetIndex > -1 && m_nuggets[nuggetIndex].m_shape != 0)
            nuggetIndex += m_nuggetCount;

        if (nuggetIndex < m_nuggets.Length && nuggetIndex > -1)
        {
            GetCROut(nuggetIndex, m_nuggetCount, m_levelSize, out int c, out int py, out int r);
            if (Input.GetMouseButtonDown(0))
            {
                m_nuggets[nuggetIndex].m_shape = m_selectedShapeN;
                m_nuggets[nuggetIndex].m_presetN = m_selectedPresetN;
                m_state = State.PreEvaluate;
            }
            m_preview.transform.position = new Vector3((c * 0.75f) * m_mapLevel.m_scale,
                py * m_mapLevel.m_scale,
                ((r * 0.8660254f) + (ceven ? 0.4330127f : 0f)) * m_mapLevel.m_scale);
        }
        else
        {
            m_preview.transform.position = new Vector3((pickedColumn * 0.75f) * m_mapLevel.m_scale,
                pickedY * m_mapLevel.m_scale,
                ((pickedRow * 0.8660254f) + (ceven ? 0.4330127f : 0f)) * m_mapLevel.m_scale);
        }
    }

    private void HandlePlaceNegZ(bool ceven, int nuggetIndex, int pickedColumn, int pickedY, int pickedRow)
    {
        while (nuggetIndex < m_nuggets.Length && nuggetIndex > -1 && m_nuggets[nuggetIndex].m_shape != 0)
            nuggetIndex -= m_nuggetCount;

        if (nuggetIndex < m_nuggets.Length && nuggetIndex > -1)
        {
            GetCROut(nuggetIndex, m_nuggetCount, m_levelSize, out int c, out int py, out int r);
            if (Input.GetMouseButtonDown(0))
            {
                m_nuggets[nuggetIndex].m_shape = m_selectedShapeN;
                m_nuggets[nuggetIndex].m_presetN = m_selectedPresetN;
                m_state = State.PreEvaluate;
            }
            m_preview.transform.position = new Vector3((c * 0.75f) * m_mapLevel.m_scale,
                py * m_mapLevel.m_scale,
                ((r * 0.8660254f) + (ceven ? 0.4330127f : 0f)) * m_mapLevel.m_scale);
        }
        else
        {
            m_preview.transform.position = new Vector3((pickedColumn * 0.75f) * m_mapLevel.m_scale,
                pickedY * m_mapLevel.m_scale,
                ((pickedRow * 0.8660254f) + (ceven ? 0.4330127f : 0f)) * m_mapLevel.m_scale);
        }
    }

    private void Generate()
    {
        m_nuggets = new Nugget[m_levelSize * m_mapLevel.m_maxHeight];
        m_heightMap = new byte[m_levelSize];

        for (int z = 0; z < m_nuggetCount; ++z)
        {
            for (int x = 0; x < m_nuggetCount; ++x)
            {
                float h = NoiseGenerator.I.GetNoise(x, z, m_mapLevel.m_seed,
                    m_mapLevel.m_worldSize, m_mapLevel.m_smoothing,
                    m_xorg, m_zorg);
                h *= m_mapLevel.m_generateHeight;
                try
                {
                    int index = GetCRIndex(x, z, m_nuggetCount);
                    m_heightMap[index] = (byte)h;
                    for (int y = 0; y < m_mapLevel.m_maxHeight; ++y)
                    {
                        index = GetCRIndex(x, y, z, m_nuggetCount, m_levelSize);
                        short shapeN = (short)(y < h ? 1 : 0);
                        //short presetN = (short)(z % 2 == 0 ? 2 : 1);
                        m_nuggets[index] = new Nugget()
                        {
                            m_presetN = 0,
                            m_shape = shapeN,
                        };
                    }
                }
                catch (System.Exception ex)
                {
                    Debug.LogError(ex.Message);
                }
            }
        }
        m_generated = true;
        m_state = State.PreEvaluate;
    }

    private void PreEvaluate()
    {
        m_createResults.m_currentN = 0;
        m_evaluateResults.Reset();
        m_state = State.Evaluate;
    }

    private void Evaluate()
    {
        for (int n = m_evaluateResults.m_breakN; n < m_nuggets.Length; ++n)
        {
            try
            {
                Nugget nugget = m_nuggets[n];
                if (nugget.m_shape != 0)
                {
                    GetCROut(n, m_nuggetCount, m_levelSize, out int c, out int y, out int r);
                    Nugget[] neighbors = new Nugget[17];
                    GetNeighbors(n, c, y, r, ref neighbors);
                    neighbors[0] = nugget;
                    try
                    {
                        float x = c * 0.75f;
                        float z = r * 0.8660254f;
                        m_baseShape.Evaluate(c, y, r, x, z, ref neighbors, ref m_evaluateResults);
                    }
                    catch (System.Exception ex)
                    {
                        Debug.LogError(ex.Message);
                    }

                    if (m_evaluateResults.m_vcnt + 2400 >= m_verticeLimit &&
                        (n + 1 < m_nuggets.Length))
                    {
                        m_evaluateResults.m_breakC = c;
                        m_evaluateResults.m_breakY = y;
                        m_evaluateResults.m_breakR = r;
                        m_evaluateResults.m_breakN = n + 1;
                        m_evaluateResults.m_hasMore = true;
                        break;
                    }
                }
            }
            catch (System.Exception ex)
            {
                Debug.LogError(ex.Message);
            }
        }
        m_state = State.PostEvaluate;
    }

    private void PostEvaluate()
    {
        System.Array.Resize(ref m_evaluateResults.m_tmpvertices, m_evaluateResults.m_vcnt);
        System.Array.Copy(m_evaluateResults.m_vertices, m_evaluateResults.m_tmpvertices,
            m_evaluateResults.m_vcnt);

        System.Array.Resize(ref m_evaluateResults.m_tmpuvs, m_evaluateResults.m_vcnt);
        System.Array.Copy(m_evaluateResults.m_uvs, m_evaluateResults.m_tmpuvs,
            m_evaluateResults.m_vcnt);

        System.Array.Resize(ref m_evaluateResults.m_tmpnormals, m_evaluateResults.m_vcnt);
        System.Array.Copy(m_evaluateResults.m_normals, m_evaluateResults.m_tmpnormals,
            m_evaluateResults.m_vcnt);

        for (int n = 0; n < m_evaluateResults.m_faceIndexGroups.Length; ++n)
        {
            if (m_evaluateResults.m_faceIndexGroups[n].m_used)
            {
                System.Array.Resize(ref m_evaluateResults.m_tmpfaceIndexGroups[n].m_faceIndexs,
                    m_evaluateResults.m_faceIndexGroups[n].m_totalFaceIndexUsed);
                System.Array.Copy(m_evaluateResults.m_faceIndexGroups[n].m_faceIndexs,
                    m_evaluateResults.m_tmpfaceIndexGroups[n].m_faceIndexs,
                    m_evaluateResults.m_faceIndexGroups[n].m_totalFaceIndexUsed);
                m_evaluateResults.m_tmpfaceIndexGroups[n].m_used = true;
                ++m_evaluateResults.m_totalMatCnt;
            }
            else
                m_evaluateResults.m_tmpfaceIndexGroups[n].m_used = false;
        }
        m_state = State.CreateMesh0;
    }

    private void CreateMesh0()
    {
        if (m_createResults.m_currentN >= m_createResults.m_gameObjects.Length)
        {
            GameObject nwChild = new GameObject(string.Format("child{0}", m_createResults.m_gameObjects.Length));
            nwChild.transform.SetParent(transform);
            m_createResults.m_gameObjects = m_createResults.m_gameObjects.Add(nwChild);

            m_createResults.m_meshes = m_createResults.m_meshes.Add(new Mesh());
            m_createResults.m_gameObjects[m_createResults.m_currentN].AddComponent<MeshCollider>();
            m_createResults.m_gameObjects[m_createResults.m_currentN].AddComponent<MeshRenderer>();
            MeshFilter mf = m_createResults.m_gameObjects[m_createResults.m_currentN].AddComponent<MeshFilter>();
            mf.sharedMesh = m_createResults.m_meshes[m_createResults.m_currentN];
        }

        Mesh mesh = m_createResults.m_meshes[m_createResults.m_currentN];
        if (mesh == null)
        {
            mesh = new Mesh()
            {
                vertices = m_evaluateResults.m_tmpvertices,
                normals = m_evaluateResults.m_tmpnormals,
                uv = m_evaluateResults.m_tmpuvs,
                subMeshCount = m_evaluateResults.m_totalMatCnt,
            };
        }
        else
        {
            mesh.Clear();
            mesh.vertices = m_evaluateResults.m_tmpvertices;
            mesh.normals = m_evaluateResults.m_tmpnormals;
            mesh.uv = m_evaluateResults.m_tmpuvs;
            mesh.subMeshCount = m_evaluateResults.m_totalMatCnt;
        }

        Material[] materials = new Material[0];
        int m = 0;
        for (int n = 0; n < m_evaluateResults.m_tmpfaceIndexGroups.Length; ++n)
        {
            if (m_evaluateResults.m_tmpfaceIndexGroups[n].m_used)
            {
                materials = materials.Add(m_materials[n]);
                mesh.SetTriangles(m_evaluateResults.m_tmpfaceIndexGroups[n].m_faceIndexs, m);
                ++m;
            }
        }

        MeshRenderer mr = m_createResults.m_gameObjects[m_createResults.m_currentN].GetComponent<MeshRenderer>();
        mr.sharedMaterials = materials;
        mesh.RecalculateTangents();
        MeshCollider collider = m_createResults.m_gameObjects[m_createResults.m_currentN].GetComponent<MeshCollider>();
        collider.sharedMesh = mesh;
        MeshFilter filter = m_createResults.m_gameObjects[m_createResults.m_currentN].GetComponent<MeshFilter>();
        filter.sharedMesh = mesh;

        m_state = State.CreateMesh1;
    }

    private void CreateMesh1()
    {
        m_created = true;
        m_state = State.Paused;
    }

    private void GetNeighbors(int nuggetIndex, int c, int y, int r, ref Nugget[] neighbors)
    {
        bool ceven = c % 2 == 0;
        try
        {
            if (r > 0)
                neighbors[m_sn0] = m_nuggets[nuggetIndex - m_nuggetCount];
            else
                neighbors[m_sn0] = new Nugget() { m_shape = 0 };
        }
        catch (System.Exception ex)
        {
            Debug.LogError(ex.Message);
        }

        try
        {
            if (c > 0)
            {
                if (ceven)
                    neighbors[m_sn1] = m_nuggets[nuggetIndex - 1];
                else if (r > 0)
                    neighbors[m_sn1] = m_nuggets[nuggetIndex - m_nuggetCount - 1];
                else
                    neighbors[m_sn1] = new Nugget() { m_shape = 0 };
            }
            else
                neighbors[m_sn1] = new Nugget() { m_shape = 0 };
        }
        catch (System.Exception ex)
        {
            Debug.LogError(ex.Message);
        }

        try
        {
            if (c > 0)
            {
                if (ceven && r + 1 < m_nuggetCount)
                    neighbors[m_sn2] = m_nuggets[nuggetIndex + m_nuggetCount - 1];
                else if (ceven)
                    neighbors[m_sn2] = new Nugget() { m_shape = 0 };
                else
                    neighbors[m_sn2] = m_nuggets[nuggetIndex - 1];
            }
            else
                neighbors[m_sn2] = new Nugget() { m_shape = 0 };
        }
        catch (System.Exception ex)
        {
            Debug.LogError(ex.Message);
        }

        try
        {
            if (r + 1 < m_nuggetCount)
                neighbors[m_sn3] = m_nuggets[nuggetIndex + m_nuggetCount];
            else
                neighbors[m_sn3] = new Nugget() { m_shape = 0 };
        }
        catch (System.Exception ex)
        {
            Debug.LogError(ex.Message);
        }

        try
        {
            if (c + 1 < m_nuggetCount)
            {
                if (ceven && r + 1 < m_nuggetCount)
                    neighbors[m_sn4] = m_nuggets[nuggetIndex + m_nuggetCount + 1];
                else if (ceven)
                    neighbors[m_sn4] = new Nugget() { m_shape = 0 };
                else
                    neighbors[m_sn4] = m_nuggets[nuggetIndex + 1];
            }
            else
                neighbors[m_sn4] = new Nugget() { m_shape = 0 };
        }
        catch (System.Exception ex)
        {
            Debug.LogError(ex.Message);
        }

        try
        {
            if (c + 1 < m_nuggetCount)
            {
                if (ceven)
                    neighbors[m_sn5] = m_nuggets[nuggetIndex + 1];
                else if (r > 0)
                    neighbors[m_sn5] = m_nuggets[nuggetIndex - m_nuggetCount + 1];
                else
                    neighbors[m_sn5] = new Nugget() { m_shape = 0 };
            }
            else
                neighbors[m_sn5] = new Nugget() { m_shape = 0 };
        }
        catch (System.Exception ex)
        {
            Debug.LogError(ex.Message);
        }

        try
        {
            if (y + 1 < m_mapLevel.m_maxHeight)
                neighbors[m_sn6] = m_nuggets[nuggetIndex + m_levelSize];
            else
                neighbors[m_sn6] = new Nugget() { m_shape = 0 };
        }
        catch (System.Exception ex)
        {
            Debug.LogError(ex.Message);
        }

        try
        {
            if (y > 0)
                neighbors[m_sn7] = m_nuggets[nuggetIndex - m_levelSize];
            else
                neighbors[m_sn7] = new Nugget() { m_shape = 1 };
        }
        catch (System.Exception ex)
        {
            Debug.LogError(ex.Message);
        }
    }

    private void CreatePreview()
    {
        EvaluateResults eresults = new EvaluateResults();
        eresults.Initialize(1, 2400);
        m_baseShape.EvaluatePreview(ref eresults);

        if (m_preview == null)
        {
            m_preview = new GameObject("preview");
            m_preview.transform.SetParent(transform);
            MeshFilter mf = m_preview.AddComponent<MeshFilter>();
            m_preview.AddComponent<MeshRenderer>();
            mf.sharedMesh = new Mesh();
        }

        System.Array.Resize(ref eresults.m_tmpvertices, eresults.m_vcnt);
        System.Array.Copy(eresults.m_vertices, eresults.m_tmpvertices, eresults.m_vcnt);

        System.Array.Resize(ref eresults.m_tmpnormals, eresults.m_vcnt);
        System.Array.Copy(eresults.m_normals, eresults.m_tmpnormals, eresults.m_vcnt);

        System.Array.Resize(ref eresults.m_tmpuvs, eresults.m_vcnt);
        System.Array.Copy(eresults.m_uvs, eresults.m_tmpuvs, eresults.m_vcnt);

        System.Array.Resize(ref eresults.m_tmpfaceIndexGroups[0].m_faceIndexs, eresults.m_tficnt[0]);
        System.Array.Copy(eresults.m_faceIndexGroups[0].m_faceIndexs,
            eresults.m_tmpfaceIndexGroups[0].m_faceIndexs, eresults.m_tficnt[0]);

        Mesh mesh = m_preview.GetComponent<MeshFilter>().sharedMesh;
        mesh.vertices = eresults.m_tmpvertices;
        mesh.normals = eresults.m_tmpnormals;
        mesh.uv = eresults.m_tmpuvs;
        mesh.SetTriangles(eresults.m_tmpfaceIndexGroups[0].m_faceIndexs, 0);
        m_preview.GetComponent<MeshRenderer>().sharedMaterial = m_previewMaterial;
    }

    #region ui
    public Text m_txtNIndex;
    public Text m_txtCol;
    public Text m_txtY;
    public Text m_txtRow;
    public Text m_txtMat;
    public Text m_txtShape;

    private void SetIndetify(int nuggetIndex, int col, int y, int row)
    {
        m_txtNIndex.text = nuggetIndex.ToString();
        m_txtCol.text = col.ToString();
        m_txtY.text = y.ToString();
        m_txtRow.text = row.ToString();

        m_txtMat.text = m_nuggets[nuggetIndex].m_presetN.ToString();
        m_txtShape.text = m_nuggets[nuggetIndex].m_shape.ToString();
    }

    #endregion

    [System.Serializable]
    public struct Nugget
    {
        public short m_presetN;
        public short m_shape;
    }

    [System.Serializable]
    public struct CreateResults
    {
        public int m_currentN;
        public Mesh[] m_meshes;
        public GameObject[] m_gameObjects;
    }

    [System.Serializable]
    public struct MaterialPreset
    {
        public string m_key;
        public short[] m_matNs;
    }

    [System.Serializable]
    public struct FaceIndexGroup
    {
        public bool m_used;
        public int[] m_faceIndexs;
        public int m_totalFaceIndexUsed;
    }

    [System.Serializable]
    public struct EvaluateResults
    {
        public Vector3[] m_vertices;
        public Vector3[] m_normals;
        public Vector2[] m_uvs;
        public Vector4[] m_tangents;
        public FaceIndexGroup[] m_faceIndexGroups;

        public Vector3[] m_tmpvertices;
        public Vector3[] m_tmpnormals;
        public Vector2[] m_tmpuvs;
        public FaceIndexGroup[] m_tmpfaceIndexGroups;

        public int m_vcnt;
        public int[] m_tficnt;
        public int m_matCnt;
        public int m_totalMatCnt;

        public int m_breakN;
        public int m_breakC;
        public int m_breakY;
        public int m_breakR;
        public bool m_hasMore;

        public void Initialize(int matCnt, int verticeLimit)
        {
            m_matCnt = matCnt;
            m_vertices = new Vector3[verticeLimit];
            m_normals = new Vector3[verticeLimit];
            m_uvs = new Vector2[verticeLimit];
            m_tangents = new Vector4[verticeLimit];
            m_faceIndexGroups = new FaceIndexGroup[m_matCnt];
            m_tmpfaceIndexGroups = new FaceIndexGroup[m_matCnt];

            for (int n = 0; n < m_faceIndexGroups.Length; ++n)
            {
                m_faceIndexGroups[n].m_faceIndexs = new int[verticeLimit * 6];
            }

            m_tficnt = new int[matCnt];
        }

        public void Reset(bool resetBreak = true)
        {
            m_hasMore = false;
            m_tficnt = new int[m_matCnt];
            m_vcnt = 0;
            m_totalMatCnt = 0;

            if (resetBreak)
            {
                m_breakN = 0;
                m_breakC = m_breakY = m_breakR = 0;
            }

            for (int n = 0; n < m_faceIndexGroups.Length; ++n)
            {
                m_faceIndexGroups[n].m_totalFaceIndexUsed = 0;
                m_faceIndexGroups[n].m_used = false;
            }
        }
    }

    public class BaseShape : ScriptableObject
    {
        protected MeshLibrary m_meshLibrary;
        public MaterialPreset[] m_presets;
        protected int[] m_vcntrefs;

        protected int m_scale;

        protected float m_xorg;
        protected float m_zorg;

        public virtual void Initialize(MaterialPreset[] presets, MeshLibrary meshLibrary,
            int scale, float xorg, float zorg)
        {
            m_vcntrefs = new int[2400];
            m_meshLibrary = meshLibrary;
            m_presets = presets;
            m_scale = scale;
            m_xorg = xorg;
            m_zorg = zorg;
        }

        public virtual void Evaluate(int c, int y, int r,
            float x, float z,
            ref Nugget[] neighbors, ref EvaluateResults results)
        {
            bool ceven = c % 2 == 0;
            Vector3 offset = new Vector3(m_xorg, 0f, m_zorg + (ceven ? 0.4330127f : 0f));
            try
            {
                short presetN = neighbors[0].m_presetN;
                MeshShape shape = m_meshLibrary.m_meshShapes.m_shapes[neighbors[0].m_shape];
                for (int n = 0; n < shape.m_parts.Length; ++n)
                {
                    MaterialPreset mp = m_presets[neighbors[shape.m_matSource[n]].m_presetN];
                    MeshPart p = shape.m_parts[n].m_oppositesPart.m_opposites[neighbors[(byte)shape.m_parts[n].m_side].m_shape];
                    ProcessSide(offset + new Vector3(x, y, z), p,
                        mp.m_matNs[shape.m_matNs[n]], ref results);
                }
            }
            catch(System.Exception ex)
            {
                Debug.LogError(ex.Message);
            }
            //try
            //{
            //    bool ceven = c % 2 == 0;
            //    Vector3 offset = new Vector3(m_xorg, 0f, m_zorg + (ceven ? 0.4330127f : 0f));
            //    bool n0 = neighbors[m_sn0].m_shape == 0;
            //    bool n1 = neighbors[m_sn1].m_shape == 0;
            //    bool n2 = neighbors[m_sn2].m_shape == 0;
            //    bool n3 = neighbors[m_sn3].m_shape == 0;
            //    bool n4 = neighbors[m_sn4].m_shape == 0;
            //    bool n5 = neighbors[m_sn5].m_shape == 0;
            //    bool n6 = neighbors[m_sn6].m_shape == 0;
            //    bool n7 = neighbors[m_sn7].m_shape == 0;

            //    if (n0)
            //    {
            //        CreateSide0(offset, x, y, z,
            //            m_presets[neighbors[0].m_presetN].m_matNs[0], ref results);
            //    }

            //    if (n1)
            //    {
            //        CreateSide1(offset, x, y, z,
            //            m_presets[neighbors[0].m_presetN].m_matNs[0], ref results);
            //    }

            //    if (n2)
            //    {
            //        CreateSide2(offset, x, y, z,
            //            m_presets[neighbors[0].m_presetN].m_matNs[0], ref results);
            //    }

            //    if (n3)
            //    {
            //        CreateSide3(offset, x, y, z,
            //            m_presets[neighbors[0].m_presetN].m_matNs[0], ref results);
            //    }

            //    if (n4)
            //    {
            //        CreateSide4(offset, x, y, z,
            //            m_presets[neighbors[0].m_presetN].m_matNs[0], ref results);
            //    }

            //    if (n5)
            //    {
            //        CreateSide5(offset, x, y, z,
            //            m_presets[neighbors[0].m_presetN].m_matNs[0], ref results);
            //    }

            //    if (n6)
            //    {
            //        CreateSide6(offset, x, y, z,
            //            m_presets[neighbors[0].m_presetN].m_matNs[1], ref results);
            //    }

            //    if (n7)
            //    {
            //        CreateSide7(offset, x, y, z,
            //            m_presets[neighbors[0].m_presetN].m_matNs[2], ref results);
            //    }
            //}
            //catch (System.Exception ex)
            //{
            //    Debug.LogError(ex.Message);
            //}

            //try
            //{

            //}
            //catch (System.Exception ex)
            //{
            //    Debug.LogError(ex.Message);
            //}
        }

        protected virtual void ProcessSide(Vector3 offset,
            MeshPart side, short matN,
            ref EvaluateResults results)
        {
            try
            {
                for (int n = 0; n < side.m_vertices.Length; ++n)
                {
                    try
                    {
                        results.m_vertices[results.m_vcnt] = side.m_vertices[n] + offset;
                        results.m_vertices[results.m_vcnt] *= m_scale;
                        results.m_normals[results.m_vcnt] = side.m_normals[n];
                        results.m_tangents[results.m_vcnt] = side.m_tangents[n];
                        results.m_uvs[results.m_vcnt] = side.m_uvs[n];
                        m_vcntrefs[n] = results.m_vcnt;
                        ++results.m_vcnt;
                    }
                    catch(System.Exception ex)
                    {
                        Debug.LogError(ex.Message);
                    }
                }

                for (int n = 0; n < side.m_faceIndexs.Length; ++n)
                {
                    try
                    {
                        ++results.m_faceIndexGroups[matN].m_totalFaceIndexUsed;
                        results.m_faceIndexGroups[matN].m_used = true;
                        results.m_faceIndexGroups[matN].m_faceIndexs[results.m_tficnt[matN]] =
                            m_vcntrefs[side.m_faceIndexs[n]];
                        ++results.m_tficnt[matN];
                    }
                    catch(System.Exception ex)
                    {
                        Debug.LogError(ex.Message);
                    }
                }
            }
            catch(System.Exception ex)
            {
                Debug.LogError(ex.Message);
            }
        }

        public virtual void EvaluatePreview(ref EvaluateResults results)
        {
            try
            {
                CreateSide0(Vector3.zero, 0, 0, 0, 0, ref results);
                CreateSide1(Vector3.zero, 0, 0, 0, 0, ref results);
                CreateSide2(Vector3.zero, 0, 0, 0, 0, ref results);
                CreateSide3(Vector3.zero, 0, 0, 0, 0, ref results);
                CreateSide4(Vector3.zero, 0, 0, 0, 0, ref results);
                CreateSide5(Vector3.zero, 0, 0, 0, 0, ref results);
                CreateSide6(Vector3.zero, 0, 0, 0, 0, ref results);
                CreateSide7(Vector3.zero, 0, 0, 0, 0, ref results);
            }
            catch (System.Exception ex)
            {
                Debug.LogError(ex.Message);
            }
        }

        protected void CreateSide0(Vector3 offset,
            float x, int y, float z, int matN,
            ref EvaluateResults results)
        {
            try
            {
                results.m_vertices[results.m_vcnt] = new Vector3(x + 0.25f, y, z) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(0.25f, 0f);
                results.m_normals[results.m_vcnt] = new Vector3(0f, 0f, -1f);
                m_vcntrefs[0] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x + 0.25f, y + 1f, z) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(0.25f, 1f);
                results.m_normals[results.m_vcnt] = new Vector3(0f, 0f, -1f);
                m_vcntrefs[1] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x + 0.75f, y + 1f, z) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(0.75f, 1f);
                results.m_normals[results.m_vcnt] = new Vector3(0f, 0f, -1f);
                m_vcntrefs[2] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x + 0.75f, y, z) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(0.75f, 0f);
                results.m_normals[results.m_vcnt] = new Vector3(0f, 0f, -1f);
                m_vcntrefs[3] = results.m_vcnt;
                ++results.m_vcnt;
            }
            catch (System.Exception ex)
            {
                Debug.LogError(ex.Message);
            }

            try
            {
                int[] faceindexs = new int[]
                {
                    0, 1, 2,
                    0, 2, 3,
                };
                for (int n = 0; n < faceindexs.Length; ++n)
                {
                    try
                    {
                        ++results.m_faceIndexGroups[matN].m_totalFaceIndexUsed;
                        results.m_faceIndexGroups[matN].m_used = true;
                        results.m_faceIndexGroups[matN].m_faceIndexs[results.m_tficnt[matN]] =
                            m_vcntrefs[faceindexs[n]];
                        ++results.m_tficnt[matN];
                    }
                    catch (System.Exception ex)
                    {
                        Debug.LogError(ex.Message);
                    }
                }
            }
            catch (System.Exception ex)
            {
                Debug.LogError(ex.Message);
            }
        }

        protected void CreateSide1(Vector3 offset,
            float x, int y, float z, int matN,
            ref EvaluateResults results)
        {

            try
            {
                results.m_vertices[results.m_vcnt] = new Vector3(x, y, z + 0.4330127f) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(0.25f, 0f);
                results.m_normals[results.m_vcnt] = new Vector3(-0.7f, 0f, -0.7f);
                m_vcntrefs[0] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x, y + 1f, z + 0.4330127f) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(0.25f, 1f);
                results.m_normals[results.m_vcnt] = new Vector3(-0.7f, 0f, -0.7f);
                m_vcntrefs[1] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x + 0.25f, y + 1f, z) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(0.75f, 1f);
                results.m_normals[results.m_vcnt] = new Vector3(-0.7f, 0f, -0.7f);
                m_vcntrefs[2] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x + 0.25f, y, z) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(0.75f, 0f);
                results.m_normals[results.m_vcnt] = new Vector3(-0.7f, 0f, -0.7f);
                m_vcntrefs[3] = results.m_vcnt;
                ++results.m_vcnt;
            }
            catch (System.Exception ex)
            {
                Debug.LogError(ex.Message);
            }

            try
            {
                int[] faceindexs = new int[]
                {
                    0, 1, 2,
                    0, 2, 3,
                };
                for (int n = 0; n < faceindexs.Length; ++n)
                {
                    try
                    {
                        ++results.m_faceIndexGroups[matN].m_totalFaceIndexUsed;
                        results.m_faceIndexGroups[matN].m_used = true;
                        results.m_faceIndexGroups[matN].m_faceIndexs[results.m_tficnt[matN]] =
                            m_vcntrefs[faceindexs[n]];
                        ++results.m_tficnt[matN];
                    }
                    catch (System.Exception ex)
                    {
                        Debug.LogError(ex.Message);
                    }
                }
            }
            catch (System.Exception ex)
            {
                Debug.LogError(ex.Message);
            }
        }

        protected void CreateSide2(Vector3 offset,
            float x, int y, float z, int matN,
            ref EvaluateResults results)
        {

            try
            {
                results.m_vertices[results.m_vcnt] = new Vector3(x + 0.25f, y, z + 0.8660254f) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(0.25f, 0f);
                results.m_normals[results.m_vcnt] = new Vector3(-0.7f, 0f, 0.7f);
                m_vcntrefs[0] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x + 0.25f, y + 1f, z + 0.8660254f) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(0.25f, 1f);
                results.m_normals[results.m_vcnt] = new Vector3(-0.7f, 0f, 0.7f);
                m_vcntrefs[1] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x, y + 1f, z + 0.4330127f) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(0.75f, 1f);
                results.m_normals[results.m_vcnt] = new Vector3(-0.7f, 0f, 0.7f);
                m_vcntrefs[2] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x, y, z + 0.4330127f) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(0.75f, 0f);
                results.m_normals[results.m_vcnt] = new Vector3(-0.7f, 0f, 0.7f);
                m_vcntrefs[3] = results.m_vcnt;
                ++results.m_vcnt;
            }
            catch (System.Exception ex)
            {
                Debug.LogError(ex.Message);
            }

            try
            {
                int[] faceindexs = new int[]
                {
                    0, 1, 2,
                    0, 2, 3,
                };
                for (int n = 0; n < faceindexs.Length; ++n)
                {
                    try
                    {
                        ++results.m_faceIndexGroups[matN].m_totalFaceIndexUsed;
                        results.m_faceIndexGroups[matN].m_used = true;
                        results.m_faceIndexGroups[matN].m_faceIndexs[results.m_tficnt[matN]] =
                            m_vcntrefs[faceindexs[n]];
                        ++results.m_tficnt[matN];
                    }
                    catch (System.Exception ex)
                    {
                        Debug.LogError(ex.Message);
                    }
                }
            }
            catch (System.Exception ex)
            {
                Debug.LogError(ex.Message);
            }
        }

        protected void CreateSide3(Vector3 offset,
            float x, int y, float z, int matN,
            ref EvaluateResults results)
        {

            try
            {
                results.m_vertices[results.m_vcnt] = new Vector3(x + 0.75f, y, z + 0.8660254f) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(0.25f, 0f);
                results.m_normals[results.m_vcnt] = new Vector3(0f, 0f, 1f);
                m_vcntrefs[0] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x + 0.75f, y + 1f, z + 0.8660254f) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(0.25f, 1f);
                results.m_normals[results.m_vcnt] = new Vector3(0f, 0f, 1f);
                m_vcntrefs[1] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x + 0.25f, y + 1f, z + 0.8660254f) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(0.75f, 1f);
                results.m_normals[results.m_vcnt] = new Vector3(0f, 0f, 1f);
                m_vcntrefs[2] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x + 0.25f, y, z + 0.8660254f) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(0.75f, 0f);
                results.m_normals[results.m_vcnt] = new Vector3(0f, 0f, 1f);
                m_vcntrefs[3] = results.m_vcnt;
                ++results.m_vcnt;
            }
            catch (System.Exception ex)
            {
                Debug.LogError(ex.Message);
            }

            try
            {
                int[] faceindexs = new int[]
                {
                    0, 1, 2,
                    0, 2, 3,
                };
                for (int n = 0; n < faceindexs.Length; ++n)
                {
                    try
                    {
                        ++results.m_faceIndexGroups[matN].m_totalFaceIndexUsed;
                        results.m_faceIndexGroups[matN].m_used = true;
                        results.m_faceIndexGroups[matN].m_faceIndexs[results.m_tficnt[matN]] =
                            m_vcntrefs[faceindexs[n]];
                        ++results.m_tficnt[matN];
                    }
                    catch (System.Exception ex)
                    {
                        Debug.LogError(ex.Message);
                    }
                }
            }
            catch (System.Exception ex)
            {
                Debug.LogError(ex.Message);
            }
        }

        protected void CreateSide4(Vector3 offset,
            float x, int y, float z, int matN,
            ref EvaluateResults results)
        {

            try
            {
                results.m_vertices[results.m_vcnt] = new Vector3(x + 1f, y, z + 0.4330127f) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(0.25f, 0f);
                results.m_normals[results.m_vcnt] = new Vector3(0.7f, 0f, 0.7f);
                m_vcntrefs[0] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x + 1f, y + 1f, z + 0.4330127f) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(0.25f, 1f);
                results.m_normals[results.m_vcnt] = new Vector3(0.7f, 0f, 0.7f);
                m_vcntrefs[1] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x + 0.75f, y + 1f, z + 0.8660254f) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(0.75f, 1f);
                results.m_normals[results.m_vcnt] = new Vector3(0.7f, 0f, 0.7f);
                m_vcntrefs[2] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x + 0.75f, y, z + 0.8660254f) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(0.75f, 0f);
                results.m_normals[results.m_vcnt] = new Vector3(0.7f, 0f, 0.7f);
                m_vcntrefs[3] = results.m_vcnt;
                ++results.m_vcnt;
            }
            catch (System.Exception ex)
            {
                Debug.LogError(ex.Message);
            }

            try
            {
                int[] faceindexs = new int[]
                {
                    0, 1, 2,
                    0, 2, 3,
                };
                for (int n = 0; n < faceindexs.Length; ++n)
                {
                    try
                    {
                        ++results.m_faceIndexGroups[matN].m_totalFaceIndexUsed;
                        results.m_faceIndexGroups[matN].m_used = true;
                        results.m_faceIndexGroups[matN].m_faceIndexs[results.m_tficnt[matN]] =
                            m_vcntrefs[faceindexs[n]];
                        ++results.m_tficnt[matN];
                    }
                    catch (System.Exception ex)
                    {
                        Debug.LogError(ex.Message);
                    }
                }
            }
            catch (System.Exception ex)
            {
                Debug.LogError(ex.Message);
            }
        }

        protected void CreateSide5(Vector3 offset,
            float x, int y, float z, int matN,
            ref EvaluateResults results)
        {
            try
            {
                results.m_vertices[results.m_vcnt] = new Vector3(x + 0.75f, y, z) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(0.25f, 0f);
                results.m_normals[results.m_vcnt] = new Vector3(0.7f, 0f, -0.7f);
                m_vcntrefs[0] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x + 0.75f, y + 1f, z) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(0.25f, 1f);
                results.m_normals[results.m_vcnt] = new Vector3(0.7f, 0f, -0.7f);
                m_vcntrefs[1] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x + 1f, y + 1f, z + 0.4330127f) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(0.75f, 1f);
                results.m_normals[results.m_vcnt] = new Vector3(0.7f, 0f, -0.7f);
                m_vcntrefs[2] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x + 1f, y, z + 0.4330127f) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(0.75f, 0f);
                results.m_normals[results.m_vcnt] = new Vector3(0.7f, 0f, -0.7f);
                m_vcntrefs[3] = results.m_vcnt;
                ++results.m_vcnt;
            }
            catch (System.Exception ex)
            {
                Debug.LogError(ex.Message);
            }

            try
            {
                int[] faceindexs = new int[]
                {
                    0, 1, 2,
                    0, 2, 3,
                };
                for (int n = 0; n < faceindexs.Length; ++n)
                {
                    try
                    {
                        ++results.m_faceIndexGroups[matN].m_totalFaceIndexUsed;
                        results.m_faceIndexGroups[matN].m_used = true;
                        results.m_faceIndexGroups[matN].m_faceIndexs[results.m_tficnt[matN]] =
                            m_vcntrefs[faceindexs[n]];
                        ++results.m_tficnt[matN];
                    }
                    catch (System.Exception ex)
                    {
                        Debug.LogError(ex.Message);
                    }
                }
            }
            catch (System.Exception ex)
            {
                Debug.LogError(ex.Message);
            }
        }

        protected void CreateSide6(Vector3 offset,
            float x, int y, float z, int matN,
            ref EvaluateResults results)
        {
            try
            {
                results.m_vertices[results.m_vcnt] = new Vector3(x + 0.25f, y + 1f, z) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(x + 0.25f, z);
                results.m_normals[results.m_vcnt] = new Vector3(0f, 1f, 0f);
                m_vcntrefs[0] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x, y + 1f, z + 0.4330127f) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(x, z + 0.4330127f);
                results.m_normals[results.m_vcnt] = new Vector3(0f, 1f, 0f);
                m_vcntrefs[1] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x + 0.25f, y + 1f, z + 0.8660254f) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(x + 0.25f, z + 0.8660254f);
                results.m_normals[results.m_vcnt] = new Vector3(0f, 1f, 0f);
                m_vcntrefs[2] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x + 0.75f, y + 1f, z + 0.8660254f) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(x + 0.75f, z + 0.8660254f);
                results.m_normals[results.m_vcnt] = new Vector3(0f, 1f, 0f);
                m_vcntrefs[3] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x + 1f, y + 1f, z + 0.4330127f) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(x + 1f, z + 0.4330127f);
                results.m_normals[results.m_vcnt] = new Vector3(0f, 1f, 0f);
                m_vcntrefs[4] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x + 0.75f, y + 1f, z) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(x + 0.75f, z);
                results.m_normals[results.m_vcnt] = new Vector3(0f, 1f, 0f);
                m_vcntrefs[5] = results.m_vcnt;
                ++results.m_vcnt;
            }
            catch (System.Exception ex)
            {
                Debug.LogError(ex.Message);
            }

            try
            {
                int[] faceindexs = new int[]
                {
                    0, 1, 2,
                    0, 2, 3,
                    0, 3, 4,
                    0, 4, 5,
                };
                for (int n = 0; n < faceindexs.Length; ++n)
                {
                    try
                    {
                        ++results.m_faceIndexGroups[matN].m_totalFaceIndexUsed;
                        results.m_faceIndexGroups[matN].m_used = true;
                        results.m_faceIndexGroups[matN].m_faceIndexs[results.m_tficnt[matN]] =
                            m_vcntrefs[faceindexs[n]];
                        ++results.m_tficnt[matN];
                    }
                    catch (System.Exception ex)
                    {
                        Debug.LogError(ex.Message);
                    }
                }
            }
            catch (System.Exception ex)
            {
                Debug.LogError(ex.Message);
            }
        }

        protected void CreateSide7(Vector3 offset,
            float x, int y, float z, int matN,
            ref EvaluateResults results)
        {
            try
            {
                results.m_vertices[results.m_vcnt] = new Vector3(x + 0.25f, y, z) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(x + 0.25f, z);
                results.m_normals[results.m_vcnt] = new Vector3(0f, -1f, 0f);
                m_vcntrefs[0] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x, y, z + 0.4330127f) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(x, z + 0.4330127f);
                results.m_normals[results.m_vcnt] = new Vector3(0f, -1f, 0f);
                m_vcntrefs[1] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x + 0.25f, y, z + 0.8660254f) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(x + 0.25f, z + 0.8660254f);
                results.m_normals[results.m_vcnt] = new Vector3(0f, -1f, 0f);
                m_vcntrefs[2] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x + 0.75f, y, z + 0.8660254f) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(x + 0.75f, z + 0.8660254f);
                results.m_normals[results.m_vcnt] = new Vector3(0f, -1f, 0f);
                m_vcntrefs[3] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x + 1f, y, z + 0.4330127f) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(x + 1f, z + 0.4330127f);
                results.m_normals[results.m_vcnt] = new Vector3(0f, -1f, 0f);
                m_vcntrefs[4] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x + 0.75f, y, z) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(x + 0.75f, z);
                results.m_normals[results.m_vcnt] = new Vector3(0f, -1f, 0f);
                m_vcntrefs[5] = results.m_vcnt;
                ++results.m_vcnt;
            }
            catch (System.Exception ex)
            {
                Debug.LogError(ex.Message);
            }

            try
            {
                int[] faceindexs = new int[]
                {
                     2, 1, 0,
                     3, 2, 0,
                     4, 3, 0,
                     5, 4, 0,
                };
                for (int n = 0; n < faceindexs.Length; ++n)
                {
                    try
                    {
                        ++results.m_faceIndexGroups[matN].m_totalFaceIndexUsed;
                        results.m_faceIndexGroups[matN].m_used = true;
                        results.m_faceIndexGroups[matN].m_faceIndexs[results.m_tficnt[matN]] =
                            m_vcntrefs[faceindexs[n]];
                        ++results.m_tficnt[matN];
                    }
                    catch (System.Exception ex)
                    {
                        Debug.LogError(ex.Message);
                    }
                }
            }
            catch (System.Exception ex)
            {
                Debug.LogError(ex.Message);
            }
        }
    }
}