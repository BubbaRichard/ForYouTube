﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using static Common;

public class VSLab1 : MonoBehaviour
{
    public const int m_nuggetCount = 16;
    public const int m_levelSize = 256;
    public const int m_verticeLimit = 30000;

    public enum State
    {
        Paused,
        Generate,
        Generating,
        PreEvaluate,
        PreEvaluating,
        Evaluate,
        Evaluating,
        PostEvaluate,
        PostEvaluating,
        CreateMesh0,
        CreatingMesh0,
        CreateMesh1,
        CreatingMesh1,
        Error,
    }
    public State m_state;

    public enum InputMode
    {
        None,
        Place,
        Material,
        Erase,
        Identify,
    }
    public InputMode m_inputMode;

    public MeshLibrary m_meshLibrary;
    public CharacterCamera m_character;
    public CreateResults m_createResults;
    public EvaluateResults m_evaluateResults;
    public BaseShape m_baseShape;

    public MapLevel m_mapLevel;
    public Nugget[] m_nuggets;
    public byte[] m_heightMap;

    public Material[] m_materials;
    public MaterialPreset[] m_materialPresets;

    public int m_xorg;
    public int m_zorg;

    public int m_column;
    public int m_row;
    public int m_index;

    public int m_x;
    public int m_y;
    public int m_z;

    public float m_nrmX;
    public float m_nrmY;
    public float m_nrmZ;

    public int m_pickedColumn;
    public int m_pickedY;
    public int m_pickedRow;

    public bool m_generated;
    public bool m_created;

    public GameObject m_preview;
    public Material m_previewMaterial;

    public float m_clickDistance = 500f;
    public bool m_nuggetMode;
    public int m_nuggetDistance = 5;

    public short m_selectedPresetN = 0;
    public short m_selectedShapeN = 0;

    // Start is called before the first frame update
    void Start()
    {
        m_createResults.m_gameObjects = new GameObject[]
        {
            new GameObject("child0"),
        };
        m_createResults.m_meshes = new Mesh[]
        {
            new Mesh(),
        };
        m_createResults.m_gameObjects[0].transform.SetParent(transform);
        m_createResults.m_gameObjects[0].AddComponent<MeshCollider>();
        m_createResults.m_gameObjects[0].AddComponent<MeshRenderer>();
        MeshFilter mf = m_createResults.m_gameObjects[0].AddComponent<MeshFilter>();
        mf.sharedMesh = m_createResults.m_meshes[0];

        m_evaluateResults.Initialize(m_materials.Length, m_verticeLimit);

        m_xorg = m_column * m_nuggetCount;
        m_zorg = m_row * m_nuggetCount;

        m_baseShape = ScriptableObject.CreateInstance<BaseShape>();
        m_baseShape.Initialize(m_materialPresets, m_meshLibrary, m_mapLevel.m_scale, m_xorg, m_zorg);
    }

    // Update is called once per frame
    void Update()
    {
        switch (m_state)
        {
            case State.Generate:
                m_state = State.Generating;
                Generate();
                break;
            case State.PreEvaluate:
                m_state = State.PreEvaluating;
                PreEvaluate();
                break;
            case State.Evaluate:
                m_state = State.Evaluating;
                Evaluate();
                break;
            case State.PostEvaluate:
                m_state = State.PostEvaluating;
                PostEvaluate();
                break;
            case State.CreateMesh0:
                m_state = State.CreatingMesh0;
                CreateMesh0();
                break;
            case State.CreateMesh1:
                m_state = State.CreatingMesh1;
                CreateMesh1();
                break;
        }
        if (m_state == State.Paused && m_inputMode != InputMode.None)
            HandleInput();
        else if (m_preview != null)
            DestroyImmediate(m_preview);
    }

    private void HandleInput()
    {
        if (m_preview == null)
            CreatePreview();
        Vector3 mp = Input.mousePosition;
        if (mp.x > 200)
        {
            Ray ray = m_character.m_camera.ScreenPointToRay(mp);
            if (!m_nuggetMode)
            {
                if (Physics.Raycast(ray, out RaycastHit hitinfo, m_clickDistance,
                    -1, QueryTriggerInteraction.Collide))
                {
                    if (hitinfo.collider.gameObject.transform.parent != null)
                    {
                        Vector3 point = hitinfo.point;
                        Vector3 normal = hitinfo.normal;
                        m_x = (int)point.x / m_mapLevel.m_scale;
                        m_y = (int)point.y / m_mapLevel.m_scale;
                        m_z = (int)point.z / m_mapLevel.m_scale;

                        m_nrmX = normal.x.Round(5);
                        m_nrmY = normal.y.Round(5);
                        m_nrmZ = normal.z.Round(5);

                        VSLab1 chunk = hitinfo.collider.gameObject.transform.parent.GetComponent<VSLab1>();
                        if (chunk != null)
                        {
                            m_pickedColumn = m_x - m_xorg;
                            m_pickedY = m_y;
                            m_pickedRow = m_z - m_zorg;
                        }
                        if (m_inputMode == InputMode.Place)
                            HandlePlace(m_pickedColumn, m_pickedY, m_pickedRow, m_nrmX, m_nrmY, m_nrmZ);
                        else
                            HandleInner(m_pickedColumn, m_pickedY, m_pickedRow, m_nrmX, m_nrmY, m_nrmZ);
                    }
                }
            }
            else
            {
                Vector3 point = ray.GetPoint(m_character.m_scrollDelta * m_mapLevel.m_scale);
                m_x = (int)point.x / m_mapLevel.m_scale;
                m_y = (int)point.y / m_mapLevel.m_scale;
                m_z = (int)point.z / m_mapLevel.m_scale;

                m_pickedColumn = m_x - m_xorg;
                m_pickedY = m_y;
                m_pickedRow = m_z - m_zorg;

                HandleNuggetMode(m_pickedColumn, m_pickedY, m_pickedRow);
            }
        }
    }

    private void HandleNuggetMode(int pickedColumn, int pickedY, int pickedRow)
    {
        int nuggetIndex = GetCRIndex(pickedColumn, pickedY, pickedRow, m_nuggetCount, m_levelSize);
        if (nuggetIndex > -1 && nuggetIndex < m_nuggets.Length)
        {
            if (Input.GetMouseButtonDown(0))
            {
                if (m_inputMode == InputMode.Place)
                {
                    m_nuggets[nuggetIndex].m_shape = m_selectedShapeN;
                    m_nuggets[nuggetIndex].m_presetN = m_selectedPresetN;
                    m_state = State.PreEvaluate;
                }
                else if (m_inputMode == InputMode.Erase)
                {
                    m_nuggets[nuggetIndex].m_shape = 0;
                    m_state = State.PreEvaluate;
                }
                else if (m_inputMode == InputMode.Material)
                {
                    m_nuggets[nuggetIndex].m_presetN = m_selectedPresetN;
                    m_state = State.PreEvaluate;
                }
                else
                {
                    SetIndetify(nuggetIndex, pickedColumn, pickedY, pickedRow);
                }
            }
        }
        m_preview.transform.position = new Vector3(pickedColumn * m_mapLevel.m_scale, pickedY * m_mapLevel.m_scale, pickedRow * m_mapLevel.m_scale);
    }

    private void HandleInner(int nuggetIndex, int c, int y, int r)
    {
        if (m_inputMode == InputMode.Erase)
        {
            m_nuggets[nuggetIndex].m_shape = 0;
            m_state = State.PreEvaluate;
        }
        else if (m_inputMode == InputMode.Material)
        {
            m_nuggets[nuggetIndex].m_presetN = m_selectedPresetN;
            m_state = State.PreEvaluate;
        }
        else
        {
            SetIndetify(nuggetIndex, c, y, r);
        }
    }

    private void HandleInner(int pickedColumn, int pickedY, int pickedRow, float nrmX, float nrmY, float nrmZ)
    {
        int nuggetIndex = GetCRIndex(pickedColumn, pickedY, pickedRow, m_nuggetCount, m_levelSize);
        if (nuggetIndex > -1 && nuggetIndex < m_nuggets.Length)
        {
            if (nrmX > 0f)
                HandleInnerPosX(nuggetIndex, pickedColumn, pickedY, pickedRow);
            else if (nrmX < 0f)
                HandleInnerNegX(nuggetIndex, pickedColumn, pickedY, pickedRow);
            else if (nrmY > 0f)
                HandleInnerPosY(nuggetIndex, pickedColumn, pickedY, pickedRow);
            else if (nrmY < 0f)
                HandleInnerNegY(nuggetIndex, pickedColumn, pickedY, pickedRow);
            else if (nrmZ > 0f)
                HandleInnerPosZ(nuggetIndex, pickedColumn, pickedY, pickedRow);
            else if (nrmZ < 0f)
                HandleInnerNegZ(nuggetIndex, pickedColumn, pickedY, pickedRow);
        }
        else if (pickedColumn > -1 && pickedRow > -1)
        {
            m_preview.transform.position = new Vector3(pickedColumn * m_mapLevel.m_scale, pickedY * m_mapLevel.m_scale, pickedRow * m_mapLevel.m_scale);
        }
    }

    private void HandleInnerPosX(int nuggetIndex, int pickedColumn, int pickedY, int pickedRow)
    {
        while (nuggetIndex < m_nuggets.Length && nuggetIndex > -1 && m_nuggets[nuggetIndex].m_shape == 0)
            --nuggetIndex;

        if (nuggetIndex < m_nuggets.Length && nuggetIndex > -1)
        {
            GetCROut(nuggetIndex, m_nuggetCount, m_levelSize, out int c, out int y, out int r);
            if (Input.GetMouseButtonDown(0))
            {
                HandleInner(nuggetIndex, c, y, r);
            }
            m_preview.transform.position = new Vector3((c + m_xorg) * m_mapLevel.m_scale, y * m_mapLevel.m_scale, (r + m_zorg) * m_mapLevel.m_scale);
        }
        else if (pickedColumn > -1 && pickedRow > -1)
        {
            m_preview.transform.position = new Vector3((pickedColumn + m_xorg) * m_mapLevel.m_scale, pickedY * m_mapLevel.m_scale, (pickedRow + m_zorg) * m_mapLevel.m_scale);
        }
    }

    private void HandleInnerNegX(int nuggetIndex, int pickedColumn, int pickedY, int pickedRow)
    {
        while (nuggetIndex < m_nuggets.Length && nuggetIndex > -1 && m_nuggets[nuggetIndex].m_shape == 0)
            ++nuggetIndex;

        if (nuggetIndex < m_nuggets.Length && nuggetIndex > -1)
        {
            GetCROut(nuggetIndex, m_nuggetCount, m_levelSize, out int c, out int y, out int r);
            if (Input.GetMouseButtonDown(0))
            {
                HandleInner(nuggetIndex, c, y, r);
            }
            m_preview.transform.position = new Vector3((c + m_xorg) * m_mapLevel.m_scale, y * m_mapLevel.m_scale, (r + m_zorg) * m_mapLevel.m_scale);
        }
        else if (pickedColumn > -1 && pickedRow > -1)
        {
            m_preview.transform.position = new Vector3((pickedColumn + m_xorg) * m_mapLevel.m_scale, pickedY * m_mapLevel.m_scale, (pickedRow + m_zorg) * m_mapLevel.m_scale);
        }
    }

    private void HandleInnerPosY(int nuggetIndex, int pickedColumn, int pickedY, int pickedRow)
    {
        while (nuggetIndex < m_nuggets.Length && nuggetIndex > -1 && m_nuggets[nuggetIndex].m_shape == 0)
            nuggetIndex -= m_levelSize;

        if (nuggetIndex < m_nuggets.Length && nuggetIndex > -1)
        {
            GetCROut(nuggetIndex, m_nuggetCount, m_levelSize, out int c, out int y, out int r);
            if (Input.GetMouseButtonDown(0))
            {
                HandleInner(nuggetIndex, c, y, r);
            }
            m_preview.transform.position = new Vector3((c + m_xorg) * m_mapLevel.m_scale, y * m_mapLevel.m_scale, (r + m_zorg) * m_mapLevel.m_scale);
        }
        else if (pickedColumn > -1 && pickedRow > -1)
        {
            m_preview.transform.position = new Vector3((pickedColumn + m_xorg) * m_mapLevel.m_scale, pickedY * m_mapLevel.m_scale, (pickedRow + m_zorg) * m_mapLevel.m_scale);
        }
    }

    private void HandleInnerNegY(int nuggetIndex, int pickedColumn, int pickedY, int pickedRow)
    {
        while (nuggetIndex < m_nuggets.Length && nuggetIndex > -1 && m_nuggets[nuggetIndex].m_shape == 0)
            nuggetIndex += m_levelSize;

        if (nuggetIndex < m_nuggets.Length && nuggetIndex > -1)
        {
            GetCROut(nuggetIndex, m_nuggetCount, m_levelSize, out int c, out int y, out int r);
            if (Input.GetMouseButtonDown(0))
            {
                HandleInner(nuggetIndex, c, y, r);
            }
            m_preview.transform.position = new Vector3((c + m_xorg) * m_mapLevel.m_scale, y * m_mapLevel.m_scale, (r + m_zorg) * m_mapLevel.m_scale);
        }
        else if (pickedColumn > -1 && pickedRow > -1)
        {
            m_preview.transform.position = new Vector3((pickedColumn + m_xorg) * m_mapLevel.m_scale, pickedY * m_mapLevel.m_scale, (pickedRow + m_zorg) * m_mapLevel.m_scale);
        }
    }

    private void HandleInnerPosZ(int nuggetIndex, int pickedColumn, int pickedY, int pickedRow)
    {
        while (nuggetIndex < m_nuggets.Length && nuggetIndex > -1 && m_nuggets[nuggetIndex].m_shape == 0)
            nuggetIndex -= m_nuggetCount;

        if (nuggetIndex < m_nuggets.Length && nuggetIndex > -1)
        {
            GetCROut(nuggetIndex, m_nuggetCount, m_levelSize, out int c, out int y, out int r);
            if (Input.GetMouseButtonDown(0))
            {
                HandleInner(nuggetIndex, c, y, r);
            }
            m_preview.transform.position = new Vector3((c + m_xorg) * m_mapLevel.m_scale, y * m_mapLevel.m_scale, (r + m_zorg) * m_mapLevel.m_scale);
        }
        else if (pickedColumn > -1 && pickedRow > -1)
        {
            m_preview.transform.position = new Vector3((pickedColumn + m_xorg) * m_mapLevel.m_scale, pickedY * m_mapLevel.m_scale, (pickedRow + m_zorg) * m_mapLevel.m_scale);
        }
    }

    private void HandleInnerNegZ(int nuggetIndex, int pickedColumn, int pickedY, int pickedRow)
    {
        while (nuggetIndex < m_nuggets.Length && nuggetIndex > -1 && m_nuggets[nuggetIndex].m_shape == 0)
            nuggetIndex += m_nuggetCount;

        if (nuggetIndex < m_nuggets.Length && nuggetIndex > -1)
        {
            GetCROut(nuggetIndex, m_nuggetCount, m_levelSize, out int c, out int y, out int r);
            if (Input.GetMouseButtonDown(0))
            {
                HandleInner(nuggetIndex, c, y, r);
            }
            m_preview.transform.position = new Vector3((c + m_xorg) * m_mapLevel.m_scale, y * m_mapLevel.m_scale, (r + m_zorg) * m_mapLevel.m_scale);
        }
        else if (pickedColumn > -1 && pickedRow > -1)
        {
            m_preview.transform.position = new Vector3((pickedColumn + m_xorg) * m_mapLevel.m_scale, pickedY * m_mapLevel.m_scale, (pickedRow + m_zorg) * m_mapLevel.m_scale);
        }
    }


    private void HandlePlace(int pickedColumn, int pickedY, int pickedRow, float nrmX, float nrmY, float nrmZ)
    {
        int nuggetIndex = GetCRIndex(pickedColumn, pickedY, pickedRow, m_nuggetCount, m_levelSize);
        if (nuggetIndex > -1 && nuggetIndex < m_nuggets.Length)
        {
            if (nrmX > 0f)
                HandlePlacePosX(nuggetIndex, pickedColumn, pickedY, pickedRow);
            else if (nrmX < 0f)
                HandlePlaceNegX(nuggetIndex, pickedColumn, pickedY, pickedRow);
            else if (nrmY > 0f)
                HandlePlacePosY(nuggetIndex, pickedColumn, pickedY, pickedRow);
            else if (nrmY < 0f)
                HandlePlaceNegY(nuggetIndex, pickedColumn, pickedY, pickedRow);
            else if (nrmZ > 0f)
                HandlePlacePosZ(nuggetIndex, pickedColumn, pickedY, pickedRow);
            else if (nrmZ < 0f)
                HandlePlaceNegZ(nuggetIndex, pickedColumn, pickedY, pickedRow);
        }
        else if (pickedColumn > -1 && pickedRow > -1)
        {
            m_preview.transform.position = new Vector3(pickedColumn * m_mapLevel.m_scale, pickedY * m_mapLevel.m_scale, pickedRow * m_mapLevel.m_scale);
        }
    }

    private void HandlePlacePosX(int nuggetIndex, int pickedColumn, int pickedY, int pickedRow)
    {
        while (nuggetIndex < m_nuggets.Length && nuggetIndex > -1 && m_nuggets[nuggetIndex].m_shape != 0)
            ++nuggetIndex;

        if (nuggetIndex < m_nuggets.Length && nuggetIndex > -1)
        {
            GetCROut(nuggetIndex, m_nuggetCount, m_levelSize, out int c, out int y, out int r);
            if (Input.GetMouseButtonDown(0))
            {
                m_nuggets[nuggetIndex].m_shape = m_selectedShapeN;
                m_nuggets[nuggetIndex].m_presetN = m_selectedPresetN;
                m_state = State.PreEvaluate;
            }
            m_preview.transform.position = new Vector3((c + m_xorg) * m_mapLevel.m_scale, y * m_mapLevel.m_scale, (r + m_zorg) * m_mapLevel.m_scale);
        }
        else if (pickedColumn > -1 && pickedRow > -1)
        {
            m_preview.transform.position = new Vector3((pickedColumn + m_xorg) * m_mapLevel.m_scale, pickedY * m_mapLevel.m_scale, (pickedRow + m_zorg) * m_mapLevel.m_scale);
        }
    }

    private void HandlePlaceNegX(int nuggetIndex, int pickedColumn, int pickedY, int pickedRow)
    {
        while (nuggetIndex < m_nuggets.Length && nuggetIndex > -1 && m_nuggets[nuggetIndex].m_shape != 0)
            --nuggetIndex;

        if (nuggetIndex < m_nuggets.Length && nuggetIndex > -1)
        {
            GetCROut(nuggetIndex, m_nuggetCount, m_levelSize, out int c, out int y, out int r);
            if (Input.GetMouseButtonDown(0))
            {
                m_nuggets[nuggetIndex].m_shape = m_selectedShapeN;
                m_nuggets[nuggetIndex].m_presetN = m_selectedPresetN;
                m_state = State.PreEvaluate;
            }
            m_preview.transform.position = new Vector3((c + m_xorg) * m_mapLevel.m_scale, y * m_mapLevel.m_scale, (r + m_zorg) * m_mapLevel.m_scale);
        }
        else if (pickedColumn > -1 && pickedRow > -1)
        {
            m_preview.transform.position = new Vector3((pickedColumn + m_xorg) * m_mapLevel.m_scale, pickedY * m_mapLevel.m_scale, (pickedRow + m_zorg) * m_mapLevel.m_scale);
        }
    }

    private void HandlePlacePosY(int nuggetIndex, int pickedColumn, int pickedY, int pickedRow)
    {
        while (nuggetIndex < m_nuggets.Length && nuggetIndex > -1 && m_nuggets[nuggetIndex].m_shape != 0)
            nuggetIndex += m_levelSize;

        if (nuggetIndex < m_nuggets.Length && nuggetIndex > -1)
        {
            GetCROut(nuggetIndex, m_nuggetCount, m_levelSize, out int c, out int y, out int r);
            if (Input.GetMouseButtonDown(0))
            {
                m_nuggets[nuggetIndex].m_shape = m_selectedShapeN;
                m_nuggets[nuggetIndex].m_presetN = m_selectedPresetN;
                m_state = State.PreEvaluate;
            }
            m_preview.transform.position = new Vector3((c + m_xorg) * m_mapLevel.m_scale, y * m_mapLevel.m_scale, (r + m_zorg) * m_mapLevel.m_scale);
        }
        else if (pickedColumn > -1 && pickedRow > -1)
        {
            m_preview.transform.position = new Vector3((pickedColumn + m_xorg) * m_mapLevel.m_scale, pickedY * m_mapLevel.m_scale, (pickedRow + m_zorg) * m_mapLevel.m_scale);
        }
    }

    private void HandlePlaceNegY(int nuggetIndex, int pickedColumn, int pickedY, int pickedRow)
    {
        while (nuggetIndex < m_nuggets.Length && nuggetIndex > -1 && m_nuggets[nuggetIndex].m_shape != 0)
            nuggetIndex -= m_levelSize;

        if (nuggetIndex < m_nuggets.Length && nuggetIndex > -1)
        {
            GetCROut(nuggetIndex, m_nuggetCount, m_levelSize, out int c, out int y, out int r);
            if (Input.GetMouseButtonDown(0))
            {
                m_nuggets[nuggetIndex].m_shape = m_selectedShapeN;
                m_nuggets[nuggetIndex].m_presetN = m_selectedPresetN;
                m_state = State.PreEvaluate;
            }
            m_preview.transform.position = new Vector3((c + m_xorg) * m_mapLevel.m_scale, y * m_mapLevel.m_scale, (r + m_zorg) * m_mapLevel.m_scale);
        }
        else if (pickedColumn > -1 && pickedRow > -1)
        {
            m_preview.transform.position = new Vector3((pickedColumn + m_xorg) * m_mapLevel.m_scale, pickedY * m_mapLevel.m_scale, (pickedRow + m_zorg) * m_mapLevel.m_scale);
        }
    }

    private void HandlePlacePosZ(int nuggetIndex, int pickedColumn, int pickedY, int pickedRow)
    {
        while (nuggetIndex < m_nuggets.Length && nuggetIndex > -1 && m_nuggets[nuggetIndex].m_shape != 0)
            nuggetIndex += m_nuggetCount;

        if (nuggetIndex < m_nuggets.Length && nuggetIndex > -1)
        {
            GetCROut(nuggetIndex, m_nuggetCount, m_levelSize, out int c, out int y, out int r);
            if (Input.GetMouseButtonDown(0))
            {
                m_nuggets[nuggetIndex].m_shape = m_selectedShapeN;
                m_nuggets[nuggetIndex].m_presetN = m_selectedPresetN;
                m_state = State.PreEvaluate;
            }
            m_preview.transform.position = new Vector3((c + m_xorg) * m_mapLevel.m_scale, y * m_mapLevel.m_scale, (r + m_zorg) * m_mapLevel.m_scale);
        }
        else if (pickedColumn > -1 && pickedRow > -1)
        {
            m_preview.transform.position = new Vector3((pickedColumn + m_xorg) * m_mapLevel.m_scale, pickedY * m_mapLevel.m_scale, (pickedRow + m_zorg) * m_mapLevel.m_scale);
        }
    }

    private void HandlePlaceNegZ(int nuggetIndex, int pickedColumn, int pickedY, int pickedRow)
    {
        while (nuggetIndex < m_nuggets.Length && nuggetIndex > -1 && m_nuggets[nuggetIndex].m_shape != 0)
            nuggetIndex -= m_nuggetCount;

        if (nuggetIndex < m_nuggets.Length && nuggetIndex > -1)
        {
            GetCROut(nuggetIndex, m_nuggetCount, m_levelSize, out int c, out int y, out int r);
            if (Input.GetMouseButtonDown(0))
            {
                m_nuggets[nuggetIndex].m_shape = m_selectedShapeN;
                m_nuggets[nuggetIndex].m_presetN = m_selectedPresetN;
                m_state = State.PreEvaluate;
            }
            m_preview.transform.position = new Vector3((c + m_xorg) * m_mapLevel.m_scale, y * m_mapLevel.m_scale, (r + m_zorg) * m_mapLevel.m_scale);
        }
        else if (pickedColumn > -1 && pickedRow > -1)
        {
            m_preview.transform.position = new Vector3((pickedColumn + m_xorg) * m_mapLevel.m_scale, pickedY * m_mapLevel.m_scale, (pickedRow + m_zorg) * m_mapLevel.m_scale);
        }
    }

    private void Generate()
    {
        m_nuggets = new Nugget[m_levelSize * m_mapLevel.m_maxHeight];
        m_heightMap = new byte[m_levelSize];
        for (int z = 0; z < m_nuggetCount; ++z)
        {
            for (int x = 0; x < m_nuggetCount; ++x)
            {
                float h = NoiseGenerator.I.GetNoise(x, z, m_mapLevel.m_seed,
                    m_mapLevel.m_worldSize, m_mapLevel.m_smoothing,
                    m_xorg, m_zorg);
                h *= m_mapLevel.m_generateHeight;

                try
                {
                    int index = GetCRIndex(x, z, m_nuggetCount);
                    m_heightMap[index] = (byte)h;
                    for (int y = 0; y < m_mapLevel.m_maxHeight; ++y)
                    {
                        index = GetCRIndex(x, y, z, m_nuggetCount, m_levelSize);
                        short shapeN = (short)(y < h ? 1 : 0);
                        m_nuggets[index] = new Nugget()
                        {
                            m_presetN = 0,
                            m_shape = shapeN,
                        };
                    }
                }
                catch (System.Exception ex)
                {
                    Debug.LogError(ex.Message);
                }
            }
        }
        m_generated = true;
        m_state = State.PreEvaluate;
    }

    private void PreEvaluate()
    {
        m_createResults.m_currentN = 0;
        m_evaluateResults.Reset();
        m_state = State.Evaluate;
    }

    private void Evaluate()
    {
        for (int n = m_evaluateResults.m_breakN; n < m_nuggets.Length; ++n)
        {
            try
            {
                Nugget nugget = m_nuggets[n];
                if (nugget.m_shape != 0)
                {
                    GetCROut(n, m_nuggetCount, m_levelSize, out int c, out int y, out int r);
                    Nugget[] neighbors = new Nugget[17];
                    GetNeighbors(n, c, y, r, ref neighbors);
                    neighbors[0] = nugget;
                    try
                    {
                        m_baseShape.Evaluate(c, y, r, ref neighbors, ref m_evaluateResults);
                    }
                    catch (System.Exception ex)
                    {
                        Debug.LogError(ex.Message);
                    }

                    if (m_evaluateResults.m_vcnt + 2400 >= m_verticeLimit &&
                        (n + 1 < m_nuggets.Length))
                    {
                        m_evaluateResults.m_breakC = c;
                        m_evaluateResults.m_breakY = y;
                        m_evaluateResults.m_breakR = r;
                        m_evaluateResults.m_breakN = n;
                        m_evaluateResults.m_hasMore = true;
                        break;
                    }
                }
            }
            catch (System.Exception ex)
            {
                Debug.LogError(ex.Message);
            }
        }
        m_state = State.PostEvaluate;
    }

    private void PostEvaluate()
    {
        System.Array.Resize(ref m_evaluateResults.m_tmpvertices, m_evaluateResults.m_vcnt);
        System.Array.Copy(m_evaluateResults.m_vertices, m_evaluateResults.m_tmpvertices,
            m_evaluateResults.m_vcnt);

        System.Array.Resize(ref m_evaluateResults.m_tmpnormals, m_evaluateResults.m_vcnt);
        System.Array.Copy(m_evaluateResults.m_normals, m_evaluateResults.m_tmpnormals,
            m_evaluateResults.m_vcnt);

        System.Array.Resize(ref m_evaluateResults.m_tmpuvs, m_evaluateResults.m_vcnt);
        System.Array.Copy(m_evaluateResults.m_uvs, m_evaluateResults.m_tmpuvs,
            m_evaluateResults.m_vcnt);

        System.Array.Resize(ref m_evaluateResults.m_tmptangents, m_evaluateResults.m_vcnt);
        System.Array.Copy(m_evaluateResults.m_tangents, m_evaluateResults.m_tmptangents,
            m_evaluateResults.m_vcnt);

        for (int n = 0; n < m_evaluateResults.m_faceIndexGroups.Length; ++n)
        {
            if (m_evaluateResults.m_faceIndexGroups[n].m_used)
            {
                System.Array.Resize(ref m_evaluateResults.m_tmpfaceIndexGroups[n].m_faceIndexs,
                    m_evaluateResults.m_faceIndexGroups[n].m_totalFaceIndexUsed);
                System.Array.Copy(m_evaluateResults.m_faceIndexGroups[n].m_faceIndexs,
                    m_evaluateResults.m_tmpfaceIndexGroups[n].m_faceIndexs,
                    m_evaluateResults.m_faceIndexGroups[n].m_totalFaceIndexUsed);
                m_evaluateResults.m_tmpfaceIndexGroups[n].m_used = true;
                ++m_evaluateResults.m_totalMatCnt;
            }
            else
                m_evaluateResults.m_tmpfaceIndexGroups[n].m_used = false;
        }
        m_state = State.CreateMesh0;
    }

    private void CreateMesh0()
    {
        if (m_createResults.m_currentN >= m_createResults.m_gameObjects.Length)
        {
            GameObject nwChild = new GameObject(string.Format("child{0}",
                m_createResults.m_gameObjects.Length));
            nwChild.transform.SetParent(transform);
            m_createResults.m_gameObjects = m_createResults.m_gameObjects.Add(nwChild);

            m_createResults.m_meshes = m_createResults.m_meshes.Add(new Mesh());
            m_createResults.m_gameObjects[m_createResults.m_currentN].AddComponent<MeshCollider>();
            m_createResults.m_gameObjects[m_createResults.m_currentN].AddComponent<MeshRenderer>();
            MeshFilter mf = m_createResults.m_gameObjects[m_createResults.m_currentN].AddComponent<MeshFilter>();
            mf.sharedMesh = m_createResults.m_meshes[m_createResults.m_currentN];
        }

        Mesh mesh = m_createResults.m_meshes[m_createResults.m_currentN];
        if (mesh == null)
        {
            mesh = new Mesh()
            {
                vertices = m_evaluateResults.m_tmpvertices,
                normals = m_evaluateResults.m_tmpnormals,
                uv = m_evaluateResults.m_tmpuvs,
                tangents = m_evaluateResults.m_tmptangents,
                subMeshCount = m_evaluateResults.m_totalMatCnt,
            };
        }
        else
        {
            mesh.Clear();
            mesh.vertices = m_evaluateResults.m_tmpvertices;
            mesh.normals = m_evaluateResults.m_tmpnormals;
            mesh.uv = m_evaluateResults.m_tmpuvs;
            mesh.tangents = m_evaluateResults.m_tmptangents;
            mesh.subMeshCount = m_evaluateResults.m_totalMatCnt;
        }

        Material[] materials = new Material[0];
        int m = 0;
        for (int n = 0; n < m_evaluateResults.m_tmpfaceIndexGroups.Length; ++n)
        {
            if (m_evaluateResults.m_tmpfaceIndexGroups[n].m_used)
            {
                materials = materials.Add(m_materials[n]);
                mesh.SetTriangles(m_evaluateResults.m_tmpfaceIndexGroups[n].m_faceIndexs, m);
                ++m;
            }
        }

        MeshRenderer render = m_createResults.m_gameObjects[m_createResults.m_currentN].GetComponent<MeshRenderer>();
        render.sharedMaterials = materials;
        //mesh.RecalculateTangents();
        MeshCollider collider = m_createResults.m_gameObjects[m_createResults.m_currentN].GetComponent<MeshCollider>();
        collider.sharedMesh = mesh;
        MeshFilter filter = m_createResults.m_gameObjects[m_createResults.m_currentN].GetComponent<MeshFilter>();
        filter.sharedMesh = mesh;
        m_state = State.CreateMesh1;
    }

    private void CreateMesh1()
    {
        m_created = true;
        m_state = State.Paused;
    }

    private void GetNeighbors(int nuggetIndex, int c, int y, int r, ref Nugget[] nuggets)
    {
        //Neighbor0
        if (r > 0)
        {
            nuggets[m_sn0] = m_nuggets[nuggetIndex - m_nuggetCount];
        }
        else
        {
            nuggets[m_sn0] = new Nugget() { m_shape = 0 };
        }

        //Neighbor2
        if (r + 1 < m_nuggetCount)
        {
            nuggets[m_sn2] = m_nuggets[nuggetIndex + m_nuggetCount];
        }
        else
        {
            nuggets[m_sn2] = new Nugget() { m_shape = 0 };
        }

        //Neighbor1
        if (c > 0)
        {
            nuggets[m_sn1] = m_nuggets[nuggetIndex - 1];
        }
        else
        {
            nuggets[m_sn1] = new Nugget() { m_shape = 0 };
        }

        //Neighbor3
        if (c + 1 < m_nuggetCount)
        {
            nuggets[m_sn3] = m_nuggets[nuggetIndex + 1];
        }
        else
        {
            nuggets[m_sn3] = new Nugget() { m_shape = 0 };
        }

        if (y + 1 < m_mapLevel.m_maxHeight)
        {
            nuggets[m_sn4] = m_nuggets[nuggetIndex + m_levelSize];
        }
        else
        {
            nuggets[m_sn4] = new Nugget() { m_shape = 0 };
        }

        if (y - 1 >= 0)
        {
            nuggets[m_sn5] = m_nuggets[nuggetIndex - m_levelSize];
        }
        else
        {
            nuggets[m_sn5] = new Nugget() { m_shape = m_selectedShapeN };
        }
    }

    private void CreatePreview()
    {
        EvaluateResults eresults = new EvaluateResults();
        eresults.Initialize(1, 2400);
        m_baseShape.EvaluatePreview(ref eresults);

        if (m_preview == null)
        {
            m_preview = new GameObject("preview");
            m_preview.transform.SetParent(transform);
            MeshFilter mf = m_preview.AddComponent<MeshFilter>();
            m_preview.AddComponent<MeshRenderer>();
            mf.sharedMesh = new Mesh();
        }

        System.Array.Resize(ref eresults.m_vertices, eresults.m_vcnt);
        System.Array.Resize(ref eresults.m_uvs, eresults.m_vcnt);
        System.Array.Resize(ref eresults.m_normals, eresults.m_vcnt);

        System.Array.Resize(ref eresults.m_faceIndexGroups[0].m_faceIndexs, eresults.m_tficnt[0]);

        Mesh mesh = m_preview.GetComponent<MeshFilter>().sharedMesh;
        mesh.vertices = eresults.m_vertices;
        mesh.normals = eresults.m_normals;
        mesh.uv = eresults.m_uvs;
        mesh.SetTriangles(eresults.m_faceIndexGroups[0].m_faceIndexs, 0);
        m_preview.GetComponent<MeshRenderer>().sharedMaterial = m_previewMaterial;
    }

    #region ui
    public Text m_txtNIndex;
    public Text m_txtCol;
    public Text m_txtY;
    public Text m_txtRow;
    public Text m_txtShape;
    public Text m_txtMat;

    private void SetIndetify(int nuggetIndex, int c, int y, int r)
    {
        m_txtNIndex.text = nuggetIndex.ToString();
        m_txtCol.text = c.ToString();
        m_txtY.text = y.ToString();
        m_txtRow.text = r.ToString();

        m_txtShape.text = m_nuggets[nuggetIndex].m_shape.ToString();
        m_txtMat.text = m_nuggets[nuggetIndex].m_presetN.ToString();
    }

    #endregion

    [System.Serializable]
    public struct Nugget
    {
        public short m_presetN;
        public short m_shape;
    }

    [System.Serializable]
    public struct CreateResults
    {
        public int m_currentN;
        public Mesh[] m_meshes;
        public GameObject[] m_gameObjects;
    }

    [System.Serializable]
    public struct MaterialPreset
    {
        public string m_key;
        public short[] m_matNs;
    }

    [System.Serializable]
    public struct FaceIndexGroup
    {
        public bool m_used;
        public int[] m_faceIndexs;
        public int m_totalFaceIndexUsed;
    }

    [System.Serializable]
    public struct EvaluateResults
    {
        public Vector3[] m_vertices;
        public Vector3[] m_normals;
        public Vector2[] m_uvs;
        public Vector4[] m_tangents;
        public FaceIndexGroup[] m_faceIndexGroups;

        public Vector3[] m_tmpvertices;
        public Vector3[] m_tmpnormals;
        public Vector2[] m_tmpuvs;
        public Vector4[] m_tmptangents;
        public FaceIndexGroup[] m_tmpfaceIndexGroups;

        public int m_vcnt;
        public int[] m_tficnt;
        public int m_matCnt;
        public int m_totalMatCnt;

        public int m_breakN;
        public int m_breakC;
        public int m_breakY;
        public int m_breakR;
        public bool m_hasMore;

        public void Initialize(int matCnt, int verticeLimit)
        {
            m_matCnt = matCnt;
            m_vertices = new Vector3[verticeLimit];
            m_normals = new Vector3[verticeLimit];
            m_uvs = new Vector2[verticeLimit];
            m_tangents = new Vector4[verticeLimit];
            m_faceIndexGroups = new FaceIndexGroup[m_matCnt];
            m_tmpfaceIndexGroups = new FaceIndexGroup[m_matCnt];

            for (int n = 0; n < m_faceIndexGroups.Length; ++n)
            {
                m_faceIndexGroups[n].m_faceIndexs = new int[verticeLimit * 6];
            }

            m_tficnt = new int[matCnt];
        }

        public void Reset(bool resetBreaks = true)
        {
            m_hasMore = false;
            m_tficnt = new int[m_matCnt];
            m_vcnt = 0;
            m_totalMatCnt = 0;

            if (resetBreaks)
            {
                m_breakN = 0;
                m_breakC = m_breakY = m_breakR = 0;
            }

            for (int n = 0; n < m_faceIndexGroups.Length; ++n)
            {
                m_faceIndexGroups[n].m_totalFaceIndexUsed = 0;
                m_faceIndexGroups[n].m_used = false;
            }
        }
    }

    public class BaseShape : ScriptableObject
    {
        private MaterialPreset[] m_presets;
        protected MeshLibrary m_meshLibrary;
        protected int[] m_vcntrefs;
        protected int m_scale;
        protected int m_xorg;
        protected int m_zorg;

        public virtual void Initialize(MaterialPreset[] presets, MeshLibrary meshLibrary, int scale, int xorg, int zorg)
        {
            m_vcntrefs = new int[2400];
            m_meshLibrary = meshLibrary;
            m_presets = presets;
            m_scale = scale;
            m_xorg = xorg;
            m_zorg = zorg;
        }

        public virtual void Evaluate(int x, int y, int z,
            ref Nugget[] neighbors, ref EvaluateResults results)
        {
            try
            {
                Vector3 offset = new Vector3(m_xorg, 0f, m_zorg);
                short presetN = neighbors[0].m_presetN;
                MeshShape shape = m_meshLibrary.m_meshShapes.m_shapes[neighbors[0].m_shape];
                for (int n = 0; n < shape.m_meshParts.Length; ++n)
                {
                    MaterialPreset mp = m_presets[neighbors[shape.m_matSource[n]].m_presetN];
                    MeshPart p = shape.m_meshParts[n].m_oppositesPart.m_opposites[neighbors[(byte)shape.m_meshParts[n].m_side].m_shape];
                    ProcessSide(offset + new Vector3(x, y, z), p,
                        mp.m_matNs[shape.m_matNs[n]], ref results);
                }
            }
            catch (System.Exception ex)
            {
                Debug.LogError(ex.Message);
            }
        }

        protected virtual void ProcessSide(Vector3 offset,
            MeshPart side, short matN,
            ref EvaluateResults results)
        {
            try
            {
                for (int n = 0; n < side.m_vertices.Length; ++n)
                {
                    try
                    {
                        results.m_vertices[results.m_vcnt] = side.m_vertices[n] + offset;
                        results.m_vertices[results.m_vcnt] *= m_scale;
                        results.m_normals[results.m_vcnt] = side.m_normals[n];
                        results.m_tangents[results.m_vcnt] = side.m_tangents[n];
                        results.m_uvs[results.m_vcnt] = side.m_uvs[n];
                        m_vcntrefs[n] = results.m_vcnt;
                        ++results.m_vcnt;
                    }
                    catch (System.Exception ex)
                    {
                        Debug.LogError(ex.Message);
                    }
                }

                for (int n = 0; n < side.m_faceIndexs.Length; ++n)
                {
                    try
                    {
                        ++results.m_faceIndexGroups[matN].m_totalFaceIndexUsed;
                        results.m_faceIndexGroups[matN].m_used = true;
                        results.m_faceIndexGroups[matN].m_faceIndexs[results.m_tficnt[matN]] =
                            m_vcntrefs[side.m_faceIndexs[n]];
                        ++results.m_tficnt[matN];
                    }
                    catch(System.Exception ex)
                    {
                        Debug.LogError(ex.Message);
                    }
                }
            }
            catch(System.Exception ex)
            {
                Debug.LogError(ex.Message);
            }
        }

        public virtual void EvaluatePreview(ref EvaluateResults results)
        {
            try
            {
                CreateSide0(Vector3.zero, 0, 0, 0, 0, ref results);
                CreateSide1(Vector3.zero, 0, 0, 0, 0, ref results);
                CreateSide2(Vector3.zero, 0, 0, 0, 0, ref results);
                CreateSide3(Vector3.zero, 0, 0, 0, 0, ref results);
                CreateSide4(Vector3.zero, 0, 0, 0, 0, ref results);
                CreateSide5(Vector3.zero, 0, 0, 0, 0, ref results);
            }
            catch(System.Exception ex)
            {
                Debug.LogError(ex.Message);
            }
        }

        protected void CreateSide0(Vector3 offset, int x, int y, int z,
            int matN, ref EvaluateResults results)
        {
            try
            {
                results.m_vertices[results.m_vcnt] = new Vector3(x, y, z) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(0f, 0f);
                results.m_normals[results.m_vcnt] = new Vector3(0f, 0f, -1f);
                m_vcntrefs[0] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x, y + 1f, z) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(0f, 1f);
                results.m_normals[results.m_vcnt] = new Vector3(0f, 0f, -1f);
                m_vcntrefs[1] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x + 1f, y + 1f, z) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(1f, 1f);
                results.m_normals[results.m_vcnt] = new Vector3(0f, 0f, -1f);
                m_vcntrefs[2] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x + 1f, y, z) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(1f, 0f);
                results.m_normals[results.m_vcnt] = new Vector3(0f, 0f, -1f);
                m_vcntrefs[3] = results.m_vcnt;
                ++results.m_vcnt;
            }
            catch (System.Exception ex)
            {
                Debug.LogError(ex.Message);
            }

            try
            {
                int[] faceIndexs = new int[]
                {
                    0, 1, 2,
                    0, 2, 3,
                };

                for (int n = 0; n < faceIndexs.Length; ++n)
                {
                    try
                    {
                        ++results.m_faceIndexGroups[matN].m_totalFaceIndexUsed;
                        results.m_faceIndexGroups[matN].m_used = true;
                        results.m_faceIndexGroups[matN].m_faceIndexs[results.m_tficnt[matN]] =
                            m_vcntrefs[faceIndexs[n]];
                        ++results.m_tficnt[matN];
                    }
                    catch (System.Exception ex)
                    {
                        Debug.LogError(ex.Message);
                    }
                }
            }
            catch (System.Exception ex)
            {
                Debug.LogError(ex.Message);
            }
        }

        protected void CreateSide1(Vector3 offset, int x, int y, int z,
            int matN, ref EvaluateResults results)
        {
            try
            {
                results.m_vertices[results.m_vcnt] = new Vector3(x, y, z + 1f) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(0f, 0f);
                results.m_normals[results.m_vcnt] = new Vector3(-1f, 0f, 0f);
                m_vcntrefs[0] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x, y + 1f, z + 1f) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(0f, 1f);
                results.m_normals[results.m_vcnt] = new Vector3(-1f, 0f, 0f);
                m_vcntrefs[1] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x, y + 1f, z) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(1f, 1f);
                results.m_normals[results.m_vcnt] = new Vector3(-1f, 0f, 0f);
                m_vcntrefs[2] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x, y, z) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(1f, 0f);
                results.m_normals[results.m_vcnt] = new Vector3(-1f, 0f, 0f);
                m_vcntrefs[3] = results.m_vcnt;
                ++results.m_vcnt;
            }
            catch (System.Exception ex)
            {
                Debug.LogError(ex.Message);
            }

            try
            {
                int[] faceIndexs = new int[]
                {
                    0, 1, 2,
                    0, 2, 3,
                };

                for (int n = 0; n < faceIndexs.Length; ++n)
                {
                    try
                    {
                        ++results.m_faceIndexGroups[matN].m_totalFaceIndexUsed;
                        results.m_faceIndexGroups[matN].m_used = true;
                        results.m_faceIndexGroups[matN].m_faceIndexs[results.m_tficnt[matN]] =
                            m_vcntrefs[faceIndexs[n]];
                        ++results.m_tficnt[matN];
                    }
                    catch (System.Exception ex)
                    {
                        Debug.LogError(ex.Message);
                    }
                }
            }
            catch (System.Exception ex)
            {
                Debug.LogError(ex.Message);
            }
        }

        protected void CreateSide2(Vector3 offset, int x, int y, int z,
            int matN, ref EvaluateResults results)
        {
            try
            {
                results.m_vertices[results.m_vcnt] = new Vector3(x + 1f, y, z + 1f) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(0f, 0f);
                results.m_normals[results.m_vcnt] = new Vector3(0f, 0f, 1f);
                m_vcntrefs[0] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x + 1f, y + 1f, z + 1f) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(0f, 1f);
                results.m_normals[results.m_vcnt] = new Vector3(0f, 0f, 1f);
                m_vcntrefs[1] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x, y + 1f, z + 1f) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(1f, 1f);
                results.m_normals[results.m_vcnt] = new Vector3(0f, 0f, 1f);
                m_vcntrefs[2] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x, y, z + 1f) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(1f, 0f);
                results.m_normals[results.m_vcnt] = new Vector3(0f, 0f, 1f);
                m_vcntrefs[3] = results.m_vcnt;
                ++results.m_vcnt;
            }
            catch (System.Exception ex)
            {
                Debug.LogError(ex.Message);
            }

            try
            {
                int[] faceIndexs = new int[]
                {
                    0, 1, 2,
                    0, 2, 3,
                };

                for (int n = 0; n < faceIndexs.Length; ++n)
                {
                    try
                    {
                        ++results.m_faceIndexGroups[matN].m_totalFaceIndexUsed;
                        results.m_faceIndexGroups[matN].m_used = true;
                        results.m_faceIndexGroups[matN].m_faceIndexs[results.m_tficnt[matN]] =
                            m_vcntrefs[faceIndexs[n]];
                        ++results.m_tficnt[matN];
                    }
                    catch (System.Exception ex)
                    {
                        Debug.LogError(ex.Message);
                    }
                }
            }
            catch (System.Exception ex)
            {
                Debug.LogError(ex.Message);
            }
        }

        protected void CreateSide3(Vector3 offset, int x, int y, int z,
            int matN, ref EvaluateResults results)
        {
            try
            {
                results.m_vertices[results.m_vcnt] = new Vector3(x + 1f, y, z) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(0f, 0f);
                results.m_normals[results.m_vcnt] = new Vector3(1f, 0f, 0f);
                m_vcntrefs[0] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x + 1f, y + 1f, z) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(0f, 1f);
                results.m_normals[results.m_vcnt] = new Vector3(1f, 0f, 0f);
                m_vcntrefs[1] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x + 1f, y + 1f, z + 1f) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(1f, 1f);
                results.m_normals[results.m_vcnt] = new Vector3(1f, 0f, 0f);
                m_vcntrefs[2] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x + 1f, y, z + 1f) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(1f, 0f);
                results.m_normals[results.m_vcnt] = new Vector3(1f, 0f, 0f);
                m_vcntrefs[3] = results.m_vcnt;
                ++results.m_vcnt;
            }
            catch (System.Exception ex)
            {
                Debug.LogError(ex.Message);
            }

            try
            {
                int[] faceIndexs = new int[]
                {
                    0, 1, 2,
                    0, 2, 3,
                };

                for (int n = 0; n < faceIndexs.Length; ++n)
                {
                    try
                    {
                        ++results.m_faceIndexGroups[matN].m_totalFaceIndexUsed;
                        results.m_faceIndexGroups[matN].m_used = true;
                        results.m_faceIndexGroups[matN].m_faceIndexs[results.m_tficnt[matN]] =
                            m_vcntrefs[faceIndexs[n]];
                        ++results.m_tficnt[matN];
                    }
                    catch (System.Exception ex)
                    {
                        Debug.LogError(ex.Message);
                    }
                }
            }
            catch (System.Exception ex)
            {
                Debug.LogError(ex.Message);
            }
        }

        protected void CreateSide4(Vector3 offset, int x, int y, int z,
            int matN, ref EvaluateResults results)
        {
            try
            {
                results.m_vertices[results.m_vcnt] = new Vector3(x, y + 1f, z) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(0f, 0f);
                results.m_normals[results.m_vcnt] = new Vector3(0f, 1f, 0f);
                m_vcntrefs[0] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x, y + 1f, z + 1f) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(0f, 1f);
                results.m_normals[results.m_vcnt] = new Vector3(0f, 1f, 0f);
                m_vcntrefs[1] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x + 1f, y + 1f, z + 1f) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(1f, 1f);
                results.m_normals[results.m_vcnt] = new Vector3(0f, 1f, 0f);
                m_vcntrefs[2] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x + 1f, y + 1f, z) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(1f, 0f);
                results.m_normals[results.m_vcnt] = new Vector3(0f, 1f, 0f);
                m_vcntrefs[3] = results.m_vcnt;
                ++results.m_vcnt;
            }
            catch (System.Exception ex)
            {
                Debug.LogError(ex.Message);
            }

            try
            {
                int[] faceIndexs = new int[]
                {
                    0, 1, 2,
                    0, 2, 3,
                };

                for (int n = 0; n < faceIndexs.Length; ++n)
                {
                    try
                    {
                        ++results.m_faceIndexGroups[matN].m_totalFaceIndexUsed;
                        results.m_faceIndexGroups[matN].m_used = true;
                        results.m_faceIndexGroups[matN].m_faceIndexs[results.m_tficnt[matN]] =
                            m_vcntrefs[faceIndexs[n]];
                        ++results.m_tficnt[matN];
                    }
                    catch (System.Exception ex)
                    {
                        Debug.LogError(ex.Message);
                    }
                }
            }
            catch (System.Exception ex)
            {
                Debug.LogError(ex.Message);
            }
        }

        protected void CreateSide5(Vector3 offset, int x, int y, int z,
            int matN, ref EvaluateResults results)
        {
            try
            {
                results.m_vertices[results.m_vcnt] = new Vector3(x, y, z) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(0f, 0f);
                results.m_normals[results.m_vcnt] = new Vector3(0f, -1f, 0f);
                m_vcntrefs[0] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x, y, z + 1f) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(0f, 1f);
                results.m_normals[results.m_vcnt] = new Vector3(0f, -1f, 0f);
                m_vcntrefs[1] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x + 1f, y, z + 1f) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(1f, 1f);
                results.m_normals[results.m_vcnt] = new Vector3(0f, -1f, 0f);
                m_vcntrefs[2] = results.m_vcnt;
                ++results.m_vcnt;

                results.m_vertices[results.m_vcnt] = new Vector3(x + 1f, y, z) + offset;
                results.m_vertices[results.m_vcnt] *= m_scale;
                results.m_uvs[results.m_vcnt] = new Vector2(1f, 0f);
                results.m_normals[results.m_vcnt] = new Vector3(0f, -1f, 0f);
                m_vcntrefs[3] = results.m_vcnt;
                ++results.m_vcnt;
            }
            catch (System.Exception ex)
            {
                Debug.LogError(ex.Message);
            }

            try
            {
                int[] faceIndexs = new int[]
                {
                    2, 1, 0,
                    3, 2, 0,
                };

                for (int n = 0; n < faceIndexs.Length; ++n)
                {
                    try
                    {
                        ++results.m_faceIndexGroups[matN].m_totalFaceIndexUsed;
                        results.m_faceIndexGroups[matN].m_used = true;
                        results.m_faceIndexGroups[matN].m_faceIndexs[results.m_tficnt[matN]] =
                            m_vcntrefs[faceIndexs[n]];
                        ++results.m_tficnt[matN];
                    }
                    catch (System.Exception ex)
                    {
                        Debug.LogError(ex.Message);
                    }
                }
            }
            catch (System.Exception ex)
            {
                Debug.LogError(ex.Message);
            }
        }

    }
}