﻿#pragma warning disable 0168    // variable declared but not used.
#pragma warning disable 0219    // variable assigned but not used.
#pragma warning disable 0414    // private field assigned but not used.
#pragma warning disable 0649    // public field assigned but not used.
#pragma warning disable 0067
#pragma warning disable UNT0001
using System;
using UnityEngine;
using UnityEngine.UI;
using static Common;

public class HSLab2Common : MonoBehaviour
{
    public CharacterCamera m_character;
    public enum State
    {
        Paused,
        InUse,
        Update,
    }
    public State m_state;
    public HSLab2.InputMode m_inputMode;

    public HSLab2[] m_chunks;
    public static int m_chunkSpan = 3;

    public MapLevel m_mapLevel;
    public MeshLibrary m_meshLibrary;

    public Material[] m_materials;
    public HSLab2.MaterialPreset[] m_materialPresets;
    public HSLab2.EvaluateResults m_evaluateResults;

    public GameObject m_preview;
    public Material m_previewMaterial;

    public HSLab2.BaseShape m_baseShape;

    public float m_x;
    public float m_y;
    public float m_z;

    public float m_nrmX;
    public float m_nrmY;
    public float m_nrmZ;

    public int m_pickedIndex;
    public int m_pickedColumn;
    public int m_pickedY;
    public int m_pickedRow;

    public bool m_ceven;
    public float m_clickDistance = 500f;

    public short m_selectedPresetN;
    public short m_selectedShapeN;

    public bool m_nuggetMode;
    public int m_nuggetDistance = 5;

    // Start is called before the first frame update
    void Start()
    {
        m_evaluateResults.Initialize(m_materials.Length, HSLab2.m_verticeLimit);
        m_baseShape = ScriptableObject.CreateInstance<HSLab2.BaseShape>();
        m_baseShape.Initialize(m_materialPresets, m_meshLibrary, m_mapLevel.m_scale, 0, 0);

        m_chunks = GetComponentsInChildren<HSLab2>();
    }

    // Update is called once per frame
    void Update()
    {
        switch(m_state)
        {
            case State.InUse:
                break;
            case State.Update:
                m_state = State.Paused;
                CheckChunks();
                break;
        }
        if (m_state != State.InUse && m_inputMode != HSLab2.InputMode.None)
            HandleInput();
        else if (m_preview != null)
            Destroy(m_preview);
    }

    private void HandleInput()
    {
        if (m_preview == null)
            CreatePreview();

        int layerMask = 1 << 2;
        layerMask = ~layerMask;
        Vector3 mp = Input.mousePosition;
        Ray ray = m_character.m_camera.ScreenPointToRay(mp);

        if (Physics.Raycast(ray, out RaycastHit hitinfo, m_clickDistance * m_mapLevel.m_scale,
            layerMask, QueryTriggerInteraction.Collide))
        {
            if (hitinfo.collider.gameObject.transform.parent != null)
            {
                Vector3 point = hitinfo.point;
                Vector3 normal = hitinfo.normal;
                m_x = point.x / m_mapLevel.m_scale;
                m_y = point.y / m_mapLevel.m_scale;
                m_z = point.z / m_mapLevel.m_scale;

                m_nrmX = normal.x.Round(5);
                m_nrmY = normal.y.Round(5);
                m_nrmZ = normal.z.Round(5);

                HSLab2 chunk = hitinfo.collider.gameObject.transform.parent.GetComponent<HSLab2>();
                if (chunk != null)
                {
                    m_pickedIndex = chunk.m_index;
                    m_pickedColumn = ((m_x - chunk.m_xorg) / 0.75f).FloorToInt();
                    m_ceven = m_pickedColumn % 2 == 0;
                    m_pickedRow = (((m_z - chunk.m_zorg) - (m_ceven ? 0.4330127f : 0f)) / 0.8660254f).FloorToInt();
                    m_pickedY = (int)m_y;

                    if (m_inputMode == HSLab2.InputMode.Place)
                        chunk.HandlePlace(m_ceven, m_pickedColumn, m_pickedY, m_pickedRow, m_nrmX, m_nrmY, m_nrmZ);
                    else
                        chunk.HandleInner(m_ceven, m_pickedColumn, m_pickedY, m_pickedRow, m_nrmX, m_nrmY, m_nrmZ);
                }
            }
        }
    }

    private void CheckChunks()
    {
        if (m_chunks != null)
        {
            for (int n = 0; n < m_chunks.Length; ++n)
            {
                if (m_chunks[n].m_state == HSLab2.State.Waiting)
                {
                    m_state = State.InUse;
                    m_chunks[n].m_state = HSLab2.State.PreEvaluate;
                    return;
                }
            }
        }
        m_state = State.Update;
    }

    public void GetNeighborNugget(int chunkColumn, int chunkRow, 
        int nuggetIndex, ref HSLab2.Nugget nugget)
    {
        try
        {
            int chunkIndex = GetCRIndex(chunkColumn, chunkRow, m_chunkSpan);
            if (chunkIndex > -1 && chunkIndex < m_chunks.Length)
            {
                nugget = m_chunks[chunkIndex].m_nuggets[nuggetIndex];
            }
            else
            {
                nugget = new HSLab2.Nugget() { m_presetN = 0, m_shape = 0 };
            }
        }
        catch(System.Exception ex)
        {
            Debug.LogError(ex.Message);
        }
    }

    private void CreatePreview()
    {
        HSLab2.EvaluateResults eresults = new HSLab2.EvaluateResults();
        eresults.Initialize(1, 2400);
        m_baseShape.EvaluatePreview(ref eresults);

        if (m_preview == null)
        {
            m_preview = new GameObject("preview");
            m_preview.transform.SetParent(transform);
            MeshFilter mf = m_preview.AddComponent<MeshFilter>();
            m_preview.AddComponent<MeshRenderer>();
            mf.sharedMesh = new Mesh();
        }

        System.Array.Resize(ref eresults.m_tmpvertices, eresults.m_vcnt);
        System.Array.Copy(eresults.m_vertices, eresults.m_tmpvertices, eresults.m_vcnt);

        System.Array.Resize(ref eresults.m_tmpnormals, eresults.m_vcnt);
        System.Array.Copy(eresults.m_normals, eresults.m_tmpnormals, eresults.m_vcnt);

        System.Array.Resize(ref eresults.m_tmpuvs, eresults.m_vcnt);
        System.Array.Copy(eresults.m_uvs, eresults.m_tmpuvs, eresults.m_vcnt);

        System.Array.Resize(ref eresults.m_tmpfaceIndexGroups[0].m_faceIndexs, eresults.m_tficnt[0]);
        System.Array.Copy(eresults.m_faceIndexGroups[0].m_faceIndexs,
            eresults.m_tmpfaceIndexGroups[0].m_faceIndexs, eresults.m_tficnt[0]);

        Mesh mesh = m_preview.GetComponent<MeshFilter>().sharedMesh;
        mesh.vertices = eresults.m_tmpvertices;
        mesh.normals = eresults.m_tmpnormals;
        mesh.uv = eresults.m_tmpuvs;
        mesh.SetTriangles(eresults.m_tmpfaceIndexGroups[0].m_faceIndexs, 0);
        m_preview.GetComponent<MeshRenderer>().sharedMaterial = m_previewMaterial;
    }

    public void SetPreviewPosition(float x, float y, float z)
    {
        m_preview.transform.position = new Vector3(x, y, z);
    }

    #region ui
    public Text m_txtNIndex;
    public Text m_txtCol;
    public Text m_txtY;
    public Text m_txtRow;
    public Text m_txtMat;
    public Text m_txtShape;

    public void SetIndetify(int chunkIndex, int nuggetIndex, int col, int y, int row)
    {
        m_txtNIndex.text = nuggetIndex.ToString();
        m_txtCol.text = col.ToString();
        m_txtY.text = y.ToString();
        m_txtRow.text = row.ToString();

        m_txtMat.text = m_chunks[chunkIndex].m_nuggets[nuggetIndex].m_presetN.ToString();
        m_txtShape.text = m_chunks[chunkIndex].m_nuggets[nuggetIndex].m_shape.ToString();
    }

    public Text m_txtMemory;
    public void CurrentMemory()
    {
        m_txtMemory.text = string.Format("mem: {0}", (GC.GetTotalMemory(false) / 1048576f));
    }

    public void ClearMemory()
    {
        GC.Collect();
        CurrentMemory();
    }

    public void Close()
    {
        Application.Quit();
    }

    #endregion

}