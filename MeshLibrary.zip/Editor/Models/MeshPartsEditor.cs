﻿#pragma warning disable 0168
#pragma warning disable 0219
#pragma warning disable 0414
#pragma warning disable 0649
#pragma warning disable 0067
#pragma warning disable UNT0001
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(MeshParts))]
[CanEditMultipleObjects]
public class MeshPartsEditor : Editor
{
    private MeshParts m_meshParts;

    public override void OnInspectorGUI()
    {
        if (GUILayout.Button("refresh parts"))
            m_meshParts.RefreshParts();
        if (GUILayout.Button("clear meshes"))
            m_meshParts.ClearMeshes();
        if (GUILayout.Button("new part"))
            m_meshParts.NewPart();
        if (GUILayout.Button("refresh opposites"))
            m_meshParts.UpdateOpposites();
        DrawDefaultInspector();
    }

    private void OnEnable()
    {
        m_meshParts = (MeshParts)target;
    }
}