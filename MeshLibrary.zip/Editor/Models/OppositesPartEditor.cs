﻿#pragma warning disable 0168
#pragma warning disable 0219
#pragma warning disable 0414
#pragma warning disable 0649
#pragma warning disable 0067
#pragma warning disable UNT0001
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;


[CustomEditor(typeof(OppositesPart))]
public class OppositesPartEditor : Editor
{
    private OppositesPart m_oppositesPart;
    public override void OnInspectorGUI()
    {
        if (GUILayout.Button("editorwindow"))
            OppositesPartWin.ShowWindow();
        DrawDefaultInspector();
    }

    private void OnEnable()
    {
        m_oppositesPart = (OppositesPart)target;
    }
}