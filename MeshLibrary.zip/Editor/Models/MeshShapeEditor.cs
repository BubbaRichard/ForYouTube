﻿#pragma warning disable 0168
#pragma warning disable 0219
#pragma warning disable 0414
#pragma warning disable 0649
#pragma warning disable 0067
#pragma warning disable UNT0001
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(MeshShape))]
[CanEditMultipleObjects]
public class MeshShapeEditor : Editor
{
    public MeshShape m_meshShape;
    public override void OnInspectorGUI()
    {
        m_meshShape.m_takeParts = (GameObject)EditorGUILayout.ObjectField(m_meshShape.m_takeParts, typeof(GameObject), true);
        if (GUILayout.Button("take parts"))
            m_meshShape.TakeParts();
        DrawDefaultInspector();
    }

    private void OnEnable()
    {
        m_meshShape = (MeshShape)target;
    }
}