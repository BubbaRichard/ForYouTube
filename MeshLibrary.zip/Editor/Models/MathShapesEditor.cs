﻿#pragma warning disable 0168
#pragma warning disable 0219
#pragma warning disable 0414
#pragma warning disable 0649
#pragma warning disable 0067
#pragma warning disable UNT0001
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(MeshShapes))]
public class MeshShapesEditor : Editor
{
    public MeshShapes m_meshShapes;
    public override void OnInspectorGUI()
    {
        if (GUILayout.Button("new shape"))
            m_meshShapes.NewShape();
        if (GUILayout.Button("refresh shapes"))
            m_meshShapes.RefreshShapes();
        DrawDefaultInspector();
    }

    private void OnEnable()
    {
        m_meshShapes = (MeshShapes)target;
    }
}