﻿#pragma warning disable 0168
#pragma warning disable 0219
#pragma warning disable 0414
#pragma warning disable 0649
#pragma warning disable 0067
#pragma warning disable UNT0001

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

#if UNITY_EDITOR
using UnityEditor;
#endif

using static Common;

public class MeshPart : MonoBehaviour
{
    public Neighbor m_side;
    public GameObject m_source;
    public int m_indexInParent;
    public MeshParts m_parent;
    public OppositesPart m_oppositesPart;

    public bool m_selected;
    public Material m_material;
    public Vector3[] m_vertices;
    public Vector3[] m_normals;
    public Vector4[] m_tangents;
    public Vector2[] m_uvs;
    public int[] m_faceIndexs;

    public GameObject m_import;
    public AvailablePart[] m_parts;

#if UNITY_EDITOR
    public void ImportMesh()
    {
        if (m_import != null)
        {
            MeshFilter mf = m_import.GetComponent<MeshFilter>();
            if (mf != null)
            {
                Vector3[] vertices = mf.sharedMesh.vertices;
                Vector3[] normals = mf.sharedMesh.normals;
                Vector2[] uvs = mf.sharedMesh.uv;
                Vector4[] tangents = mf.sharedMesh.tangents;
                int maxFi = m_faceIndexs != null && m_faceIndexs.Length > 0 ? m_faceIndexs.Max() + 1 : 0;
                int[] faceIndexs = mf.sharedMesh.triangles.CloneArray();
                faceIndexs = faceIndexs.Addition(maxFi);
                m_vertices = m_vertices.AddRange(vertices);
                m_normals = m_normals.AddRange(normals);
                m_uvs = m_uvs.AddRange(uvs);
                m_tangents = m_tangents.AddRange(tangents);
                m_faceIndexs = m_faceIndexs.AddRange(faceIndexs);
            }
            m_import = null;
        }
    }

    public void RefreshMesh(bool justThis = false)
    {
        if (Selection.gameObjects != null && Selection.gameObjects.Length > 1 && !justThis)
        {
            for (int n = 0; n < Selection.gameObjects.Length; ++n)
            {
                MeshPart part = Selection.gameObjects[n].GetComponent<MeshPart>();
                if (part != null)
                {
                    DestroyMeshFilter(part.gameObject);
                    CreateMeshFilter(part.gameObject, part.m_material, part.m_vertices,
                        part.m_normals, part.m_uvs, part.m_tangents, part.m_faceIndexs);
                }
            }
        }
        else
        {
            DestroyMeshFilter(gameObject);
            CreateMeshFilter(gameObject, m_material, m_vertices, m_normals, m_uvs, m_tangents, m_faceIndexs);
        }
    }

    public void ClearMesh(bool justThis = false)
    {
        if (Selection.gameObjects != null && Selection.gameObjects.Length > 1 && !justThis)
        {
            for (int n = 0; n < Selection.gameObjects.Length; ++n)
            {
                MeshPart part = Selection.gameObjects[n].GetComponent<MeshPart>();
                if (part != null)
                    DestroyMeshFilter(part.gameObject);
            }
        }
        else
        {
            DestroyMeshFilter(gameObject);
        }
    }

    public static void CreateMeshFilter(GameObject target,
        Material material, Vector3[] vertices, Vector3[] normals,
        Vector2[] uvs, Vector4[] tangents, int[] faceIndexs)
    {
        if (target == null || target.ToString() == "null") return;
        if (faceIndexs == null || faceIndexs.Length <= 0) return;
        MeshFilter mf = target.GetComponent<MeshFilter>();
        if (mf == null)
            mf = target.AddComponent<MeshFilter>();
        MeshRenderer mr = target.GetComponent<MeshRenderer>();
        if (mr == null)
            mr = target.AddComponent<MeshRenderer>();
        mr.sharedMaterial = material;
        mf.sharedMesh = new Mesh();
        if (vertices.Length == normals.Length && vertices.Length == uvs.Length)
        {
            mf.sharedMesh.SetVertices(vertices);
            mf.sharedMesh.SetNormals(normals);
            mf.sharedMesh.SetUVs(0, uvs);
            mf.sharedMesh.SetTangents(tangents);
            mf.sharedMesh.subMeshCount = 1;
            mf.sharedMesh.SetTriangles(faceIndexs, 0);

            //mf.sharedMesh.RecalculateTangents();
            //m_tangents = mf.sharedMesh.tangents;
        }
        else
        {
            Debug.LogError("vertices, uvs, normals do not match");
        }
    }

    public static void DestroyMeshFilter(GameObject target)
    {
        if (target != null)
        {
            MeshFilter mf = target.GetComponent<MeshFilter>();
            if (mf != null)
                DestroyImmediate(mf);
            MeshRenderer mr = target.GetComponent<MeshRenderer>();
            if (mr != null)
                DestroyImmediate(mr);
        }
    }

#endif

    [System.Serializable]
    public struct AvailablePart
    {
        public string m_key;
        public bool m_selected;
        public MeshFilter m_mf;
    }
}