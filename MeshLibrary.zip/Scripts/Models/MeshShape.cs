﻿#pragma warning disable 0168
#pragma warning disable 0219
#pragma warning disable 0414
#pragma warning disable 0649
#pragma warning disable 0067
#pragma warning disable UNT0001
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MeshShape : MonoBehaviour
{
    public int m_indexInParent;
    public int m_shapeProcessor;
    public MeshShapes m_parent;
    public MeshPart[] m_meshParts;
    public GameObject m_takeParts;

    public byte[] m_matNs;
    public int[] m_matSource;

#if UNITY_EDITOR
    public void TakeParts()
    {
        if (m_takeParts != null)
            m_meshParts = m_takeParts.GetComponentsInChildren<MeshPart>();
        else
            m_meshParts = new MeshPart[0];
    }
#endif
}
