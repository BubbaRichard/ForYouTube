﻿#pragma warning disable 0168
#pragma warning disable 0219
#pragma warning disable 0414
#pragma warning disable 0649
#pragma warning disable 0067
#pragma warning disable UNT0001
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class MeshParts : MonoBehaviour
{
    public GameObject m_currentSides;
    public GameObject[] m_sidesParent;
    public MeshPart[] m_parts;
    public MeshPart m_noneSide;
    public Material m_defaultMaterial;

    public MeshShapes m_shapes;

    public void RefreshParts()
    {
        m_parts = m_currentSides.GetComponentsInChildren<MeshPart>();
        int index = 0;
        for (int n = 0; n < m_parts.Length; ++n)
        {
            m_parts[n].m_parent = this;
            m_parts[n].m_indexInParent = index;
            ++index;
        }

        if (m_sidesParent != null)
        {
            for (int i = 0; i < m_sidesParent.Length; ++i)
            {
                MeshPart[] parts = m_sidesParent[i].GetComponentsInChildren<MeshPart>();
                m_parts = m_parts.AddRange(parts);
                for (int n = 0; n < parts.Length; ++n)
                {
                    parts[n].m_parent = this;
                    parts[n].m_indexInParent = index;
                    ++index;
                }
            }
        }
    }

    public void ClearMeshes()
    {
        ClearMeshes(m_currentSides);
        if (m_sidesParent != null)
        {
            for (int n = 0; n < m_sidesParent.Length; ++n)
                ClearMeshes(m_sidesParent[n]);
        }
    }

    private void ClearMeshes(GameObject source)
    {
        MeshPart[] parts = source.GetComponentsInChildren<MeshPart>();
        for (int n = 0; n < m_parts.Length; ++n)
            parts[n].ClearMesh();
    }

    public void NewPart()
    {
        GameObject gonew = new GameObject("new");
        gonew.transform.SetParent(m_currentSides.transform);
        MeshPart part = gonew.AddComponent<MeshPart>();
        part.m_material = m_defaultMaterial;
        part.m_parent = this;
        OppositesPart op = gonew.AddComponent<OppositesPart>();
        System.Array.Resize(ref op.m_opposites, m_shapes.m_shapes.Length);
        for (int i = 0; i < op.m_opposites.Length; ++i)
            op.m_opposites[i] = part;

        UnityEditor.SceneManagement.EditorSceneManager.MarkAllScenesDirty();
        EditorUtility.SetDirty(gameObject);
    }

    public void UpdateOpposites()
    {
        UpdateOpposites(m_currentSides);
        if (m_sidesParent != null)
        {
            for (int n = 0; n < m_sidesParent.Length; ++n)
            {
                UpdateOpposites(m_sidesParent[n]);
            }
        }
    }

    private void UpdateOpposites(GameObject source)
    {
        m_shapes.RefreshShapes();
        MeshPart[] parts = source.GetComponentsInChildren<MeshPart>();
        for (int n = 0; n < parts.Length; ++n)
        {
            parts[n].m_parent = this;
            OppositesPart op = m_parts[n].GetComponent<OppositesPart>();
            if (op == null)
                op = parts[n].gameObject.AddComponent<OppositesPart>();
            int preCnt = op.m_opposites != null ? op.m_opposites.Length : 0;
            System.Array.Resize(ref op.m_opposites, m_shapes.m_shapes.Length);
            for (int i = preCnt; i < op.m_opposites.Length; ++i)
            {
                op.m_opposites[i] = parts[n];
            }
            parts[n].m_oppositesPart = op;
        }
    }
}